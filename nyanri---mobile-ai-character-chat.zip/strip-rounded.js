const fs = require('fs');
const path = require('path');

const files = [
  'src/components/apps/ContactsScreen.tsx',
  'src/components/apps/SocialScreen.tsx',
  'src/components/apps/SettingsScreen.tsx',
  'src/components/widgets.tsx',
];

files.forEach(file => {
  const fullPath = path.join(process.cwd(), file);
  if (fs.existsSync(fullPath)) {
    let content = fs.readFileSync(fullPath, 'utf8');
    
    // Replace rounded corners but let's be careful about strings that are not classes
    // Regex to match Tailwind rounded classes
    // e.g., rounded-xl, rounded-[24px], rounded-full, rounded-t-3xl, rounded, sm:rounded-3xl
    content = content.replace(/\b(sm:|md:|lg:|hover:|focus:|active:|group-hover:)?rounded(-(none|sm|md|lg|xl|2xl|3xl|full|t-[a-z0-9]+|b-[a-z0-9]+|l-[a-z0-9]+|r-[a-z0-9]+|\[.*?\]))?\b/g, '$1rounded-none');
    
    fs.writeFileSync(fullPath, content);
    console.log(`Updated ${file}`);
  } else {
    console.log(`File not found: ${file}`);
  }
});
