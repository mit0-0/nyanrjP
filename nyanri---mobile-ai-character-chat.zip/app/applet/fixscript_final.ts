import fs from 'fs';

let socialCode = fs.readFileSync('src/components/apps/SocialScreen.tsx', 'utf8');
const searchStr = '  const handleGenerateComment = async (postId: string) => {';
const endIndex = socialCode.indexOf('  };\n\n  const handleImageUpload', socialCode.indexOf(searchStr)) + 4;
const targetText = socialCode.substring(socialCode.indexOf(searchStr), endIndex);

const newSocialCommentGen = `  const handleGenerateComment = async (postId: string) => {
    const post = socialPosts.find(p => p.id === postId);
    if (!post) return;
    
    // Valid contacts for commenting
    const validContacts = contacts.filter(c => c.id !== 'user');
    if (validContacts.length === 0) return alert('Hãy tạo ít nhất một nhân vật (contact) để sử dụng tính năng này!');
    
    setIsGeneratingComment(true);
    
    try {
      // Pick randomly 3-5 unique contacts
      let shuffled = [...validContacts].sort(() => 0.5 - Math.random());
      const selectedContacts = shuffled.slice(0, Math.floor(Math.random() * 3) + 3);
      
      const contactsData = selectedContacts.map(c => '- ID: ' + c.id + ' | Tên: ' + c.name + '| Tính cách: ' + c.personalityParams).join('\\n');
      const authorText = post.authorId === 'user' ? 'Tôi' : (contacts.find(c => c.id === post.authorId)?.name || 'Một người');
      
      const msgs = currentCharacter ? (messagesByContact[currentCharacter.id] || []) : [];
      const history = msgs.slice(-5).map(m => \`\${m.role === 'user' ? 'Tôi' : currentCharacter?.name}: \${m.content}\`).join('\\n');
      
      const prompt = \`Bài đăng của "\${authorText}": "\${post.content}"
\\nCác nhân vật bạn bè (bình luận viên):
\${contactsData}
\\nLịch sử (để tham khảo): \${history}
\\nYÊU CẦU:
1. Đóng vai các nhân vật trên, mỗi người viết 1 bình luận cho bài đăng. (Tổng cộng \${selectedContacts.length} bình luận).
2. Từng người bình luận phải ĐÚNG TÍNH CÁCH. KHÔNG được nhắn quá ngắn cụt lủn (kiểu: "hay quá", "tuyệt"), mà phải nói vài câu tự nhiên giống thật.
TRẢ VỀ JSON DUY NHẤT: { "comments": [{ "contactId": "id", "content": "..." }] }\`;

      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data: any = { comments: [] };
      try {
         data = JSON.parse(response.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/gi, '').trim());
      } catch (e) {}

      if (data.comments && Array.isArray(data.comments)) {
        data.comments.forEach((c: any, index: number) => {
           setTimeout(() => {
              addCommentToPost(postId, {
                id: Date.now().toString() + Math.random(),
                authorId: c.contactId,
                content: c.content,
                timestamp: new Date().toISOString()
              });
           }, index * 1800);
        });
      }
    } catch(err) {
      console.error(err);
    } finally {
      setTimeout(() => setIsGeneratingComment(false), 2000);
    }
  };`;

if (endIndex > 0) {
    if (socialCode.includes(targetText)) {
       socialCode = socialCode.replace(targetText, newSocialCommentGen);
       fs.writeFileSync('src/components/apps/SocialScreen.tsx', socialCode);
       console.log("SocialScreen updated!");
    } else {
       console.log("Could not find exact text in social screen.");
    }
} else {
    console.log("End index not found for Social Screen");
}


// FORUM SCREEN
let forumCode = fs.readFileSync('src/components/apps/ForumScreen.tsx', 'utf8');
const searchStrF = '  const handleAIGenerateComment = async () => {';
const endIndexF = forumCode.indexOf('  };\n\n  const handleAddComment', forumCode.indexOf(searchStrF)) + 4;
const targetTextF = forumCode.substring(forumCode.indexOf(searchStrF), endIndexF);

const newForumCommentGen = `  const handleAIGenerateComment = async () => {
    if (!selectedPostId) return;
    setIsGeneratingComment(true);
    
    try {
      const postContent = selectedPost?.content || '';
      const prompt = \`Có bài đăng sau trên diễn đàn ẩn danh (như Reddit/VOZ/Threads): "\${postContent}".
YÊU CẦU:
1. Tạo 3-5 bình luận phản hồi từ người lạ. Mỗi người 1 bình luận (không comment liên tiếp 1 người).
2. Mỗi bình luận mang 1 cá tính khác biệt (ví dụ: khịa, đồng tình, chia sẻ thêm kinh nghiệm, tò mò).
3. Bình luận KHÔNG được quá ngắn, dài tầm 2-4 câu, phải tự nhiên giống một cộng đồng thật. Liên quan chặt chẽ đến bài viết! Khác biệt hoàn toàn nhau.
TRẢ VỀ ĐÚNG ĐỊNH DẠNG JSON (KHÔNG MARKDOWN): { "comments": ["ý kiến 1", "ý kiến 2", "ý kiến 3", "ý kiến 4"] }\`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let arr = ["Bài này hay đấy!", "Quan điểm của mình hơi khác chút...", "Thực sự thì cũng hợp lý", "Haha chủ thớt vui tính thế"];
      try {
        const parsed: any = JSON.parse(response.replace(/[\`]{3}json/g,'').replace(/[\`]{3}/g,'').trim());
        if (parsed.comments && Array.isArray(parsed.comments)) {
          arr = parsed.comments;
        }
      } catch (e) { }
      
      const keys = Object.keys(MOCK_AUTHORS);
      arr.forEach((content, i) => {
        const randomAuthor = keys[Math.floor(Math.random() * keys.length)];
        const delay = i * 1500;
        setTimeout(() => {
           addCommentToForumPost(selectedPostId, {
             id: \`comment-ai-\${Date.now()}-\${i}\`,
             authorId: randomAuthor,
             content: content,
             timestamp: new Date().toISOString(),
             likes: Math.floor(Math.random() * 20)
           });
        }, delay);
      });
      setTimeout(() => setIsGeneratingComment(false), arr.length * 1500 + 500);
      setToastMessage(\`Đã tạo \${arr.length} bình luận mới\`);
      setTimeout(() => setToastMessage(null), 2000);
    } catch (err) {
      console.error(err);
      setIsGeneratingComment(false);
      setToastMessage('Có lỗi xảy ra');
      setTimeout(() => setToastMessage(null), 2000);
    }
  };`;

if (endIndexF > 0) {
    if (forumCode.includes(targetTextF)) {
        forumCode = forumCode.replace(targetTextF, newForumCommentGen);
        fs.writeFileSync('src/components/apps/ForumScreen.tsx', forumCode);
        console.log("ForumScreen updated!");
    } else {
        console.log("Could not find exact string in forum screen.\nTarget text was:\n", targetTextF);
    }
}
