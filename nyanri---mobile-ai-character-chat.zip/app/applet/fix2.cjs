const fs = require('fs');

let socialCode = fs.readFileSync('src/components/apps/SocialScreen.tsx', 'utf8');

const socialCommentGenRegex = /const handleGenerateComment = async \(postId: string\) => \{([\s\S]*?)\} catch\(err\) \{[\s\S]*?\}\s*\}[\s\S]*?\s*\};/m;

const newSocialCommentGen = `const handleGenerateComment = async (postId: string) => {
    const post = socialPosts.find(p => p.id === postId);
    if (!post) return;
    
    const validContacts = contacts.filter(c => c.id !== 'user');
    if (validContacts.length === 0) return alert('Hãy tạo ít nhất một nhân vật để bình luận!');
    
    setIsGeneratingComment(true);
    
    try {
      const contactsData = validContacts.map(c => '- ID: ' + c.id + ' | Tên: ' + c.name + '| Tính cách: ' + c.personalityParams).join('\\n');
      const authorText = post.authorId === 'user' ? 'Tôi' : (contacts.find(c => c.id === post.authorId)?.name || 'Một người');
      
      const msgs = currentCharacter ? (messagesByContact[currentCharacter.id] || []) : [];
      const history = msgs.slice(-5).map(m => \`\${m.role === 'user' ? 'Tôi' : currentCharacter?.name}: \${m.content}\`).join('\\n');
      
      const prompt = \`Bài đăng mạng xã hội của "\${authorText}": "\${post.content}"
\\nThông tin bạn bè:
\${contactsData}
\\nLịch sử trò chuyện gần đây (để tham khảo xưng hô nếu cần): \${history}
\\nYÊU CẦU:
1. Chọn ngẫu nhiên 3-5 nhân vật khác nhau (dùng ID) hợp lý nhất để bình luận về bài viết này.
2. Bình luận KHÔNG được quá ngắn. Phải thể hiện ĐÚNG TÍNH CÁCH của nhân vật đó. Tự nhiên, giống người thật đang dùng mạng xã hội, nói nhiều câu nếu cần. Không dùng comment liên tiếp từ 1 người.
3. Liên quan trực tiếp đến nội dung bài đăng. Không bình luận hời hợt.
TRẢ VỀ JSON DUY NHẤT (không dùng markdown): { "comments": [{ "contactId": "id", "content": "nội dung" }] }\`;

      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data: any = { comments: [] };
      try {
         data = JSON.parse(response.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/gi, '').trim());
      } catch (e) {}

      if (data.comments && Array.isArray(data.comments)) {
        data.comments.forEach((c: any, index: number) => {
           const delay = index * 1500; // staggered locally
           setTimeout(() => {
              addCommentToPost(postId, {
                id: Date.now().toString() + Math.random(),
                authorId: c.contactId,
                content: c.content,
                timestamp: new Date().toISOString()
              });
           }, delay);
        });
      }
    } catch(err) {
      console.error(err);
    } finally {
      setTimeout(() => setIsGeneratingComment(false), 2000);
    }
  };`;

// Replace finding bounds manually to be safe
const searchStr = '  const handleGenerateComment = async (postId: string) => {';
const endIndex = socialCode.indexOf('  };', socialCode.indexOf(searchStr)) + 4;
if (endIndex > 0) {
    const targetText = socialCode.substring(socialCode.indexOf(searchStr), endIndex);
    socialCode = socialCode.replace(targetText, newSocialCommentGen);
    fs.writeFileSync('src/components/apps/SocialScreen.tsx', socialCode);
    console.log("SocialScreen updated!");
}


let forumCode = fs.readFileSync('src/components/apps/ForumScreen.tsx', 'utf8');
const searchStrF = '  const handleAIGenerateComment = async () => {';
const endIndexF = forumCode.indexOf('  };', forumCode.indexOf(searchStrF)) + 4;

const newForumCommentGen = `  const handleAIGenerateComment = async () => {
    if (!selectedPostId) return;
    setIsGeneratingComment(true);
    
    try {
      const postContent = selectedPost?.content || '';
      const prompt = \`Có bài đăng sau trên diễn đàn ẩn danh (như Reddit/VOZ/Threads): "\${postContent}".
YÊU CẦU:
1. Tạo 3-5 bình luận phản hồi từ người lạ. Mỗi người 1 bình luận (không comment liên tiếp 1 người).
2. Mỗi bình luận mang 1 cá tính khác biệt (ví dụ: khịa, đồng tình, chia sẻ thêm kinh nghiệm, tò mò).
3. Bình luận KHÔNG được quá ngắn, dài tầm 2-4 câu, phải tự nhiên giống một cộng đồng thật. Liên quan chặt chẽ đến bài viết! Khác biệt hoàn toàn nhau.
TRẢ VỀ ĐÚNG ĐỊNH DẠNG JSON (KHÔNG MARKDOWN): { "comments": ["ý kiến 1", "ý kiến 2", "ý kiến 3", "ý kiến 4"] }\`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let arr = ["Bài này hay đấy!", "Quan điểm của mình hơi khác chút...", "Thực sự thì cũng hợp lý", "Haha chủ thớt vui tính thế"];
      try {
        const parsed: any = JSON.parse(response.replace(/[\`]{3}json/g,'').replace(/[\`]{3}/g,'').trim());
        if (parsed.comments && Array.isArray(parsed.comments)) {
          arr = parsed.comments;
        }
      } catch (e) { }
      
      const keys = Object.keys(MOCK_AUTHORS);
      arr.forEach((content, i) => {
        const randomAuthor = keys[Math.floor(Math.random() * keys.length)];
        const delay = i * 1500;
        setTimeout(() => {
           addCommentToForumPost(selectedPostId, {
             id: \`comment-ai-\${Date.now()}-\${i}\`,
             authorId: randomAuthor,
             content: content,
             timestamp: new Date().toISOString(),
             likes: Math.floor(Math.random() * 20)
           });
        }, delay);
      });
      setTimeout(() => setIsGeneratingComment(false), arr.length * 1500 + 500);
    } catch (err) {
      console.error(err);
      setIsGeneratingComment(false);
    }
  };`;

if (endIndexF > 0) {
    const targetTextF = forumCode.substring(forumCode.indexOf(searchStrF), endIndexF);
    forumCode = forumCode.replace(targetTextF, newForumCommentGen);
    fs.writeFileSync('src/components/apps/ForumScreen.tsx', forumCode);
    console.log("ForumScreen updated!");
}
