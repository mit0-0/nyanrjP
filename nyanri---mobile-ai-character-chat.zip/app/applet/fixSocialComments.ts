const fs = require('fs');

let socialCode = fs.readFileSync('src/components/apps/SocialScreen.tsx', 'utf8');
const searchStr = '  const handleGenerateComment = async (postId: string) => {';
const endIndex = socialCode.indexOf('  };', socialCode.indexOf(searchStr)) + 4;
const targetText = socialCode.substring(socialCode.indexOf(searchStr), endIndex);

const newSocialCommentGen = `  const handleGenerateComment = async (postId: string) => {
    const post = socialPosts.find(p => p.id === postId);
    if (!post) return;
    
    // Valid contacts for commenting
    const validContacts = contacts.filter(c => c.id !== 'user');
    if (validContacts.length === 0) return alert('Hãy tạo ít nhất một nhân vật (contact) để sử dụng tính năng này!');
    
    setIsGeneratingComment(true);
    
    try {
      // Pick randomly 3-5 unique contacts
      let shuffled = [...validContacts].sort(() => 0.5 - Math.random());
      const selectedContacts = shuffled.slice(0, Math.floor(Math.random() * 3) + 3);
      
      const contactsData = selectedContacts.map(c => '- ID: ' + c.id + ' | Tên: ' + c.name + '| Tính cách: ' + c.personalityParams).join('\\n');
      const authorText = post.authorId === 'user' ? 'Tôi' : (contacts.find(c => c.id === post.authorId)?.name || 'Một người');
      
      const msgs = currentCharacter ? (messagesByContact[currentCharacter.id] || []) : [];
      const history = msgs.slice(-5).map(m => \`\${m.role === 'user' ? 'Tôi' : currentCharacter?.name}: \${m.content}\`).join('\\n');
      
      const prompt = \`Bài đăng của "\${authorText}": "\${post.content}"
\\nCác nhân vật bạn bè (bình luận viên):
\${contactsData}
\\nLịch sử (để tham khảo): \${history}
\\nYÊU CẦU:
1. Đóng vai các nhân vật trên, mỗi người viết 1 bình luận cho bài đăng. (Tổng cộng \${selectedContacts.length} bình luận).
2. Từng người bình luận phải ĐÚNG TÍNH CÁCH. KHÔNG được nhắn quá ngắn cụt lủn (kiểu: "hay quá", "tuyệt"), mà phải nói vài câu tự nhiên giống thật.
TRẢ VỀ JSON DUY NHẤT: { "comments": [{ "contactId": "id", "content": "..." }] }\`;

      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data: any = { comments: [] };
      try {
         data = JSON.parse(response.replace(/[\\\`]{3}json/gi, '').replace(/[\\\`]{3}/gi, '').trim());
      } catch (e) {}

      if (data.comments && Array.isArray(data.comments)) {
        data.comments.forEach((c: any, index: number) => {
           setTimeout(() => {
              addCommentToPost(postId, {
                id: Date.now().toString() + Math.random(),
                authorId: c.contactId,
                content: c.content,
                timestamp: new Date().toISOString()
              });
           }, index * 1800);
        });
      }
    } catch(err) {
      console.error(err);
    } finally {
      setTimeout(() => setIsGeneratingComment(false), 2000);
    }
  };`;

if (endIndex > 0) {
    socialCode = socialCode.replace(targetText, newSocialCommentGen);
    fs.writeFileSync('src/components/apps/SocialScreen.tsx', socialCode);
    console.log("SocialScreen updated!");
}
