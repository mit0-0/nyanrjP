import { useState, useRef } from 'react';
import AppLayout from './AppLayout';
import { useAppStore, DailyLogPost, DailyLogComment } from '../../store/useAppStore';
import { ArrowLeft, MoreHorizontal, MessageSquare, Heart, Plus, Camera, Send, X } from 'lucide-react';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';
import { generateGeminiResponse } from '../../services/geminiService';

export default function DailyLogScreen() {
  const { 
    dailyLogProfile, 
    updateDailyLogProfile, 
    dailyLogPosts, 
    addDailyLogPost, 
    toggleLikeDailyLogPost, 
    addCommentToDailyLogPost,
    contacts,
  } = useAppStore();

  const [isCreatingPost, setIsCreatingPost] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostImage, setNewPostImage] = useState('');
  const [editingProfile, setEditingProfile] = useState(false);
  
  const [tempProfile, setTempProfile] = useState(dailyLogProfile);
  
  const [commentingPostId, setCommentingPostId] = useState<string | null>(null);
  const [newComment, setNewComment] = useState('');
  const [replyToId, setReplyToId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const handleCreatePost = () => {
    if (!newPostContent.trim() && !newPostImage) return;

    const post: DailyLogPost = {
      id: Date.now().toString(),
      authorId: 'user',
      content: newPostContent,
      image: newPostImage || undefined,
      timestamp: new Date().toISOString(),
      likes: [],
      comments: []
    };

    addDailyLogPost(post);
    setNewPostContent('');
    setNewPostImage('');
    setIsCreatingPost(false);

    // Simulate character reactions
    setTimeout(() => {
      contacts.forEach(contact => {
        if (Math.random() > 0.5) {
          setTimeout(() => {
            toggleLikeDailyLogPost(post.id, contact.id);
          }, Math.random() * 5000 + 2000);
        }
        
        if (Math.random() > 0.7) {
          setTimeout(async () => {
             try {
                const response = await generateGeminiResponse(`
You are ${contact.name}, a ${contact.gender} character.
Background: ${contact.background}
Personality: ${contact.personalityParams}

Your friend just posted this on their social media (daily log): "${newPostContent}"
Write a short, natural, in-character comment (max 15 words) about this post.
Do NOT use quotes holding your text. Be concise, use emojis when natural.
                `, []);
                const comment: DailyLogComment = {
                  id: Date.now().toString() + Math.random(),
                  authorId: contact.id,
                  content: response.content || "Awesome! 🌸",
                  timestamp: new Date().toISOString()
                };
                addCommentToDailyLogPost(post.id, comment);
             } catch (e) {
                console.error(e);
             }
          }, Math.random() * 8000 + 4000);
        }
      });
    }, 1000);
  };

  const handlePostComment = () => {
    if (!newComment.trim() || !commentingPostId) return;

    const comment: DailyLogComment = {
      id: Date.now().toString(),
      authorId: 'user',
      content: newComment,
      timestamp: new Date().toISOString(),
      replyToId: replyToId || undefined
    };

    addCommentToDailyLogPost(commentingPostId, comment);
    setNewComment('');
    setCommentingPostId(null);
    setReplyToId(null);
  };

  const getAuthorDisplay = (id: string) => {
    if (id === 'user') return { name: dailyLogProfile.name, avatar: dailyLogProfile.avatar };
    const contact = contacts.find(c => c.id === id);
    return contact ? { name: contact.name, avatar: contact.avatar } : { name: 'Unknown', avatar: '' };
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setNewPostImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setTempProfile(p => ({...p, banner: reader.result as string}));
      reader.readAsDataURL(file);
    }
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setTempProfile(p => ({...p, avatar: reader.result as string}));
      reader.readAsDataURL(file);
    }
  };

  const saveProfile = () => {
    updateDailyLogProfile(tempProfile);
    setEditingProfile(false);
  };

  return (
    <div className="absolute inset-0 bg-[#F5F6F8] overflow-y-auto no-scrollbar font-sans"
         style={{ backgroundImage: 'radial-gradient(#E5E7EB 1px, transparent 0)', backgroundSize: '24px 24px' }}>
      
      {/* Cover Header */}
      <div className="relative w-full h-[320px] bg-white border-b border-gray-100">
        <img src={dailyLogProfile.banner} className="w-full h-full object-cover opacity-90 mix-blend-luminosity" alt="banner" />
        
        {/* Top bar */}
        <div className="absolute top-10 w-full px-4 flex justify-between z-20">
          <button className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-gray-700 active:scale-95 transition-transform" onClick={() => window.history.back()}>
             <ArrowLeft size={20} />
          </button>
          <button className="w-12 h-12 bg-black/40 backdrop-blur-md rounded-full flex items-center justify-center shadow-sm text-white active:scale-95 transition-transform" onClick={() => setEditingProfile(true)}>
             <MoreHorizontal size={20} />
          </button>
        </div>

        {/* daily log text */}
        <div className="absolute bottom-4 left-6 text-white drop-shadow-md z-10">
           <h1 className="text-[28px] font-serif italic tracking-wide text-white" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>daily log</h1>
        </div>

        {/* Circle Plus Button */}
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 z-20">
          <div className="p-1.5 bg-[#F5F6F8] rounded-full">
            <button 
              onClick={() => setIsCreatingPost(true)}
              className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm border border-gray-100 text-gray-800 hover:text-black active:scale-95 transition-transform"
            >
              <Plus size={24} />
            </button>
          </div>
        </div>

        {/* Profile Avatar Overlapping */}
        <div className="absolute -bottom-10 right-6 z-20">
          <div className="w-[100px] h-[100px] bg-white rounded-[24px] p-1.5 shadow-sm">
            <img src={dailyLogProfile.avatar} className="w-full h-full object-cover rounded-[18px]" alt="avatar" />
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="relative px-4 pt-16 pb-24 max-w-lg mx-auto">
        {/* Posts */}
        <div className="space-y-8">
          {dailyLogPosts.length === 0 ? (
            <div className="text-center py-20 text-gray-400 font-serif italic">
              chưa có bài viết nào...
            </div>
          ) : (
            dailyLogPosts.map((post, index) => {
              const author = getAuthorDisplay(post.authorId);
              const isLiked = post.likes.includes('user');

              return (
                <div key={post.id} className="bg-white rounded-xl shadow-[0_2px_10px_rgba(0,0,0,0.02)] border border-gray-100 relative">
                  {/* Fake pin at top center */}
                  <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-8 h-3 bg-gray-100/80 rounded-md border border-gray-200"></div>
                  
                  {/* Post Number */}
                  <div className="absolute top-4 right-4 text-gray-300 font-serif text-sm italic">
                    No.{dailyLogPosts.length - index}
                  </div>

                  <div className="p-5">
                    {/* Post Header */}
                    <div className="flex gap-4 items-center mb-5">
                      <div className="w-[52px] h-[52px] rounded-full overflow-hidden shrink-0 border border-gray-100 p-0.5">
                        <img src={author.avatar} alt="author" className="w-full h-full object-cover rounded-full" />
                      </div>
                      <div className="flex-grow">
                        <div className="font-bold text-[#3A3A3A] text-[16px] mb-0.5">{author.name}</div>
                        <div className="text-gray-400 text-[12px] font-mono tracking-widest uppercase">{format(new Date(post.timestamp), 'yyyy-MM-dd HH:mm')}</div>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600 mb-4"><MoreHorizontal size={18} /></button>
                    </div>

                    {/* Post Content */}
                    <div className="mb-6">
                      <p className="text-[#3A3A3A] text-[15px] whitespace-pre-wrap leading-[1.8] font-medium mb-4">{post.content}</p>
                      {post.image && (
                        <div className="rounded-lg overflow-hidden max-h-[400px]">
                          <img src={post.image} alt="post media" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>

                    {/* Post Actions (Dotted top border) */}
                    <div className="flex items-center justify-end gap-6 pt-4 pb-2 mb-4 border-t border-gray-200 border-dashed">
                      <button 
                        onClick={() => toggleLikeDailyLogPost(post.id, 'user')}
                        className={cn("flex items-center gap-1.5 font-bold text-[15px] transition-colors", isLiked ? "text-pink-500" : "text-gray-500 hover:text-gray-700")}
                      >
                        <Heart size={18} className={cn(isLiked && "fill-current")} /> Thích
                      </button>
                      <button 
                        onClick={() => { setCommentingPostId(post.id); setReplyToId(null); }}
                        className="flex items-center gap-1.5 font-bold text-[15px] text-gray-500 hover:text-gray-700 transition-colors"
                      >
                        <MessageSquare size={18} /> Bình luận
                      </button>
                    </div>

                    {/* Interaction Area (Likes & Comments) */}
                    {(post.likes.length > 0 || post.comments.length > 0) && (
                      <div className="bg-[#F8F9FA] rounded-md p-4">
                        
                        {/* Likes row */}
                        {post.likes.length > 0 && (
                          <div className="flex flex-wrap items-center gap-2 mb-3">
                            <Heart size={14} className="text-pink-400 fill-pink-400 mr-2" />
                            {post.likes.map(likerId => {
                              const liker = getAuthorDisplay(likerId);
                              return (
                                <img key={likerId} src={liker.avatar} title={liker.name} className="w-5 h-5 rounded-full border border-gray-200 object-cover" />
                              );
                            })}
                          </div>
                        )}

                        {/* Divider between likes and comments if both exist */}
                        {post.likes.length > 0 && post.comments.length > 0 && (
                          <div className="border-t border-gray-200/60 border-dashed mb-3"></div>
                        )}

                        {/* Comments list */}
                        <div className="space-y-3">
                          {post.comments.map(comment => {
                            const cAuthor = getAuthorDisplay(comment.authorId);
                            let replyName = '';
                            if (comment.replyToId) {
                              const parentComment = post.comments.find(c => c.id === comment.replyToId);
                              if (parentComment) {
                                replyName = getAuthorDisplay(parentComment.authorId).name;
                              }
                            }

                            return (
                              <div 
                                key={comment.id} 
                                className="text-[14px] leading-relaxed cursor-pointer group flex items-start gap-2 border-b border-gray-200/50 border-dashed pb-2 last:border-0 last:pb-0"
                                onClick={() => {
                                  setCommentingPostId(post.id);
                                  setReplyToId(comment.id);
                                }}
                              >
                                <img src={cAuthor.avatar} className="w-5 h-5 rounded-full border border-gray-200 object-cover shrink-0 mt-0.5" />
                                <div>
                                  <span className="font-bold text-[#3A3A3A]">{cAuthor.name}</span>
                                  {replyName && <span className="text-gray-500 mx-1">đã trả lời</span>}
                                  {replyName && <span className="font-bold text-gray-700">{replyName}</span>}
                                  <span className="mx-1">:</span>
                                  <span className="text-[#3A3A3A]">{comment.content}</span>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                      </div>
                    )}

                    {/* Comment Input inline if replying */}
                    {commentingPostId === post.id && (
                      <div className="mt-4 flex items-center gap-2 bg-gray-50 rounded-md p-1 border border-gray-200">
                         <input 
                           autoFocus
                           type="text"
                           value={newComment}
                           onChange={(e) => setNewComment(e.target.value)}
                           placeholder={replyToId ? "Trả lời..." : "Bình luận..."}
                           className="flex-grow bg-transparent outline-none px-3 py-1.5 text-sm text-gray-800"
                           onKeyDown={(e) => {
                             if (e.key === 'Enter') handlePostComment();
                           }}
                         />
                         <button 
                           onClick={handlePostComment}
                           disabled={!newComment.trim()}
                           className="p-1.5 px-3 bg-black text-white rounded text-xs font-bold disabled:opacity-50"
                         >
                           Gửi
                         </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Editing Profile Modal */}
      {editingProfile && (
        <div className="absolute inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-[24px] p-6 shadow-xl animate-in zoom-in-95">
             <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-lg font-serif">thiết lập</h3>
                <button onClick={() => setEditingProfile(false)} className="p-1 text-gray-400 hover:text-gray-700 bg-gray-100 rounded-full"><X size={20}/></button>
             </div>

             <div className="space-y-5">
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-2">tên hiển thị</label>
                  <input type="text" value={tempProfile.name} onChange={e => setTempProfile(p => ({...p, name: e.target.value}))} className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 outline-none focus:border-pink-300 font-medium" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-2">ảnh bìa (cover)</label>
                  <div className="w-full h-24 rounded-xl overflow-hidden border-2 border-dashed border-gray-200 relative cursor-pointer group" onClick={() => bannerInputRef.current?.click()}>
                     <img src={tempProfile.banner} className="w-full h-full object-cover" />
                     <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><Camera className="text-white"/></div>
                  </div>
                  <input type="file" ref={bannerInputRef} className="hidden" accept="image/*" onChange={handleBannerUpload} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-2">avatar</label>
                  <div className="w-16 h-16 rounded-[16px] overflow-hidden border-2 border-dashed border-gray-200 relative cursor-pointer group" onClick={() => avatarInputRef.current?.click()}>
                     <img src={tempProfile.avatar} className="w-full h-full object-cover" />
                     <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><Camera className="text-white"/></div>
                  </div>
                  <input type="file" ref={avatarInputRef} className="hidden" accept="image/*" onChange={handleAvatarUpload} />
                </div>
             </div>

             <button onClick={saveProfile} className="w-full mt-8 bg-black text-white rounded-xl py-3 font-bold hover:bg-gray-800 transition-colors">Lưu</button>
          </div>
        </div>
      )}

      {/* Creating Post Modal */}
      {isCreatingPost && (
        <div className="absolute inset-0 bg-[#F5F6F8] z-[100] flex flex-col animate-in slide-in-from-bottom">
           <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200">
              <button onClick={() => setIsCreatingPost(false)} className="text-gray-500 font-bold hover:text-black">Hủy</button>
              <h2 className="font-bold text-lg font-serif">nhật ký mới</h2>
              <button 
                onClick={handleCreatePost}
                disabled={!newPostContent.trim() && !newPostImage}
                className="bg-black text-white px-5 py-2 rounded-full font-bold text-sm disabled:opacity-50 transition-all hover:bg-gray-800"
              >
                Đăng
              </button>
           </div>
           
           <div className="p-4 flex-grow flex flex-col gap-4 max-w-lg mx-auto w-full">
              <div className="bg-white rounded-[24px] p-5 shadow-sm border border-gray-100">
                <textarea 
                  value={newPostContent}
                  onChange={e => setNewPostContent(e.target.value)}
                  placeholder="Chia sẻ khoảnh khắc hôm nay..."
                  className="w-full text-[16px] outline-none resize-none font-medium text-gray-800 h-32 placeholder-gray-400"
                  autoFocus
                ></textarea>

                {newPostImage ? (
                  <div className="relative w-full rounded-xl overflow-hidden border border-gray-200 mt-2">
                    <img src={newPostImage} className="w-full object-cover max-h-[300px]" alt="preview" />
                    <button onClick={() => setNewPostImage('')} className="absolute top-2 right-2 p-1.5 bg-black/50 backdrop-blur-sm text-white rounded-full hover:bg-black transition-colors"><X size={16}/></button>
                  </div>
                ) : (
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="w-20 h-20 bg-gray-50 border-2 border-dashed border-gray-200 rounded-2xl flex flex-col items-center justify-center text-gray-400 hover:text-gray-700 hover:bg-gray-100 hover:border-gray-300 transition-all mt-2"
                  >
                    <Camera size={24} className="mb-1" />
                    <span className="text-[10px] font-bold uppercase tracking-wider">Ảnh</span>
                  </button>
                )}
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
              </div>
           </div>
        </div>
      )}

    </div>
  );
}