const fs = require('fs');
let code = fs.readFileSync('src/components/apps/DailyLogScreen.tsx', 'utf8');

const regex = /setTimeout\(\(\) => \{\s*contacts\.forEach\(contact => \{([\s\S]*?)}\);\s*\}, 1000\);/;
const replacement = `
setTimeout(async () => {
      // 1. Simulate likes for 30-50% of contacts
      contacts.forEach(contact => {
        if (Math.random() > 0.5) {
          setTimeout(() => {
            toggleLikeDailyLogPost(post.id, contact.id);
          }, Math.random() * 5000 + 2000);
        }
      });

      // 2. Generate exactly 3-5 comments and 1-2 DMs in ONE AI CALL
      // Filter out 'user' contact if any, just in case
      const validContacts = contacts.filter(c => c.id !== 'user');
      if (validContacts.length === 0) return;

      const prompt = \`Bạn của những nhân vật sau vừa đăng bài trên News Feed (Nhật ký): "\${postContentStore}".

Thông tin các nhân vật (bạn bè):
\${validContacts.map(c => \`- ID: \${c.id} | Tên: \${c.name} | Giới tính: \${c.gender}
  Bối cảnh: \${c.background}
  Tính cách (CỰC KỲ QUAN TRỌNG, phải tuân thủ nghiêm ngặt): \${c.personalityParams}\`).join('\\n\\n')}

YÊU CẦU:
1. Chọn ngẫu nhiên 3 đến 5 nhân vật khác nhau để "Bình luận" về bài đăng này. 
   - Bình luận phải CỰC KỲ ĐÚNG VỚI TÍNH CÁCH VÀ BỐI CẢNH của mỗi người. 
   - Dưới 15 chữ. Không dùng ngoặc kép. Tự nhiên như bạn bè. GỌI TÊN CỦA USER NẾU CẦN.
2. Chọn ngẫu nhiên 1 đến 2 nhân vật (có thể trùng hoặc không trùng với người đã bình luận) để "Nhắn tin riêng (DM)" phản hồi về bài đăng này. Mở đầu câu chuyện.

TRẢ VỀ ĐÚNG ĐỊNH DẠNG JSON (KHÔNG BỎ VÀO MARKDOWN, CHỈ CÓ JSON):
{
  "comments": [ { "contactId": "id_nhan_vat", "content": "nội dung bình luận" } ],
  "dms": [ { "contactId": "id_nhan_vat", "content": "nội dung DM" } ]
}\`;

      try {
        const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
        let data: any = { comments: [], dms: [] };
        try {
           data = JSON.parse(response.replace(/\`\`\`json/gi, '').replace(/\`\`\`/gi, '').trim());
        } catch (e) {
           console.error("JSON parse error from DailyLog AI:", e);
        }

        // Apply generated comments with staggered delays
        if (data.comments && Array.isArray(data.comments)) {
          data.comments.forEach((c: any) => {
             const delay = Math.random() * 8000 + 3000;
             setTimeout(() => {
                const comment: DailyLogComment = {
                  id: Date.now().toString() + Math.random(),
                  authorId: c.contactId,
                  content: c.content,
                  timestamp: new Date().toISOString()
                };
                addCommentToDailyLogPost(post.id, comment);
             }, delay);
          });
        }

        // Apply generated DMs with slightly longer staggered delays
        if (data.dms && Array.isArray(data.dms)) {
          data.dms.forEach((dm: any) => {
             const delay = Math.random() * 10000 + 8000;
             setTimeout(() => {
                const message: Message = {
                  id: Date.now().toString() + Math.random(),
                  contactId: dm.contactId,
                  authorId: dm.contactId,
                  content: dm.content,
                  timestamp: new Date().toISOString(),
                  type: 'text'
                };
                addMessage(message);
             }, delay);
          });
        }
      } catch (err) {
         console.error("Failed to generate Daily Log interactions:", err);
      }
    }, 1000);`;

code = code.replace(regex, replacement);
fs.writeFileSync('src/components/apps/DailyLogScreen.tsx', code);
