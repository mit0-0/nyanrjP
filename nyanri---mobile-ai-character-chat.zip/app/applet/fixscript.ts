const fs = require('fs');
let code = fs.readFileSync('src/components/apps/DailyLogScreen.tsx', 'utf8');
const searchStr = 'setTimeout(() => {\n      contacts.forEach(contact => {\n        if (Math.random() > 0.4) {';
const endIndex = code.indexOf('    }, 1000);', code.indexOf(searchStr)) + 13;
const targetText = code.substring(code.indexOf(searchStr), endIndex);

const replacement = `setTimeout(async () => {
      // 1. Simulate likes for 30-50% of contacts
      contacts.forEach(contact => {
        if (Math.random() > 0.5) {
          setTimeout(() => {
            toggleLikeDailyLogPost(post.id, contact.id);
          }, Math.random() * 5000 + 2000);
        }
      });

      // 2. Generate exactly 3-5 comments and 1-2 DMs in ONE AI CALL
      // Filter out 'user' contact just in case
      const validContacts = contacts.filter(c => c.id !== 'user');
      if (validContacts.length === 0) return;

      const contactsData = validContacts.map(c => 
         '- ID: ' + c.id + ' | Tên: ' + c.name + '| TT: ' + c.personalityParams
      ).join('\\n');

      const prompt = 'Bạn của những người sau vừa đăng status: "' + postContentStore + '" \\n\\n' + contactsData + ' \\n\\n' + 
      'YÊU CẦU:\\n 1. Chọn 3-5 nhân vật bình luận. Bình luận phải CỰC KỲ GIỐNG tính cách của nhân vật.\\n 2. Chọn 1-2 người nhắn tin riêng DM phản hồi (mở đầu tin nhắn).\\n TRẢ VỀ JSON DUY NHẤT: { "comments": [{ "contactId": "id", "content": "..."}], "dms": [{ "contactId": "id", "content": "..."}] } KHÔNG Markdown.';

      try {
        const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
        let data: any = { comments: [], dms: [] };
        try {
           data = JSON.parse(response.replace(/[\`]{3}json/gi, '').replace(/[\`]{3}/gi, '').trim());
        } catch (e) {}

        if (data.comments) {
          data.comments.forEach((c: any) => {
             const delay = Math.random() * 8000 + 3000;
             setTimeout(() => {
                const comment: DailyLogComment = { id: Date.now().toString() + Math.random(), authorId: c.contactId, content: c.content, timestamp: new Date().toISOString() };
                addCommentToDailyLogPost(post.id, comment);
             }, delay);
          });
        }
        if (data.dms) {
          data.dms.forEach((dm: any) => {
             const delay = Math.random() * 10000 + 8000;
             setTimeout(() => {
                const message: Message = { id: Date.now().toString() + Math.random(), contactId: dm.contactId, authorId: dm.contactId, content: dm.content, timestamp: new Date().toISOString(), type: 'text' };
                addMessage(message);
             }, delay);
          });
        }
      } catch (err) {}
    }, 1000);`;

if (!targetText || targetText.length < 50) {
    console.log("Could not find target text!");
    process.exit(1);
}

fs.writeFileSync('src/components/apps/DailyLogScreen.tsx', code.replace(targetText, replacement));
console.log("SUCCESS!");
