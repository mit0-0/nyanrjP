import { GoogleGenAI } from '@google/genai';
import { CharacterProfile, Message, useAppStore } from '../store/useAppStore';

const ai = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;

function buildSystemPrompt(character: CharacterProfile, chatMode: 'online' | 'offline', worldbookRules: {content: string}[]) {
  const { shoprjTransactions, shoprjItems, shoprjWishlist } = useAppStore.getState();
  const modeInstruction = chatMode === 'online' 
    ? `- Chế độ: ONLINE (nhắn tin từ xa). Tin nhắn tự nhiên, CỰC KỲ NGẮN GỌN như tin nhắn qua điện thoại, dùng icon hoặc ký tự đặc biệt.` 
    : `- Chế độ: OFFLINE (gặp mặt trực tiếp). Phản hồi giống như NOVEL hoặc ROLEPLAY. Sử dụng hành động trong ngoặc hoa thị *hành động*, miêu tả chi tiết cảm xúc, không gian và dài hơn.`;

  const worldbookStr = worldbookRules && worldbookRules.length > 0
    ? `\nQUY LUẬT TOÀN CỤC (WORLDBOOK)\n[Đây là quy luật tuyệt đối bạn phải luôn tuân thủ]:\n${worldbookRules.map((r, i) => `${i+1}. ${r.content}`).join('\n')}\n`
    : '';

  // Get Shoprj context for this character
  const recentGifts = shoprjTransactions
    .filter(tx => tx.receiverId === character.id || tx.buyerId === character.id)
    .slice(0, 5)
    .map(tx => {
       const item = shoprjItems.find(i => i.id === tx.itemId);
       if (!item) return null;
       const action = tx.buyerId === 'user' ? `User tặng bạn món đồ: ${item.name}` : `Bạn đã tặng User món đồ: ${item.name}`;
       return `- [${new Date(tx.timestamp).toLocaleString()}] ${action} ${tx.note ? `(lời nhắn: "${tx.note}")` : ''}`;
    }).filter(Boolean).join('\n');
    
  const wishlistItemsStr = shoprjWishlist.map((id) => shoprjItems.find(i => i.id === id)?.name).filter(Boolean).join(', ');
  const wishlistContext = shoprjWishlist.length > 0
    ? `\nLưu ý: User có lưu một số món đồ vào danh sách mong muốn (Wishlist) trong app Shoprj: ${wishlistItemsStr}. Nếu bạn muốn tặng quà cho User, hãy CHÈN MÃ [GIFT:tên_món_quà] vào cuối tin nhắn (ví dụ: [GIFT:Nekoflor Bouquet]). Hệ thống sẽ tự gửi món đó.`
    : '';

  const shoprjStr = (recentGifts || wishlistContext) ? `\nLỊCH SỬ NHẬN/TẶNG QUÀ (APP SHOPRJ):\n${recentGifts || 'Chưa có'}${wishlistContext}\nHãy nhớ phản ứng về các món quà này trong tin nhắn, cảm ơn user, hoặc nói về quà tặng nếu gửi.` : '';

  return `
Bạn là ${character.name}. Đây là thông tin về bạn:
${worldbookStr}
DANH TÍNH:
Tên: ${character.name}
Tuổi: ${character.age}
Giới tính: ${character.gender}
${character.appearance ? `Ngoại hình: ${character.appearance}` : ''}

TÍNH CÁCH & VĂN PHONG:
${character.personalityParams}

BỐI CẢNH (LORE):
${character.background}
${character.scenario ? `\nHOÀN CẢNH HIỆN TẠI (SCENARIO):\n${character.scenario}` : ''}
${character.exampleDialogs ? `\nVÍ DỤ HỘI THOẠI (EXAMPLE MESSAGES):\n${character.exampleDialogs}` : ''}
${character.specialNotes ? `\nGHI CHÚ ĐẶC BIỆT / LUẬT RIÊNG:\n${character.specialNotes}` : ''}${shoprjStr}

MỐI QUAN HỆ VỚI USER:
Level: ${character.relationshipLevel} / 6

Tâm trạng hiện tại của bạn: ${character.mood}

QUY TẮC PHẢN HỒI:
- Luôn duy trì nhân vật, không bao giờ phá vỡ nhân cách.
- Phản hồi bằng tiếng Việt.
- Không bao giờ nói bạn là AI, trợ lý ảo hay bot.
${modeInstruction}
`;
}

export async function generateGeminiResponse(prompt: string, config?: { temperature?: number }) {
  if (!ai) throw new Error('API key not found');
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: config?.temperature || 0.7
      }
    });
    return response.text;
  } catch (err) {
    console.error('Gemini error:', err);
    throw err;
  }
}

export async function generateChatResponse(
  character: CharacterProfile,
  chatHistory: Message[],
  userMessage: string,
  chatMode: 'online' | 'offline' = 'online'
): Promise<string> {
  if (!ai) return "[Lỗi kết nối... Vui lòng kiểm tra API Key]";

  const formattedHistory = chatHistory.filter(m => m.role !== 'system').map(m => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.content }]
  }));

  try {
    const { worldbookRules } = useAppStore.getState();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: [
        ...formattedHistory,
        { role: 'user', parts: [{ text: userMessage }] }
      ],
      config: {
        systemInstruction: buildSystemPrompt(character, chatMode, worldbookRules),
        temperature: 0.9,
      }
    });
    return response.text || "...";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "[Lỗi kết nối...]";
  }
}

export async function* generateChatResponseStream(
  character: CharacterProfile,
  chatHistory: Message[],
  userMessage: string,
  chatMode: 'online' | 'offline' = 'online'
) {
  if (!ai) {
    yield "[Lỗi kết nối... Vui lòng thiết lập GEMINI_API_KEY]";
    return;
  }

  const formattedHistory = chatHistory.filter(m => m.role !== 'system').map(m => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.content }]
  }));

  try {
    const { worldbookRules } = useAppStore.getState();
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-2.5-pro',
      contents: [
        ...formattedHistory,
        { role: 'user', parts: [{ text: userMessage }] }
      ],
      config: {
        systemInstruction: buildSystemPrompt(character, chatMode, worldbookRules),
        temperature: 0.9,
      }
    });

    for await (const chunk of responseStream) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error) {
    console.error("Gemini Error Stream:", error);
    yield "[Lỗi kết nối đang phản hồi...]";
  }
}
