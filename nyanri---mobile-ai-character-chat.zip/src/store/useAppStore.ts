import { create } from 'zustand';
import localforage from 'localforage';

// Types
export type ScreenState = 
  | 'splash'
  | 'lock'
  | 'home'
  | 'character-create'
  | 'chat'
  | 'chat-detail'
  | 'diary'
  | 'social'
  | 'bank'
  | 'shoprj'
  | 'music'
  | 'search'
  | 'settings'
  | 'worldbook'
  | 'forum'
  | 'camera'
  | 'contacts'
  | 'daily-log';

export type MoodState = 'vui vẻ' | 'bình thường' | 'buồn' | 'cáu kỉnh' | 'nhớ nhung' | 'ghen tuông' | 'lo lắng' | 'mơ màng';


export interface DailyLogComment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
  replyToId?: string;
}

export interface DailyLogPost {
  id: string;
  authorId: string; // 'user' or character id
  content: string;
  image?: string;
  timestamp: string;
  likes: string[]; // array of author ids who liked
  comments: DailyLogComment[];
}

export interface DailyLogProfile {
  name: string;
  avatar: string;
  banner: string;
}

export interface Message {
  id: string;
  role: 'user' | 'char' | 'system';
  content: string;
  timestamp: string;
  type: 'text' | 'image' | 'transfer' | 'sticker';
}

export interface DiaryEntry {
  id: string;
  authorId: string; // 'user' or character id
  date: string;
  content: string;
  moodTag: string;
  weatherIcon: 'sun' | 'cloud' | 'rain' | 'moon';
}

export interface SocialComment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
}

export interface SocialPost {
  id: string;
  authorId: string;
  content: string;
  image?: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
  comments: SocialComment[];
}

export interface ForumComment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
  likes?: number;
  isLiked?: boolean;
}

export interface ForumPost {
  id: string;
  authorId: string;
  content: string;
  image?: string;
  timestamp: string;
  likes: number;
  isLiked: boolean;
  comments: ForumComment[];
}

export interface ForumProfile {
  name: string;
  avatar: string;
  coverPhoto?: string;
  bio?: string;
  followers: number;
}

export interface CharacterProfile {
  id: string;
  name: string;
  avatar: string; // URL or placeholder
  age: string;
  gender: string;
  appearance?: string; // Physical description
  personalityParams: string; // tags or description
  background: string; // World/history
  scenario?: string; // Current situation/context
  firstMessage?: string; // Greeting message
  exampleDialogs?: string; // Sample chat logs
  specialNotes?: string; // System prompt/extra rules
  mood: MoodState;
  relationshipLevel: number;
  relationshipPoints: number;
}

export interface UserProfile {
  name: string;
  avatar: string;
  socialAvatar?: string;
  chatAvatar?: string;
  status: string;
  badge: string;
  coverPhoto?: string;
  avatarFrame?: string;
  socialStats?: { balance: string, msgs: string, time: string };
}

export interface WorldbookRule {
  id: string;
  title: string;
  content: string;
}

export interface ThemeSettings {
  homeBackground: string;
  appBackground: string;
  appBackgrounds: Record<string, string>;
  chatBackground: string;
  chatBubbleColor: string;
  userFrame?: string;
  characterFrame?: string;
  appFrame?: string;
  appIcons?: Record<string, string>;
  appOrder?: string[];
  homeItems?: string[];
  customPhotoWidgets?: Record<string, string>;
  playerWidgets?: Record<string, { title: string, coverImage: string, thumbnail: string, mediaUrl: string }>;
  statusWidgets?: Record<string, { batteryText: string, nameText: string, subText: string, avatarUrl: string }>;
  setHomeItems: (items: string[]) => void;
  updateCustomPhotoWidget: (id: string, url: string) => void;
  updatePlayerWidget: (id: string, data: { title?: string, coverImage?: string, thumbnail?: string, mediaUrl?: string }) => void;
  updateStatusWidget: (id: string, data: Partial<{ batteryText: string, nameText: string, subText: string, avatarUrl: string }>) => void;
}

export interface ShoprjItem {
  id: string;
  name: string;
  image: string;
  price: number;
}

export interface ShoprjTransaction {
  id: string;
  buyerId: string;
  receiverId: string;
  itemId: string;
  timestamp: string;
  note?: string;
}

export interface AppStore {
  worldbookRules: WorldbookRule[];
  addWorldbookRule: (rule: Omit<WorldbookRule, 'id'>) => void;
  updateWorldbookRule: (id: string, updates: Partial<WorldbookRule>) => void;
  removeWorldbookRule: (id: string) => void;
  themeSettings: ThemeSettings;
  updateThemeSettings: (settings: Partial<ThemeSettings>) => void;
  currentScreen: ScreenState;
  setScreen: (screen: ScreenState) => void;
  
  // User Profile
  userProfile: UserProfile;
  updateUserProfile: (profile: Partial<UserProfile>) => void;

  // Contacts and Characters
  contacts: CharacterProfile[];
  addContact: (char: CharacterProfile) => void;
  updateContact: (id: string, updates: Partial<CharacterProfile>) => void;
  removeContact: (id: string) => void;
  
  currentCharacter: CharacterProfile | null;
  setCharacter: (char: CharacterProfile) => void;
  updateMood: (mood: MoodState) => void;
  
  // Navigation stack
  screenStack: ScreenState[];
  pushScreen: (screen: ScreenState) => void;
  popScreen: () => void;
  replaceScreen: (screen: ScreenState) => void;

  // Chat Data
  messagesByContact: Record<string, Message[]>;
  chatMode: 'online' | 'offline';
  setChatMode: (mode: 'online' | 'offline') => void;
  addMessage: (msg: Message) => void;
  updateMessage: (id: string, content: string) => void;
  clearMessages: () => void;

  // Diaries
  diaries: Record<string, DiaryEntry[]>; // keyed by authorId
  addDiaryEntry: (authorId: string, entry: DiaryEntry) => void;
  deleteDiaryEntry: (authorId: string, entryId: string) => void;

  // Social
  socialPosts: SocialPost[];
  addSocialPost: (post: SocialPost) => void;
  toggleLikePost: (postId: string) => void;
  addCommentToPost: (postId: string, comment: SocialComment) => void;

  // Forum
  forumProfile: ForumProfile;
  updateForumProfile: (profile: Partial<ForumProfile>) => void;
  forumPosts: ForumPost[];
  addForumPost: (post: ForumPost) => void;
  toggleLikeForumPost: (postId: string) => void;
  addCommentToForumPost: (postId: string, comment: ForumComment) => void;
  toggleLikeForumComment: (postId: string, commentId: string) => void;

  // Shoprj
  shoprjItems: ShoprjItem[];
  shoprjTransactions: ShoprjTransaction[];
  shoprjWishlist: string[];
  addShoprjItem: (item: Omit<ShoprjItem, 'id'>) => void;
  updateShoprjItem: (itemId: string, data: Partial<ShoprjItem>) => void;
  buyShoprjItem: (buyerId: string, receiverId: string, itemId: string, note?: string) => void;
  toggleShoprjWishlist: (itemId: string) => void;

  // Manual save/load controls
  isHomeEditMode: boolean;
  setHomeEditMode: (mode: boolean) => void;
  homeItems?: string[];
  customPhotoWidgets?: Record<string, string>;
  playerWidgets?: Record<string, { title: string, coverImage: string, thumbnail: string, mediaUrl: string }>;
  statusWidgets?: Record<string, { batteryText: string, nameText: string, subText: string, avatarUrl: string }>;
  setHomeItems: (items: string[]) => void;
  updateCustomPhotoWidget: (id: string, url: string) => void;
  updatePlayerWidget: (id: string, data: { title?: string, coverImage?: string, thumbnail?: string, mediaUrl?: string }) => void;
  updateStatusWidget: (id: string, data: Partial<{ batteryText: string, nameText: string, subText: string, avatarUrl: string }>) => void;
  
  
  // Daily Log
  dailyLogProfile: DailyLogProfile;
  updateDailyLogProfile: (profile: Partial<DailyLogProfile>) => void;
  dailyLogPosts: DailyLogPost[];
  addDailyLogPost: (post: DailyLogPost) => void;
  toggleLikeDailyLogPost: (postId: string, authorId: string) => void;
  addCommentToDailyLogPost: (postId: string, comment: DailyLogComment) => void;

  // Global Media Player
  globalMediaId: string | null;
  globalMediaUrl: string | null;
  isGlobalPlaying: boolean;
  globalMediaProgress: number;
  globalMediaCurrentTime: number;
  globalMediaDuration: number;
  setGlobalMedia: (id: string | null, url: string | null, playing: boolean) => void;
  toggleGlobalPlay: () => void;
  setGlobalMediaProgress: (progress: number, currentTime: number, duration: number) => void;
}

export const useAppStore = create<AppStore>()((set, get) => ({
  worldbookRules: [
    {
      id: 'default_rule_1',
      title: 'Ngôn ngữ',
      content: 'Nhân vật luôn trả lời bằng tiếng Việt tự nhiên, phù hợp với tính cách.'
    }
  ],
  addWorldbookRule: (rule) => set((state) => ({
    worldbookRules: [...state.worldbookRules, { ...rule, id: Date.now().toString() }]
  })),
  updateWorldbookRule: (id, updates) => set((state) => ({
    worldbookRules: state.worldbookRules.map(r => r.id === id ? { ...r, ...updates } : r)
  })),
  removeWorldbookRule: (id) => set((state) => ({
    worldbookRules: state.worldbookRules.filter(r => r.id !== id)
  })),
  themeSettings: {
    homeBackground: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=1000&auto=format&fit=crop',
    appBackground: '',
    appBackgrounds: {},
    appIcons: {},
    chatBackground: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=1000&auto=format&fit=crop',
    chatBubbleColor: 'bg-pink-500',
  } as ThemeSettings,
  updateThemeSettings: (settings) => set((state) => ({
    themeSettings: { ...state.themeSettings, ...settings }
  })),
  isHomeEditMode: false,
  setHomeEditMode: (mode) => set({ isHomeEditMode: mode }),
  setHomeItems: (items) => set({ homeItems: items }),
  updateCustomPhotoWidget: (id, url) => set((state) => ({ customPhotoWidgets: { ...(state.customPhotoWidgets || {}), [id]: url } })),
  updatePlayerWidget: (id, data) => set((state) => {
    const existing = state.playerWidgets?.[id] || { title: 'carpe diem', coverImage: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=1000&auto=format&fit=crop', thumbnail: 'https://ui-avatars.com/api/?name=CD&background=random&color=fff', mediaUrl: '' };
    return { playerWidgets: { ...(state.playerWidgets || {}), [id]: { ...existing, ...data } } };
  }),
  updateStatusWidget: (id, data) => set((state) => {
    const existing = state.statusWidgets?.[id] || { batteryText: '电量', nameText: 'SanYa', subText: '椰梦', avatarUrl: state.userProfile?.avatar || 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=200' };
    return { statusWidgets: { ...(state.statusWidgets || {}), [id]: { ...existing, ...data } } };
  }),
  
  
  dailyLogProfile: {
    name: 'User',
    avatar: 'https://ui-avatars.com/api/?name=User&background=random',
    banner: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=1000&auto=format&fit=crop'
  },
  updateDailyLogProfile: (profile) => set((state) => ({
    dailyLogProfile: { ...state.dailyLogProfile, ...profile }
  })),
  dailyLogPosts: [],
  addDailyLogPost: (post) => set((state) => ({
    dailyLogPosts: [post, ...state.dailyLogPosts]
  })),
  toggleLikeDailyLogPost: (postId, authorId) => set((state) => ({
    dailyLogPosts: state.dailyLogPosts.map(p => {
      if (p.id === postId) {
        const currentLikes = p.likes || [];
        const hasLiked = currentLikes.includes(authorId);
        return {
          ...p,
          likes: hasLiked ? currentLikes.filter(id => id !== authorId) : [...currentLikes, authorId]
        };
      }
      return p;
    })
  })),
  addCommentToDailyLogPost: (postId, comment) => set((state) => ({
    dailyLogPosts: state.dailyLogPosts.map(p => p.id === postId ? { ...p, comments: [...(p.comments || []), comment] } : p)
  })),

  globalMediaId: null,
  globalMediaUrl: null,
  isGlobalPlaying: false,
  globalMediaProgress: 0,
  globalMediaCurrentTime: 0,
  globalMediaDuration: 0,
  setGlobalMedia: (id, url, playing) => set({ 
    globalMediaId: id, 
    globalMediaUrl: url, 
    isGlobalPlaying: playing,
    ...(url !== get().globalMediaUrl ? { globalMediaProgress: 0, globalMediaCurrentTime: 0, globalMediaDuration: 0 } : {})
  }),
  toggleGlobalPlay: () => set((state) => ({ isGlobalPlaying: !state.isGlobalPlaying })),
  setGlobalMediaProgress: (progress, currentTime, duration) => set({ globalMediaProgress: progress, globalMediaCurrentTime: currentTime, globalMediaDuration: duration }),
  
  currentScreen: 'splash',
  setScreen: (screen) => set({ currentScreen: screen }),
  
  userProfile: {
    name: 'Nina',
    avatar: 'https://ui-avatars.com/api/?name=Nina&background=random&color=fff',
    status: 'Digital World',
    badge: '🌸',
    coverPhoto: 'https://ui-avatars.com/api/?name=Nina&background=random&color=fff',
    socialStats: { balance: '860,260', msgs: '1831', time: '420' }
  },
  updateUserProfile: (profile) => set((state) => ({
    userProfile: { ...state.userProfile, ...profile }
  })),

  contacts: [],
  addContact: (char) => set((state) => ({ contacts: [...state.contacts, char] })),
  updateContact: (id, updates) => set((state) => ({
    contacts: state.contacts.map(c => c.id === id ? { ...c, ...updates } : c),
    currentCharacter: state.currentCharacter?.id === id ? { ...state.currentCharacter, ...updates } : state.currentCharacter
  })),
  removeContact: (id) => set((state) => {
    const { [id]: _, ...remainingMessages } = state.messagesByContact;
    return {
      contacts: state.contacts.filter(c => c.id !== id),
      currentCharacter: state.currentCharacter?.id === id ? null : state.currentCharacter,
      messagesByContact: remainingMessages
    };
  }),

  currentCharacter: null,
  setCharacter: (char) => set({ currentCharacter: char }),
  updateMood: (mood) => set((state) => ({ 
    currentCharacter: state.currentCharacter ? { ...state.currentCharacter, mood } : null,
    contacts: state.contacts.map(c => state.currentCharacter && c.id === state.currentCharacter.id ? { ...c, mood } : c)
  })),

  screenStack: ['splash'],
  pushScreen: (screen) => set((state) => ({ 
    screenStack: [...state.screenStack, screen],
    currentScreen: screen
  })),
  popScreen: () => set((state) => {
    const newStack = [...state.screenStack];
    if (newStack.length > 1) {
      newStack.pop();
    }
    return { 
      screenStack: newStack,
      currentScreen: newStack[newStack.length - 1]
    };
  }),
  replaceScreen: (screen) => set((state) => {
     const newStack = [...state.screenStack];
     newStack[newStack.length - 1] = screen;
     return {
        screenStack: newStack,
        currentScreen: screen
     };
  }),

  messagesByContact: {},
  chatMode: 'online',
  setChatMode: (mode) => set({ chatMode: mode }),
  addMessage: (msg) => set((state) => {
    if (!state.currentCharacter) return state;
    const cid = state.currentCharacter.id;
    const currentMsgs = state.messagesByContact[cid] || [];
    return { 
      messagesByContact: { ...state.messagesByContact, [cid]: [...currentMsgs, msg] } 
    };
  }),
  updateMessage: (id, content) => set((state) => {
    if (!state.currentCharacter) return state;
    const cid = state.currentCharacter.id;
    const currentMsgs = state.messagesByContact[cid] || [];
    return {
      messagesByContact: { 
        ...state.messagesByContact, 
        [cid]: currentMsgs.map(msg => msg.id === id ? { ...msg, content } : msg) 
      }
    };
  }),
  clearMessages: () => set((state) => {
    if (!state.currentCharacter) return state;
    return {
      messagesByContact: { ...state.messagesByContact, [state.currentCharacter.id]: [] }
    };
  }),

  diaries: {
    'user': [
      {
         id: 'd1',
         authorId: 'user',
         date: new Date().toISOString(),
         content: 'Chào ngày mới. Mình hy vọng hôm nay mọi thứ đều suôn sẻ.',
         moodTag: 'bình yên',
         weatherIcon: 'sun'
      }
    ]
  },
  addDiaryEntry: (authorId, entry) => set((state) => {
    const current = state.diaries[authorId] || [];
    return {
       diaries: { ...state.diaries, [authorId]: [entry, ...current] }
    };
  }),
  deleteDiaryEntry: (authorId, entryId) => set((state) => {
    const current = state.diaries[authorId] || [];
    return {
       diaries: { ...state.diaries, [authorId]: current.filter(d => d.id !== entryId) }
    };
  }),

  socialPosts: [],
  addSocialPost: (post) => set(state => ({ socialPosts: [post, ...state.socialPosts] })),
  toggleLikePost: (postId) => set(state => ({
    socialPosts: state.socialPosts.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          isLiked: !p.isLiked,
          likes: p.isLiked ? p.likes - 1 : p.likes + 1
        };
      }
      return p;
    })
  })),
  addCommentToPost: (postId, comment) => set(state => ({
    socialPosts: state.socialPosts.map(p => p.id === postId ? { ...p, comments: [...(p.comments || []), comment] } : p)
  })),

  forumProfile: {
    name: 'Người dùng Ẩn danh',
    avatar: 'https://ui-avatars.com/api/?name=Hidden&background=random&color=fff',
    followers: 120
  },
  updateForumProfile: (profile) => set(state => ({ forumProfile: { ...state.forumProfile, ...profile } })),
  forumPosts: [],
  addForumPost: (post) => set(state => ({ forumPosts: [post, ...state.forumPosts] })),
  toggleLikeForumPost: (postId) => set(state => ({
    forumPosts: state.forumPosts.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          isLiked: !p.isLiked,
          likes: p.isLiked ? p.likes - 1 : p.likes + 1
        };
      }
      return p;
    })
  })),
  addCommentToForumPost: (postId, comment) => set(state => ({
    forumPosts: state.forumPosts.map(p => p.id === postId ? { ...p, comments: [...(p.comments || []), comment] } : p)
  })),
  toggleLikeForumComment: (postId, commentId) => set(state => ({
    forumPosts: state.forumPosts.map(p => {
      if (p.id === postId) {
        const comments = p.comments || [];
        return {
          ...p,
          comments: comments.map(c => {
            if (c.id === commentId) {
              const currentLiked = !!c.isLiked;
              return { ...c, isLiked: !currentLiked, likes: (c.likes || 0) + (currentLiked ? -1 : 1) };
            }
            return c;
          })
        };
      }
      return p;
    })
  })),

  // Shoprj
  shoprjItems: [
    { id: 'item1', name: 'Cuteness Potion', image: 'https://images.unsplash.com/photo-1544605417-cbeae2de5505?w=500&auto=format&fit=crop', price: 42.28 },
    { id: 'item2', name: 'Nekoflor Bouquet', image: 'https://images.unsplash.com/photo-1563241527-3004b7be0ffd?w=500&auto=format&fit=crop', price: 15.00 },
    { id: 'item3', name: 'Seraph Wings', image: 'https://images.unsplash.com/photo-1520607162513-7770dd0018d0?w=500&auto=format&fit=crop', price: 99.99 },
  ],
  shoprjTransactions: [],
  shoprjWishlist: [],
  addShoprjItem: (item) => set(state => ({
    shoprjItems: [{...item, id: Date.now().toString()}, ...state.shoprjItems]
  })),
  updateShoprjItem: (itemId, data) => set(state => ({
    shoprjItems: state.shoprjItems.map(item => item.id === itemId ? { ...item, ...data } : item)
  })),
  buyShoprjItem: (buyerId, receiverId, itemId, note) => set(state => {
    const newItem: ShoprjTransaction = {
      id: Date.now().toString() + Math.random().toString(36).substring(7),
      buyerId,
      receiverId,
      itemId,
      timestamp: new Date().toISOString(),
      note
    };

    let targetContactId = null;
    let senderRole: 'user' | 'char' = 'user';
    if (buyerId === 'user') {
        targetContactId = receiverId;
        senderRole = 'user';
    } else {
        targetContactId = buyerId;
        senderRole = 'char';
    }

    const itemObj = state.shoprjItems.find(i => i.id === itemId);

    let nextMessages = state.messagesByContact;
    if (targetContactId && itemObj && targetContactId !== 'user') {
        const giftMsg = {
            id: "gift-" + newItem.id,
            role: senderRole,
            content: `[ĐÃ TẶNG QUÀ: ${itemObj.name}]${note ? ` - Lời nhắn: ${note}` : ''}`,
            timestamp: newItem.timestamp,
            type: 'text' as const
        };
        const st = state.messagesByContact[targetContactId] || [];
        nextMessages = {
            ...state.messagesByContact,
            [targetContactId]: [...st, giftMsg]
        };
    }

    return { 
      shoprjTransactions: [newItem, ...state.shoprjTransactions],
      messagesByContact: nextMessages
    };
  }),
  toggleShoprjWishlist: (itemId) => set(state => ({
    shoprjWishlist: state.shoprjWishlist.includes(itemId) 
      ? state.shoprjWishlist.filter(id => id !== itemId)
      : [...state.shoprjWishlist, itemId]
  }))
}));

// Manual persistence functions
export async function saveAppData() {
  const state = useAppStore.getState();
  const dataToSave = {
    worldbookRules: state.worldbookRules,
    themeSettings: state.themeSettings,
    userProfile: state.userProfile,
    forumProfile: state.forumProfile,
    contacts: state.contacts,
    messagesByContact: state.messagesByContact,
    diaries: state.diaries,
    socialPosts: state.socialPosts,
    forumPosts: state.forumPosts,
    homeItems: state.homeItems,
    customPhotoWidgets: state.customPhotoWidgets,
    playerWidgets: state.playerWidgets,
    statusWidgets: state.statusWidgets,
    dailyLogProfile: state.dailyLogProfile,
    dailyLogPosts: state.dailyLogPosts,
    shoprjItems: state.shoprjItems,
    shoprjTransactions: state.shoprjTransactions,
    shoprjWishlist: state.shoprjWishlist
  };
  try {
    await localforage.setItem('manual-app-storage', dataToSave);
  } catch (e) {
    console.error('Lỗi khi lưu dữ liệu:', e);
    alert('Không thể lưu dữ liệu. Có thể do ảnh tải lên quá kích thước. Hãy xóa bớt ảnh hoặc chọn ảnh nhỏ hơn.');
  }
}

export async function loadAppData() {
  try {
    const stored: any = await localforage.getItem('manual-app-storage');
    if (!stored) {
      // Try to migrate from localStorage
      const oldStorage = localStorage.getItem('manual-app-storage');
      if (oldStorage) {
        const parsed = JSON.parse(oldStorage);
        await localforage.setItem('manual-app-storage', parsed);
        useAppStore.setState({
          ...useAppStore.getState(),
          ...parsed,
          currentScreen: 'splash',
          screenStack: ['splash']
        });
        localStorage.removeItem('manual-app-storage'); // Clean up old storage
        return;
      }
    }
    
    if (stored) {
      useAppStore.setState({
        ...useAppStore.getState(),
        ...stored,
        currentScreen: 'splash',
        screenStack: ['splash']
      });
    }
  } catch (e) {
    console.error('Failed to load app data', e);
  }
}

export async function clearAppData() {
  await localforage.removeItem('manual-app-storage');
  localStorage.removeItem('manual-app-storage'); // Just in case
  localStorage.removeItem('app-storage'); // Cleanup old Zustand state
  window.location.reload();
}

