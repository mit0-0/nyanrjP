import { useState, useRef, useEffect } from 'react';
import { MessageCircleHeart, Globe, MessageSquarePlus, ImageIcon, Map, Search, Settings, Plus, X, Heart, Users, ShoppingBag } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { cn } from '../../lib/utils';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  rectSortingStrategy
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { ClockWidget, PhotoWidget, StatusWidget, MusicWidget, ProfileWidget, PlayerWidget } from '../widgets';
import { motion, AnimatePresence } from 'motion/react';

const APP_REGISTRY: Record<string, { name: string, icon: any }> = {
  'chat': { name: 'Nhắn tin', icon: MessageCircleHeart },
  'worldbook': { name: 'Worldbook', icon: Globe },
  'contacts': { name: 'Danh bạ', icon: Users },
  'social': { name: 'Nj', icon: Heart },
  'forum': { name: 'Diễn đàn', icon: MessageSquarePlus },
  'shoprj': { name: 'Shoprj', icon: ShoppingBag },
  'search': { name: 'Tìm kiếm', icon: Search },
  'settings': { name: 'Cài đặt', icon: Settings },
};

const DOCK_APPS = ['chat', 'worldbook', 'social', 'settings'];

function getGridClasses(id: string) {
   if (id.startsWith('widget-profile')) return 'col-span-4 row-span-2 aspect-[2/1]';
   if (id.startsWith('widget-player')) return 'col-span-4 row-span-2 aspect-[2/1]';
   if (id.startsWith('widget-clock')) return 'col-span-4 row-span-1 aspect-[4/1]';
   if (id.startsWith('widget-')) return 'col-span-2 row-span-2 aspect-square';
   return 'col-span-1 row-span-1 aspect-square flex flex-col justify-center';
}

function SortableHomeItem({ id, editMode, onRemove }: { id: string, editMode: boolean, onRemove: (id: string) => void }) {
  const { pushScreen, themeSettings } = useAppStore();
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id, disabled: !editMode });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : 1,
    opacity: isDragging ? 0.8 : 1,
  };

  const gridClasses = getGridClasses(id);

  let content = null;
  if (id.startsWith('widget-profile')) content = <ProfileWidget />;
  else if (id.startsWith('widget-player')) content = <PlayerWidget widgetId={id} editMode={editMode} />;
  else if (id.startsWith('widget-clock')) content = <ClockWidget />;
  else if (id.startsWith('widget-photo')) content = <PhotoWidget widgetId={id} editMode={editMode} />;
  else if (id.startsWith('widget-music')) content = <MusicWidget />;
  else if (id.startsWith('widget-anniversary')) content = <StatusWidget widgetId={id} editMode={editMode} />;
  else if (APP_REGISTRY[id]) {
      const app = APP_REGISTRY[id];
      content = (
        <div className="flex flex-col items-center justify-center w-full h-full cursor-pointer relative group-active:scale-95 transition-transform" onClick={() => !editMode && pushScreen(id as any)}>
           <div className="w-[56px] h-[56px] sm:w-[60px] sm:h-[60px] bg-white/10 backdrop-blur-md rounded-[20px] border border-white/20 flex flex-col items-center justify-center shadow-lg relative overflow-hidden z-0 mb-1">
              {themeSettings.appIcons?.[id] ? (
                 <img src={themeSettings.appIcons[id]} className="w-full h-full object-cover" />
              ) : (
                 <app.icon className="text-white w-7 h-7 drop-shadow-sm" strokeWidth={1.5} />
              )}
           </div>
           {themeSettings.appFrame && (
              <div className="absolute top-[8px] sm:top-[12px] left-1/2 -translate-x-1/2 w-[68px] h-[68px] sm:w-[72px] sm:h-[72px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.appFrame})` }} />
           )}
           <span className="text-[11px] font-medium text-white shadow-black drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] leading-tight mt-1 truncate w-[120%] text-center">{app.name}</span>
        </div>
      );
  } else {
      content = <div className="w-full h-full bg-white/20 rounded-xl" />;
  }

  return (
      <div
         ref={setNodeRef}
         style={style}
         className={cn("relative group select-none touch-none", gridClasses, editMode && "animate-pulse")}
         {...attributes}
         {...listeners}
      >
         {content}
         {editMode && id.startsWith('widget-') && (
             <button 
               onClick={(e) => { e.stopPropagation(); onRemove(id); }}
               className="absolute -top-2 -right-2 bg-white/80 text-red-500 rounded-full p-1.5 shadow-[0_2px_10px_rgba(0,0,0,0.2)] z-50 hover:bg-red-50"
               onPointerDown={(e) => e.stopPropagation()}
             >
                <X size={14} strokeWidth={3} />
             </button>
         )}
      </div>
  );
}

export default function HomeScreen() {
  const { themeSettings, homeItems, setHomeItems, pushScreen, isHomeEditMode, setHomeEditMode } = useAppStore();
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    if (!homeItems || homeItems.length === 0) {
        setHomeItems([
            'widget-profile',
            'widget-player-DEFAULT',
            'widget-clock',
            'widget-photo-DEFAULT',
            'chat',
            'contacts',
            'worldbook',
            'forum',
            'shoprj',
            'widget-anniversary',
            'search',
            'settings'
        ]);
    } else {
        let newItems = [...homeItems];
        let changed = false;
        if (!newItems.includes('contacts')) {
            const chatIdx = newItems.indexOf('chat');
            if (chatIdx !== -1) newItems.splice(chatIdx + 1, 0, 'contacts');
            else newItems.push('contacts');
            changed = true;
        }
        if (newItems.includes('widget-music')) {
            newItems = newItems.map(i => i === 'widget-music' ? 'widget-player-DEFAULT' : i);
            changed = true;
        }
        if (!newItems.includes('shoprj')) {
            const forumIdx = newItems.indexOf('forum');
            if (forumIdx !== -1) newItems.splice(forumIdx + 1, 0, 'shoprj');
            else newItems.splice(8, 0, 'shoprj');
            changed = true;
        } else {
            // Force it to page 2 if they had it pushed to the end previously
            const shopIdx = newItems.indexOf('shoprj');
            if (shopIdx === newItems.length - 1 && newItems.length > 10) {
               newItems.splice(shopIdx, 1);
               const forumIdx = newItems.indexOf('forum');
               if (forumIdx !== -1) newItems.splice(forumIdx + 1, 0, 'shoprj');
               else newItems.splice(8, 0, 'shoprj');
               changed = true;
            }
        }
        if (newItems.includes('gallery')) {
            newItems = newItems.filter(i => i !== 'gallery');
            changed = true;
        }
        if (newItems.includes('map')) {
            newItems = newItems.filter(i => i !== 'map');
            changed = true;
        }
        if (changed) setHomeItems(newItems);
    }
    setIsInitialized(true);
  }, [homeItems, setHomeItems]);

  const items = homeItems || [];

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { delay: 150, tolerance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (active.id !== over?.id && over) {
      const oldIndex = items.indexOf(active.id as string);
      const newIndex = items.indexOf(over.id as string);
      setHomeItems(arrayMove(items, oldIndex, newIndex));
    }
  };

  const removeHomeItem = (id: string) => {
    setHomeItems(items.filter((i: string) => i !== id));
  };

  const addPhotoWidget = () => {
    setHomeItems([...items, `widget-photo-${Date.now()}`]);
  };

  if (!isInitialized) return null;

  const pages: string[][] = [];
  let currentPage: string[] = [];
  let currentSlots = 0;
  
  items.forEach(item => {
     let w = 1, h = 1;
     if (item.startsWith('widget-profile')) { w = 4; h = 2; }
     else if (item.startsWith('widget-clock')) { w = 4; h = 1; }
     else if (item.startsWith('widget-')) { w = 2; h = 2; }
     
     const slots = w * h;
     
     // 5 rows * 4 cols = 20 slots
     if (currentSlots + slots > 20) {
        pages.push(currentPage);
        currentPage = [item];
        currentSlots = slots;
     } else {
        currentPage.push(item);
        currentSlots += slots;
     }
  });
  if (currentPage.length > 0) pages.push(currentPage);
  if (pages.length === 0) pages.push([]);

  return (
    <div className={cn("absolute inset-0 bg-cover bg-center flex flex-col pt-10 pb-0", !themeSettings.homeBackground && "bg-gradient-to-br from-[#FFF0F5] to-[#F5F1FD]")} 
         style={themeSettings.homeBackground ? { backgroundImage: `url("${themeSettings.homeBackground}")` } : {}}>
      
      {/* Dim overlay */}
      <div className="absolute inset-0 bg-black/30 pointer-events-none mix-blend-overlay"></div>

      <div className="relative z-10 flex flex-col h-full overflow-hidden">
        
        {isHomeEditMode && (
          <div className="flex justify-end items-center px-4 mb-2 shrink-0 animate-in fade-in">
             <button 
               className="bg-white/40 hover:bg-white/50 backdrop-blur-md px-5 py-2 rounded-full text-pink-500 text-sm font-bold shadow-md transition-transform active:scale-95 border border-white/40 flex items-center gap-2"
               onClick={() => {
                  setHomeEditMode(false);
                  import('../../store/useAppStore').then(m => {
                     m.saveAppData();
                  });
               }}
             >
                <Plus className="rotate-45" size={16} /> Save
             </button>
          </div>
        )}

        {/* Grid Container */}
        <DndContext 
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
        >
            <div className={cn("flex-grow w-full overflow-x-auto snap-x snap-mandatory [-ms-overflow-style:'none'] [scrollbar-width:'none'] [&::-webkit-scrollbar]:hidden flex flex-row", !isHomeEditMode && "overflow-y-hidden")}>
               <SortableContext items={items} strategy={rectSortingStrategy}>
                   {pages.map((page, i) => (
                      <div key={i} className={cn("w-screen shrink-0 snap-center px-4 flex flex-col justify-start pb-4", isHomeEditMode ? "overflow-y-auto" : "overflow-hidden")}>
                         <div 
                            className="grid grid-cols-4 grid-flow-row-dense gap-4 w-full content-start"
                         >
                            {page.map(item => (
                                <SortableHomeItem key={item} id={item} editMode={isHomeEditMode} onRemove={removeHomeItem} />
                            ))}
                         </div>
                      </div>
                   ))}
               </SortableContext>
            </div>
        </DndContext>

        {/* Edit Add Actions removed, handled in settings */}

        {/* Dock */}
        <div className="w-full px-4 shrink-0 mb-2 pb-0">
          <div className="w-full h-[80px] backdrop-blur-xl bg-white/20 rounded-[28px] border border-white/30 flex items-center justify-around px-2 shadow-[0_8px_32px_rgba(0,0,0,0.15)] relative z-10">
             {DOCK_APPS.map((appId, i) => {
                const app = APP_REGISTRY[appId];
                if (!app) return null;
                return (
                  <div 
                    key={appId + 'dock'} 
                    className="flex flex-col items-center cursor-pointer active:scale-95 transition-transform"
                    onClick={() => pushScreen(appId as any)}
                  >
                    <div className="relative w-[52px] h-[52px] sm:w-[56px] sm:h-[56px]">
                      <div className={cn("w-full h-full rounded-[18px] sm:rounded-2xl flex items-center justify-center relative z-0 overflow-hidden", i === 0 ? "bg-[#F2C4CE] shadow-[0_4px_10px_rgba(242,196,206,0.5)]" : "bg-white/10 border border-white/20 shadow-sm")}>
                        {themeSettings.appIcons?.[appId] ? (
                           <img src={themeSettings.appIcons[appId]} alt={app.name} className="w-full h-full object-cover" />
                        ) : (
                           <app.icon className={cn("w-6 h-6 drop-shadow-sm", i === 0 ? "text-[#1A1A1A]" : "text-white")} strokeWidth={1.5} />
                        )}
                      </div>
                      {themeSettings.appFrame && (
                         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[64px] h-[64px] sm:w-[68px] sm:h-[68px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.appFrame})` }} />
                      )}
                    </div>
                  </div>
                )
              })}
          </div>
        </div>

      </div>
    </div>
  );
}
