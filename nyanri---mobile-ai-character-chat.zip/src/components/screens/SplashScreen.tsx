import { useState, useEffect } from "react";
import { ChevronUp } from "lucide-react";
import { motion, useAnimation } from "motion/react";
import { useAppStore } from "../../store/useAppStore";

export default function SplashScreen() {
  const { replaceScreen, themeSettings } = useAppStore();
  const [time, setTime] = useState(new Date());
  const controls = useAnimation();

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleDragEnd = (event: any, info: any) => {
    if (info.offset.y < -100) {
      // Swiped up enough, complete the animation and change screen
      controls.start({ y: "-100%", opacity: 0, transition: { duration: 0.3 } }).then(() => {
        replaceScreen("home");
      });
    } else {
      // Return to original position
      controls.start({ y: 0, opacity: 1, transition: { type: "spring", bounce: 0.4 } });
    }
  };

  return (
    <div className="absolute inset-0 bg-[#1A1A1A] overflow-hidden">
      {/* Background Wallpaper */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-80"
        style={{ backgroundImage: `url("${themeSettings.homeBackground}")` }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      <motion.div 
        className="absolute inset-0 flex flex-col items-center z-10 w-full h-full"
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 1, bottom: 0.1 }}
        onDragEnd={handleDragEnd}
        animate={controls}
      >
        {/* Corner App Name */}
        <div className="absolute top-6 left-6 z-20">
          <span className="font-serif italic font-bold text-white tracking-widest text-sm drop-shadow-md opacity-90">nyanri</span>
        </div>

        {/* Lock Screen Clock */}
        <div className="mt-24 flex flex-col items-center">
          <div className="text-white text-7xl font-sans font-light tracking-tight drop-shadow-lg">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
          </div>
          <div className="text-white/90 text-sm font-medium mt-2 drop-shadow-md tracking-wide">
            {time.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long' })}
          </div>
        </div>

        {/* Swipe up hint */}
        <div className="absolute bottom-10 flex flex-col items-center text-white/80 animate-pulse">
          <ChevronUp size={24} className="mb-1" />
          <span className="text-xs uppercase tracking-[0.2em] font-medium">Vuốt lên để mở</span>
        </div>
      </motion.div>
    </div>
  );
}
