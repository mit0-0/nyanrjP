import { useState, useRef } from 'react';
import { useAppStore, CharacterProfile } from '../../store/useAppStore';
import { ChevronLeft, PawPrint, Camera } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function CharacterCreateScreen() {
  const { popScreen, setCharacter, currentCharacter, pushScreen, addContact, updateContact, addMessage, themeSettings } = useAppStore();
  const [avatar, setAvatar] = useState(currentCharacter?.avatar || '');
  const [name, setName] = useState(currentCharacter?.name || '');
  const [gender, setGender] = useState(currentCharacter?.gender || 'Nữ');
  const [age, setAge] = useState(currentCharacter?.age || '18');
  const [appearance, setAppearance] = useState(currentCharacter?.appearance || '');
  const [personality, setPersonality] = useState(currentCharacter?.personalityParams || '');
  const [background, setBackground] = useState(currentCharacter?.background || '');
  const [scenario, setScenario] = useState(currentCharacter?.scenario || '');
  const [firstMessage, setFirstMessage] = useState(currentCharacter?.firstMessage || '');
  const [exampleDialogs, setExampleDialogs] = useState(currentCharacter?.exampleDialogs || '');
  const [specialNotes, setSpecialNotes] = useState(currentCharacter?.specialNotes || '');
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const displayAvatar = avatar || (name ? `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=F8E8EE&color=C9748A` : 'https://ui-avatars.com/api/?name=?&background=F8E8EE&color=C9748A');

  const handleSave = () => {
    if (!name) return;
    
    if (currentCharacter) {
      // Edit mode
      const updates: Partial<CharacterProfile> = {
        name,
        avatar: displayAvatar,
        age,
        gender,
        appearance,
        personalityParams: personality,
        background,
        scenario,
        firstMessage,
        exampleDialogs,
        specialNotes,
      };
      updateContact(currentCharacter.id, updates);
      setCharacter({ ...currentCharacter, ...updates });
      
      // Navigate back to contacts
      popScreen();
    } else {
      // Create mode
      const newChar: CharacterProfile = {
        id: Date.now().toString(),
        name,
        avatar: displayAvatar,
        age,
        gender,
        appearance,
        personalityParams: personality,
        background,
        scenario,
        firstMessage,
        exampleDialogs,
        specialNotes,
        mood: 'bình thường',
        relationshipLevel: 1,
        relationshipPoints: 0
      };
      addContact(newChar);
      setCharacter(newChar);
      if (firstMessage.trim()) {
        // Need to setTimeout to give the state time to update currentCharacter before adding message
        setTimeout(() => {
          addMessage({
            id: Date.now().toString(),
            role: 'char',
            content: firstMessage.trim(),
            timestamp: new Date().toISOString(),
            type: 'text'
          });
        }, 50);
      }
      popScreen();
    }
  };

  const generateWithAI = async () => {
    setName('Yumi');
    setGender('Nữ');
    setAge('19');
    setAppearance('Tóc đen dài cúp ngang lưng, đôi mắt to nhưng hay lảng tránh ánh nhìn. Thường mặc một chiếc áo len oversize màu trắng ấm áp.');
    setPersonality('Lạnh lùng bên ngoài nhưng bên trong rất ấm áp (tsundere). Hay ngại ngùng, thích dùng icon "><" hoăc "...". Thông minh nhưng hơi vụng về trong việc thể hiện cảm xúc.');
    setBackground('Một sinh viên năm nhất sống ở căn hộ đối diện. Rất thích nuôi mèo và có một bé mèo tam thể tên "Mochi". Đã bí mật quan sát bạn từ lâu nhưng chưa bao giờ dám kết bạn.');
    setScenario('Trong một ngày trời mưa lớn, Yumi làm rơi chìa khóa trước cửa phòng và không thể vào nhà. Cô bé ướt sũng và run rẩy gõ cửa phòng người hàng xóm duy nhất - là bạn.');
    setFirstMessage('*Giật mình rụt tay lại khi cửa mở, giọng run run* "...Xin lỗi đã làm phiền cậu. Chìa khóa của tớ... tớ làm rớt đâu mất rồi. C-Cậu có thể cho tớ đứng tạm ngoài hành lang đợi thợ sửa khóa được không? Tớ không vào trong đâu..." ><');
    setExampleDialogs('<user>: Cậu lạnh đúng không? Vào nhà đi, tớ lấy khăn cho lau.\n<Yumi>: Mình... mình không sao đâu! Tại... tại gió lạnh quá thôi chứ tớ không lạnh! *hắt xì* Thấy chưa... chỉ là bụi bay vô mũi thôi...');
    setSpecialNotes('Sẽ nói dối về cảm xúc thật, nhưng dễ bị lật tẩy vì tai sẽ đỏ lên. Luôn ôm một con gấu bông nhỏ do bạn tặng nếu mối quan hệ phát triển. Cực kỳ thích trà sữa matcha.');
  };

  return (
    <div className="absolute inset-0 bg-[#E5E3D8] flex flex-col pt-12 font-sans">
      {/* Header */}
      <div className="flex items-center px-4 mb-4">
        <button onClick={popScreen} className="p-2 -ml-2 text-[#3A3831] active:scale-95">
          <ChevronLeft />
        </button>
        <div className="flex-grow flex flex-col items-center">
            <h1 className="font-serif text-2xl text-[#3A3831] tracking-widest uppercase">PERSONA</h1>
            <span className="text-[8px] tracking-[0.4em] font-medium text-[#7D786D] uppercase">The Silent Script</span>
        </div>
        <div className="w-10"></div>
      </div>

      <div className="flex-grow overflow-y-auto px-6 pb-24 no-scrollbar">
        
        {/* Avatar */}
        <div className="flex justify-center mb-8 mt-2">
          <input 
             type="file" 
             accept="image/*" 
             ref={fileInputRef} 
             className="hidden" 
             onChange={handleImageUpload} 
          />
          <div className="relative w-32 h-40 group shadow-[0_4px_15px_rgba(0,0,0,0.05)] border border-[#BDBCA9] bg-[#C3C1B5]">
            <div 
               className="w-full h-full flex items-center justify-center relative overflow-hidden cursor-pointer"
               onClick={() => fileInputRef.current?.click()}
            >
               {avatar || name ? (
                 <img src={displayAvatar} className="w-full h-full object-cover mix-blend-multiply opacity-90" />
               ) : (
                 <Camera className="text-[#7D786D]" size={32} />
               )}
               <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                 <Camera className="text-white" size={24} />
               </div>
            </div>
          </div>
        </div>

        {/* AI Assist Button */}
        <button 
          onClick={generateWithAI}
          className="w-10 h-10 rounded-full bg-[#DDDCD2] border border-dashed border-[#BDBCA9] flex items-center justify-center shadow-sm text-[#3A3831] active:scale-95 transition-all hover:bg-[#D5D3CA] absolute top-4 right-4 z-10"
        >
          <PawPrint size={16} />
        </button>

        {/* Form */}
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">STITCH 01 / NAME</label>
              <input 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Name..."
                className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-3.5 text-sm shadow-sm focus:border-[#7D786D] outline-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
              />
            </div>
            <div>
              <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">GENDER & AGE</label>
              <div className="flex space-x-2">
                <input 
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  placeholder="Female"
                  className="w-2/3 bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-3.5 text-sm shadow-sm focus:border-[#7D786D] outline-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
                />
                <input 
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="18"
                  className="w-1/3 bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-3.5 text-sm shadow-sm focus:border-[#7D786D] outline-none text-[#3A3831] placeholder:text-[#A5A396] font-serif text-center"
                />
              </div>
            </div>
          </div>

          <div>
             <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">IMAGE URL</label>
             <input 
               value={avatar}
               onChange={(e) => setAvatar(e.target.value)}
               placeholder="https://..."
               className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-3.5 text-sm shadow-sm focus:border-[#7D786D] outline-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
             />
          </div>

          <div>
            <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">APPEARANCE</label>
            <textarea 
              value={appearance}
              onChange={(e) => setAppearance(e.target.value)}
              placeholder="Visual description..."
              rows={2}
              className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
            />
          </div>

          <div>
            <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">PERSONALITY</label>
            <textarea 
              value={personality}
              onChange={(e) => setPersonality(e.target.value)}
              placeholder="Traits, habits..."
              rows={3}
              className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
            />
          </div>

          <div>
            <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">BACKGROUND & LORE</label>
            <textarea 
              value={background}
              onChange={(e) => setBackground(e.target.value)}
              placeholder="History, world..."
              rows={3}
              className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
            />
          </div>

          <div className="pt-4 border-t border-dashed border-[#BDBCA9]">
             <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">SCENARIO</label>
             <textarea 
               value={scenario}
               onChange={(e) => setScenario(e.target.value)}
               placeholder="Setup the initial context..."
               rows={3}
               className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
             />
          </div>

          <div>
             <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">FIRST MESSAGE</label>
             <textarea 
               value={firstMessage}
               onChange={(e) => setFirstMessage(e.target.value)}
               placeholder="Greeting..."
               rows={3}
               className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
             />
          </div>

          <div className="pt-4 border-t border-dashed border-[#BDBCA9]">
             <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">EXAMPLE DIALOGS</label>
             <textarea 
               value={exampleDialogs}
               onChange={(e) => setExampleDialogs(e.target.value)}
               placeholder="<user>: Hello!&#10;<char>: Hi there..."
               rows={4}
               className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-mono text-[10px]"
             />
          </div>

          <div>
             <label className="block text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1.5 ml-1">SYSTEM NOTES / RULES</label>
             <textarea 
               value={specialNotes}
               onChange={(e) => setSpecialNotes(e.target.value)}
               placeholder="Special rules, formatting..."
               rows={3}
               className="w-full bg-[#DDDCD2] border border-[#BDBCA9] rounded-3xl p-4 text-sm shadow-sm focus:border-[#7D786D] outline-none resize-none text-[#3A3831] placeholder:text-[#A5A396] font-serif"
             />
          </div>
        </div>
        
        <div className="h-10"></div>

      </div>

      {/* Save Button */}
      <div className="absolute bottom-6 left-6 right-6">
        <button 
          onClick={handleSave}
          disabled={!name}
          className={cn(
            "w-full py-4 rounded-3xl border text-[11px] transition-all uppercase tracking-[0.2em] flex items-center justify-center font-medium",
            name ? "bg-[#2A2A2A] text-white border-[#2A2A2A] active:bg-[#1A1A1A] active:scale-[0.98]" : "bg-transparent text-[#A5A396] border-[#BDBCA9]"
          )}
        >
          ACTION <span className="ml-2 font-serif text-lg leading-none opacity-50">+</span>
        </button>
      </div>
    </div>
  );
}
