import { useState } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { ChevronLeft, Plus, MessageCircle, UserSquare2, Search, MoreHorizontal, Camera, Clock } from 'lucide-react';
import { cn } from '../../lib/utils';
import DailyLogScreen from '../apps/DailyLogScreen';
import { motion, AnimatePresence } from 'motion/react';

export default function ChatListScreen() {
  const { contacts, pushScreen, popScreen, setCharacter, messagesByContact, userProfile, themeSettings } = useAppStore();
  const [activeTab, setActiveTab] = useState<'chats' | 'contacts' | 'daily-log'>('chats');
  const [showOptions, setShowOptions] = useState(false);

  const handleOpenChat = (contact: any) => {
     setCharacter(contact);
     pushScreen('chat-detail');
  };

  return (
    <div className="absolute inset-0 flex flex-col z-10 font-sans" style={{ backgroundImage: themeSettings.chatBackground ? `url(${themeSettings.chatBackground})` : 'none', backgroundSize: 'cover', backgroundPosition: 'center' }}>
      <div className="absolute inset-0 bg-white/30 backdrop-blur-[2px] pointer-events-none z-0"></div>
      
      {/* Header */}
      <div className="pt-8 pb-1 px-4 relative z-10 bg-transparent">
        <div className="flex items-center justify-between mb-1.5">
           <div className="flex items-center">
              <button onClick={popScreen} className="p-1 -ml-1 text-gray-700 active:scale-95">
                <ChevronLeft size={22} />
              </button>
              <div className="relative w-7 h-7 ml-1 text-center">
                <img src={userProfile.chatAvatar || userProfile.avatar} className="w-7 h-7 rounded-full object-cover border border-gray-100" />
                {themeSettings.userFrame && (
                   <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[38px] h-[38px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.userFrame})` }} />
                )}
             </div>
           </div>
           <div className="flex space-x-8 sm:space-x-10">
              <button 
                 className={cn("text-[13px] transition-colors relative whitespace-nowrap tracking-wide", activeTab === 'chats' ? 'text-pink-500 font-medium' : 'text-gray-500 font-normal hover:text-gray-600')}
                 onClick={() => setActiveTab('chats')}
              >
                 Nhắn tin
                 {activeTab === 'chats' && <motion.div layoutId="tabIndicator" className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-[2px] bg-pink-500 rounded-full" />}
              </button>
              <button 
                 className={cn("text-[13px] transition-colors relative whitespace-nowrap tracking-wide", activeTab === 'contacts' ? 'text-pink-500 font-medium' : 'text-gray-500 font-normal hover:text-gray-600')}
                 onClick={() => setActiveTab('contacts')}
              >
                 Kết nối
                 {activeTab === 'contacts' && <motion.div layoutId="tabIndicator" className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-[2px] bg-pink-500 rounded-full" />}
              </button>
              <button 
                 className={cn("text-[13px] transition-colors relative whitespace-nowrap tracking-wide", activeTab === 'daily-log' ? 'text-pink-500 font-medium' : 'text-gray-500 font-normal hover:text-gray-600')}
                 onClick={() => setActiveTab('daily-log')}
              >
                 Daily Log
                 {activeTab === 'daily-log' && <motion.div layoutId="tabIndicator" className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-[2px] bg-pink-500 rounded-full" />}
              </button>
           </div>
           <div className="relative">
              <button onClick={() => setShowOptions(!showOptions)} className="p-1 -mr-1 text-gray-700 active:scale-95">
                <Plus size={22} />
              </button>
              
              <AnimatePresence>
                 {showOptions && (
                    <>
                       <div className="fixed inset-0 z-20" onClick={() => setShowOptions(false)} />
                       <motion.div 
                          initial={{ opacity: 0, scale: 0.95, y: -10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95, y: -10 }}
                          className="absolute right-0 top-12 bg-white/80 rounded-xl shadow-xl border border-gray-100 w-48 z-30 py-1"
                       >
                          <button 
                             className="w-full text-left px-4 py-3 text-sm font-medium hover:bg-transparent flex items-center"
                             onClick={() => { setShowOptions(false); pushScreen('character-create'); }}
                          >
                             <UserSquare2 size={18} className="mr-3" />
                             Tạo nhân vật mới
                          </button>
                       </motion.div>
                    </>
                 )}
              </AnimatePresence>
           </div>
        </div>
        
        {/* Search */}
        {activeTab !== 'daily-log' && (
        <div className="bg-white/50 backdrop-blur-sm shadow-[inset_0_2px_4px_rgba(0,0,0,0.02)] border border-pink-100/50 rounded-full flex items-center px-3 py-1.5 mx-2">
           <Search size={16} className="text-gray-400 mr-2" />
           <input type="text" placeholder="Tìm kiếm" className="bg-transparent text-sm w-full outline-none text-gray-700 placeholder-gray-400" />
        </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-grow overflow-y-auto bg-transparent pt-2 hide-scrollbar relative z-10">
         {activeTab === 'chats' ? (
            <div className="flex flex-col">
               {contacts.map(contact => {
                  const msgs = messagesByContact[contact.id] || [];
                  const lastMsg = msgs[msgs.length - 1];
                  return (
                    <div 
                       key={contact.id} 
                       className="flex items-center px-4 py-3 active:bg-white/60 hover:bg-white/40 cursor-pointer mb-1 mx-2 rounded-2xl bg-white/50 backdrop-blur-sm border border-white/50 shadow-sm"
                       onClick={() => handleOpenChat(contact)}
                    >
                       <div className="relative w-12 h-12 mr-4 flex-shrink-0">
                          <img src={contact.avatar} className="w-12 h-12 rounded-full object-cover" />
                          {themeSettings.characterFrame && (
                             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[64px] h-[64px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
                          )}
                       </div>
                       <div className="flex-grow pb-1">
                          <div className="flex justify-between items-baseline mb-1">
                             <span className="font-bold text-[15px] text-gray-900">{contact.name}</span>
                             <span className="text-xs text-gray-400">
                                {lastMsg ? new Date(lastMsg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}
                             </span>
                          </div>
                          <div className="text-[13px] text-gray-500 truncate max-w-[200px]">
                             {lastMsg ? (lastMsg.type === 'text' ? lastMsg.content : `[${lastMsg.type}]`) : 'Chưa có tin nhắn'}
                          </div>
                       </div>
                    </div>
                  );
               })}
            </div>
         ) : activeTab === 'contacts' ? (
            <div className="flex flex-col space-y-3 px-2">
               
               <div className="px-2 py-1 mt-1 flex items-center justify-between bg-transparent">
                  <span className="text-[11px] font-bold text-pink-400 tracking-wider uppercase">Kết nối</span>
                  <span className="text-[11px] text-gray-400">({contacts.length}) Người</span>
               </div>
               {contacts.map(contact => {
                  const msgs = messagesByContact[contact.id] || [];
                  const lastMsg = msgs[msgs.length - 1];
                  const compatibility = 60 + (contact.id.length % 40); 
                  
                  return (
                  <div 
                     key={contact.id} 
                     className="flex flex-col p-4 active:scale-[0.98] transition-transform cursor-pointer rounded-3xl bg-white/70 backdrop-blur-md border border-pink-100/50 shadow-[0_4px_20px_rgba(255,192,203,0.15)]"
                     onClick={() => handleOpenChat(contact)}
                  >
                     <div className="flex items-start mb-3">
                        <div className="relative w-14 h-14 mr-3 flex-shrink-0">
                           <img src={contact.avatar} className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-sm" />
                           {themeSettings.characterFrame && (
                              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[72px] h-[72px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
                           )}
                           <div className={cn("absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white shadow-sm", contact.mood === 'bình thường' ? 'bg-emerald-400' : 'bg-pink-400')} />
                        </div>
                        <div className="flex-grow pt-1 w-0">
                           <div className="flex justify-between items-center mb-0.5">
                              <span className="font-bold text-[16px] text-gray-900 truncate pr-2">{contact.name}</span>
                              <span className="text-[10px] whitespace-nowrap uppercase font-bold tracking-widest text-pink-400 bg-pink-50 px-2 py-0.5 rounded-full ring-1 ring-pink-100 ring-inset">
                                {compatibility}% Hợp
                              </span>
                           </div>
                           <span className="text-[12px] text-gray-500 italic block truncate">"{contact.mood || 'Đang rảnh...'}"</span>
                        </div>
                     </div>
                     
                     {/* Progress Bar & Stats */}
                     <div className="bg-pink-50/50 rounded-2xl p-3 border border-pink-100/50">
                        <div className="flex justify-between items-center mb-1.5">
                           <span className="text-[11px] font-medium text-gray-600">Tiến triển tình cảm</span>
                           <span className="text-[11px] font-bold text-pink-500">{contact.relationshipLevel}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-white rounded-full overflow-hidden mb-2.5 shadow-inner">
                           <div 
                              className="h-full bg-gradient-to-r from-pink-300 to-pink-500 rounded-full transition-all duration-1000 ease-out" 
                              style={{ width: `${contact.relationshipLevel}%` }}
                           />
                        </div>
                        
                        <div className="flex items-center justify-between text-[10px] text-gray-500 font-medium">
                           <div className="flex items-center gap-1.5">
                              <MessageCircle size={12} className="text-pink-300" />
                              <span>{msgs.length} Tin nhắn</span>
                           </div>
                           <div className="flex items-center gap-1.5">
                              <Clock size={12} className="text-pink-300" />
                              <span>{lastMsg ? new Date(lastMsg.timestamp).toLocaleDateString([], { month: '2-digit', day: '2-digit'}) : 'Chưa trò chuyện'}</span>
                           </div>
                        </div>
                     </div>
                  </div>
               )})}

            </div>
         ) : activeTab === 'daily-log' ? (
            <div className="absolute inset-0 bg-transparent z-10">
               <DailyLogScreen hideBackButton />
            </div>
         ) : null}
      </div>

    </div>
  );
}
