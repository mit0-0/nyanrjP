import { useState, useRef, useEffect } from 'react';
import { useAppStore, Message } from '../../store/useAppStore';
import { ChevronLeft, MoreVertical, Mic, Paperclip, Send, Heart, Sparkles, SmilePlus, Image as ImageIcon, Wallet, MapPin, Gift } from 'lucide-react';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';
import { generateChatResponseStream } from '../../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';

export default function ChatScreen() {
  const { currentCharacter, messagesByContact, addMessage, updateMessage, popScreen, pushScreen, userProfile, chatMode, setChatMode, themeSettings } = useAppStore();
  const messages = currentCharacter ? (messagesByContact[currentCharacter.id] || []) : [];
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isStickerDrawerOpen, setStickerDrawerOpen] = useState(false);
  const [isMoreDrawerOpen, setMoreDrawerOpen] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping, isStickerDrawerOpen, isMoreDrawerOpen]);

  if (!currentCharacter) return null;

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: "msg-" + Date.now().toString() + Math.random().toString(36).substr(2, 5),
      role: 'user',
      content: inputText,
      timestamp: new Date().toISOString(),
      type: 'text'
    };

    addMessage(userMsg);
    setInputText('');
    setIsTyping(true);

    try {
      // Simulate network delay
      await new Promise(res => setTimeout(res, 800));
      setIsTyping(false);

      const botMsgId = "bot-" + Date.now() + Math.random().toString(36).substr(2, 5);
      addMessage({
        id: botMsgId,
        role: 'char',
        content: '',
        timestamp: new Date().toISOString(),
        type: 'text'
      });

      const stateMsgs = useAppStore.getState().messagesByContact[currentCharacter.id] || [];
      const currentMessages = stateMsgs.filter(m => m.id !== userMsg.id && m.id !== botMsgId);
      const stream = generateChatResponseStream(currentCharacter, currentMessages, inputText, chatMode);
      
      let currentContent = "";
      for await (const chunk of stream) {
        currentContent += chunk;
        updateMessage(botMsgId, currentContent);
      }

      // Check for gifts after stream finishes
      let finalContent = currentContent;
      const giftRegex = /\[GIFT:(.*?)\]/g;
      let match;
      let giftFound = false;
      while ((match = giftRegex.exec(currentContent)) !== null) {
        const itemName = match[1].trim();
        const state = useAppStore.getState();
        const item = state.shoprjItems.find(i => i.name.toLowerCase() === itemName.toLowerCase());
        if (item) {
          // Actually buy/send the gift from Character to User
          state.buyShoprjItem(currentCharacter.id, 'user', item.id, 'Tặng bạn nè!');
          giftFound = true;
        }
      }

      // Remove the tags from the final string
      if (giftFound) {
        finalContent = finalContent.replace(giftRegex, '').trim();
        updateMessage(botMsgId, finalContent);
      }
    } catch (error) {
      console.error(error);
      setIsTyping(false);
    }
  };

  const handleSendSticker = (sticker: string) => {
    addMessage({
      id: "st-" + Date.now().toString() + Math.random().toString(36).substr(2, 5),
      role: 'user',
      content: sticker,
      timestamp: new Date().toISOString(),
      type: 'sticker'
    });
    setStickerDrawerOpen(false);
    
    // Auto respond with message or sticker
    setTimeout(() => {
        addMessage({
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            role: 'char',
            content: '*thả tim*',
            timestamp: new Date().toISOString(),
            type: 'text'
        });
    }, 1500);
  };

  const handleSendTransfer = () => {
    addMessage({
      id: "tr-" + Date.now().toString() + Math.random().toString(36).substr(2, 5),
      role: 'user',
      content: 'Cho em bé mua trà sữa ✦',
      timestamp: new Date().toISOString(),
      type: 'transfer'
    });
    setMoreDrawerOpen(false);
  };

  return (
    <div className="absolute inset-0 flex flex-col bg-[#FAFAFA]">
      
      {/* Background with blur */}
      <div 
        className="absolute inset-0 bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url('${themeSettings.chatBackground}')` }}
      ></div>
      <div className="absolute inset-0 bg-white/20 pointer-events-none"></div>

      {/* Top Bar */}
      <div className="h-[72px] pt-7 px-3 flex items-center bg-transparent z-10 sticky top-0 relative">
        <button onClick={popScreen} className="p-2 text-gray-700 active:scale-95">
          <ChevronLeft />
        </button>
        <div 
          className="flex items-center flex-grow ml-1 cursor-pointer"
          onClick={() => pushScreen('social')}
        >
          <div className="relative w-9 h-9">
             <img src={currentCharacter.avatar} alt="avatar" className="w-9 h-9 rounded-full object-cover border border-white shadow-sm" />
             {themeSettings.characterFrame && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[50px] h-[50px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
             )}
          </div>
          <div className="ml-3 flex flex-col justify-center">
            <span className="font-serif font-bold text-lg text-gray-900 leading-none">{currentCharacter.name}</span>
            <div className="flex items-center mt-1 space-x-1">
               <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
               <span className="text-[10px] text-gray-600 uppercase tracking-wide font-medium">{currentCharacter.mood}</span>
            </div>
          </div>
        </div>
        
        {/* Mode Toggle */}
        <div className="mr-2 p-0.5 bg-gray-200/60 rounded-full flex items-center shadow-inner">
           <button 
             onClick={() => setChatMode('online')}
             className={cn("px-2.5 py-1 text-[9px] font-bold uppercase rounded-full transition-all", chatMode === 'online' ? "bg-white/80 text-pink-500 shadow-sm" : "text-gray-500")}
           >
             Online
           </button>
           <button 
             onClick={() => setChatMode('offline')}
             className={cn("px-2.5 py-1 text-[9px] font-bold uppercase rounded-full transition-all", chatMode === 'offline' ? "bg-white/80 text-purple-500 shadow-sm" : "text-gray-500")}
           >
             Offline
           </button>
        </div>

        <button className="p-2 text-gray-700 active:scale-95">
          <MoreVertical size={20} />
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-grow overflow-y-auto px-4 py-4 space-y-4 relative z-0 hide-scrollbar pb-8" ref={scrollRef} style={{ scrollBehavior: 'smooth' }}>
        
        {messages.length === 0 && (
          <div className="flex justify-center my-6">
            <span className="bg-white/50 backdrop-blur-sm text-xs font-medium text-gray-500 px-3 py-1 rounded-full italic">
              [Cuộc trò chuyện bắt đầu ♡]
            </span>
          </div>
        )}

        {/* First system message from char */}
        {messages.length === 0 && !isTyping && (
             <div className="flex flex-col mb-4 items-center gap-2">
                <span className="bg-white/50 backdrop-blur-sm text-xs font-medium text-gray-500 px-3 py-1 rounded-full italic">Hôm nay</span>
             </div>
        )}

        {/* Message Rendering */}
        {messages.map((msg, idx) => {
          const isUser = msg.role === 'user';
          // Check if previous message was from the same person to group avatars
          const showAvatar = !isUser && (idx === 0 || messages[idx - 1].role !== 'char');

          if (msg.type === 'transfer') {
             return (
               <div key={msg.id} className="flex justify-center w-full my-4 relative group cursor-pointer">
                 <div className="w-[85%] bg-gradient-to-br from-pink-100 to-pink-200 p-4 rounded-3xl shadow-[0_8px_20px_-6px_rgba(232,160,180,0.5)] border border-white/50 transform transition-transform group-hover:scale-[1.02]">
                    <div className="flex items-center text-pink-500/80 mb-2">
                       <Heart size={14} className="mr-2 fill-current" />
                       <span className="text-xs font-medium uppercase tracking-wider">{isUser ? 'Chuyển khoản đến ' + currentCharacter.name : 'Nhận tiền từ ' + currentCharacter.name}</span>
                    </div>
                    <div className="text-3xl font-bold text-pink-800 font-serif mb-2 text-center pb-2 border-b border-pink-300/30">¥ 52,000</div>
                    <div className="text-sm font-medium text-pink-900/80 text-center italic mt-2">"{msg.content}"</div>
                 </div>
               </div>
             )
          }

          if (msg.type === 'sticker') {
             return (
                <div key={msg.id} className={cn("flex w-full mb-2", isUser ? "justify-end" : "justify-start")}>
                   {showAvatar ? (
                     <div className="relative w-7 h-7 mr-2 self-end mb-1 shrink-0">
                       <img src={currentCharacter.avatar} className="w-7 h-7 rounded-full object-cover shadow-sm" />
                       {themeSettings.characterFrame && (
                          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40px] h-[40px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
                       )}
                     </div>
                   ) : (
                     !isUser && <div className="w-9"></div>
                   )}
                   <div className={cn("text-6xl filter drop-shadow-md", isUser ? "mr-2" : "")}>{msg.content}</div>
                </div>
             )
          }

          const isGift = msg.content.startsWith('[ĐÃ TẶNG QUÀ:');

          return (
            <div 
              key={msg.id} 
              className={cn("flex w-full cursor-pointer relative", isUser ? "justify-end" : "justify-start")}
              onClick={() => setSelectedMessage(msg)}
            >
              {!isUser && (
                <div className={cn("relative w-9 h-9 mr-2 self-start mt-1 shrink-0", showAvatar ? "opacity-100" : "opacity-0")}>
                   <img src={currentCharacter.avatar} className="w-9 h-9 rounded-full object-cover shadow-sm" />
                   {themeSettings.characterFrame && (
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[50px] h-[50px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
                   )}
                </div>
              )}
              
              <div className={cn(
                "max-w-[70%] px-4 py-2.5 shadow-sm text-sm border relative",
                isGift ? "bg-[#fffbeb] border-[#fde68a] text-amber-900 rounded-[20px] font-medium" : 
                isUser 
                  ? "bg-gradient-to-br from-pink-400 to-pink-500 rounded-2xl rounded-tr-sm text-white border-transparent" 
                  : "bg-white/80 rounded-2xl rounded-tl-sm text-gray-800 border-gray-100"
              )}>
                {/* QQ-like Bubble Tail */}
                {!isGift && <div className={cn(
                  "absolute top-0 w-3 h-4",
                  isUser ? "-right-2 bg-pink-500" : "-left-2 bg-white/80 border-l border-t border-gray-100"
                )} style={{ clipPath: isUser ? "polygon(0 0, 0% 100%, 100% 0)" : "polygon(100% 0, 0 0, 100% 100%)" }} />}

                {isGift ? (
                    <div className="flex flex-col gap-1 items-center py-2 px-1 text-center">
                      <Gift size={24} className="text-amber-500 mb-1" />
                      <div>{msg.content.replace(/\[ĐÃ TẶNG QUÀ: (.*?)\]/, '🎁 $1').split(' - Lời nhắn:').join('\n\n"')} {msg.content.includes(' - Lời nhắn:') && '"'}</div>
                    </div>
                ) : (
                    <div className={cn("markdown-body text-[15px] leading-relaxed", isUser ? "prose-invert" : "")}>
                       <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                )}
                <div className={cn(
                  "text-[9px] opacity-60 mt-1",
                  isUser ? "text-right" : "text-left",
                  isGift ? "text-center opacity-40" : ""
                )}>
                  {format(new Date(msg.timestamp), 'HH:mm')}
                </div>
              </div>

              {isUser && (
                <div className="relative w-9 h-9 ml-2 self-start mt-1 shrink-0">
                   <img src={userProfile.chatAvatar || userProfile.avatar} className="w-9 h-9 rounded-full object-cover shadow-sm" />
                   {themeSettings.userFrame && (
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[50px] h-[50px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.userFrame})` }} />
                   )}
                </div>
              )}
            </div>
          );
        })}

        {isTyping && (
          <div className="flex w-full justify-start mt-2">
            <div className="relative w-7 h-7 mr-2 self-end mb-1 shrink-0">
               <img src={currentCharacter.avatar} className="w-7 h-7 rounded-full object-cover shadow-sm" />
               {themeSettings.characterFrame && (
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40px] h-[40px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
               )}
            </div>
            <div className="glass-bubble-char rounded-[20px] rounded-bl-[4px] px-4 py-3 flex items-center space-x-1.5 shadow-sm border border-white/50">
               <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></span>
               <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
               <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="min-h-[60px] p-2 glass-panel rounded-t-3xl border-t border-white/40 flex items-end gap-2 relative z-10 shrink-0 pb-6">
         <button className="p-2.5 rounded-full bg-white/50 text-gray-600 hover:bg-white/40 active:scale-95 transition-all">
            <Mic size={20} />
         </button>
         
         <div className="flex-grow flex items-center bg-white/30 border border-white rounded-[24px] pr-1 pl-4 shadow-inner min-h-[44px]">
           <input 
             type="text" 
             value={inputText}
             onChange={(e) => setInputText(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && handleSend()}
             placeholder="Nhắn tin..."
             className="w-full bg-transparent border-none outline-none text-sm py-2 placeholder:text-gray-400"
           />
           <button 
             className="p-2 text-pink-400 active:scale-95 transition-all hover:bg-pink-50/60 rounded-full"
             onClick={() => {
                setStickerDrawerOpen(!isStickerDrawerOpen);
                setMoreDrawerOpen(false);
             }}
           >
             <SmilePlus size={20} />
           </button>
         </div>

         {inputText.trim() ? (
            <button 
              onClick={handleSend}
              className="p-3.5 rounded-full bg-pink-400 text-white shadow-[0_4px_12px_rgba(244,114,182,0.4)] hover:bg-pink-500 active:scale-95 transition-all outline-none"
            >
              <Send size={18} className="translate-x-0.5" />
            </button>
         ) : (
            <button 
              className="p-3 rounded-full bg-white/50 border border-white text-gray-600 hover:bg-white/40 active:scale-95 transition-all shadow-sm"
              onClick={() => {
                 setMoreDrawerOpen(!isMoreDrawerOpen);
                 setStickerDrawerOpen(false);
              }}
            >
              <Paperclip size={20} />
            </button>
         )}
      </div>

      {/* Drawers */}
      <AnimatePresence>
         {(isStickerDrawerOpen || isMoreDrawerOpen || selectedMessage) && (
            <motion.div 
               initial={{ opacity: 0 }} 
               animate={{ opacity: 1 }} 
               exit={{ opacity: 0 }}
               className="absolute inset-0 bg-black/5 z-20"
               onClick={() => {
                  setStickerDrawerOpen(false);
                  setMoreDrawerOpen(false);
                  setSelectedMessage(null);
               }}
            />
         )}
         
         {/* Message Action Drawer */}
         {selectedMessage && (
            <motion.div 
               initial={{ y: "100%" }}
               animate={{ y: 0 }}
               exit={{ y: "100%" }}
               transition={{ type: "spring", bounce: 0, duration: 0.4 }}
               className="absolute bottom-0 left-0 right-0 h-auto bg-white/60 backdrop-blur-xl rounded-t-3xl border-t border-white shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-30 flex flex-col p-6 pb-12"
            >
               <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
               <div className="flex justify-between mb-6 border-b border-gray-100 pb-6 px-2">
                 {['💖', '😂', '🥺', '😡', '👍'].map(emoji => (
                   <button key={emoji} className="text-3xl hover:scale-110 active:scale-95 transition-transform bg-gray-50/60 rounded-full w-12 h-12 flex items-center justify-center p-1 shadow-sm border border-gray-100" onClick={() => { setSelectedMessage(null); handleSendSticker(emoji); }}>
                     {emoji}
                   </button>
                 ))}
               </div>
               <div className="flex flex-col space-y-2">
                  <button className="flex items-center space-x-3 text-gray-700 py-2.5 active:bg-gray-50/60 rounded-xl px-3 transition-colors" onClick={() => setSelectedMessage(null)}>
                     <div className="w-9 h-9 rounded-full bg-pink-50/60 flex items-center justify-center text-pink-500 shadow-sm"><Send size={16} className="-ml-0.5" /></div>
                     <span className="font-bold text-sm">Trả lời</span>
                  </button>
                  <button className="flex items-center space-x-3 text-gray-700 py-2.5 active:bg-gray-50/60 rounded-xl px-3 transition-colors" onClick={() => { if (selectedMessage.type === 'text') navigator.clipboard.writeText(selectedMessage.content); setSelectedMessage(null); }}>
                     <div className="w-9 h-9 rounded-full bg-gray-50/60 flex items-center justify-center text-gray-500 shadow-sm border border-gray-100"><Paperclip size={16} /></div>
                     <span className="font-bold text-sm">Sao chép</span>
                  </button>
                  {selectedMessage.role === 'user' && (
                     <button className="flex items-center space-x-3 text-red-600 py-2.5 active:bg-red-50 rounded-xl px-3 transition-colors" onClick={() => setSelectedMessage(null)}>
                        <div className="w-9 h-9 rounded-full bg-red-50 flex items-center justify-center text-red-500 shadow-sm"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"></path><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg></div>
                        <span className="font-bold text-sm">Thu hồi tin nhắn</span>
                     </button>
                  )}
               </div>
            </motion.div>
         )}

         {/* Sticker Drawer */}
         {isStickerDrawerOpen && (
            <motion.div 
               initial={{ y: "100%" }}
               animate={{ y: 0 }}
               exit={{ y: "100%" }}
               transition={{ type: "spring", bounce: 0, duration: 0.4 }}
               className="absolute bottom-0 left-0 right-0 h-64 bg-white/50 backdrop-blur-xl rounded-t-3xl border-t border-white shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-30 flex flex-col p-4"
            >
               <div className="w-12 h-1 bg-gray-200 rounded-full mx-auto mb-4" />
               <div className="flex gap-4 mb-4 border-b border-gray-100 pb-2">
                  <span className="text-xs font-bold uppercase tracking-widest text-pink-500 border-b-2 border-pink-500 pb-1">Gần đây</span>
                  <span className="text-xs font-bold uppercase tracking-widest text-gray-400">Yêu thích</span>
               </div>
               <div className="grid grid-cols-4 gap-4 overflow-y-auto no-scrollbar">
                  {['🎀', '🌸', '🧸', '☕', '🌟', '💝', '✨', '🍓', '🍰', '🍼', '🐾', '💭'].map(emoji => (
                     <button key={emoji} onClick={() => handleSendSticker(emoji)} className="text-4xl hover:scale-110 active:scale-90 transition-transform">
                        {emoji}
                     </button>
                  ))}
               </div>
            </motion.div>
         )}

         {/* More Drawer */}
         {isMoreDrawerOpen && (
            <motion.div 
               initial={{ y: "100%" }}
               animate={{ y: 0 }}
               exit={{ y: "100%" }}
               transition={{ type: "spring", bounce: 0, duration: 0.4 }}
               className="absolute bottom-0 left-0 right-0 h-64 bg-[#F8E8EE]/95 backdrop-blur-xl rounded-t-3xl border-t border-white shadow-[0_-10px_40px_rgba(0,0,0,0.05)] z-30 flex flex-col p-6"
            >
               <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
               <div className="grid grid-cols-4 gap-y-6 gap-x-4">
                  <div className="flex flex-col items-center group cursor-pointer">
                     <div className="w-14 h-14 bg-white/80 rounded-2xl flex items-center justify-center text-[#1A1A1A] shadow-sm transform transition-transform group-hover:scale-105 border border-white">
                        <ImageIcon size={24} />
                     </div>
                     <span className="text-[10px] uppercase font-bold tracking-wider mt-2 text-gray-600">Gửi Ảnh</span>
                  </div>
                  <div className="flex flex-col items-center group cursor-pointer" onClick={handleSendTransfer}>
                     <div className="w-14 h-14 bg-[#1A1A1A] text-white rounded-2xl flex items-center justify-center shadow-md transform transition-transform group-hover:scale-105">
                        <Wallet size={24} />
                     </div>
                     <span className="text-[10px] uppercase font-bold tracking-wider mt-2 text-[#1A1A1A]">Chuyển Tiền</span>
                  </div>
                  <div className="flex flex-col items-center group cursor-pointer">
                     <div className="w-14 h-14 bg-white/80 rounded-2xl flex items-center justify-center text-[#1A1A1A] shadow-sm transform transition-transform group-hover:scale-105 border border-white">
                        <MapPin size={24} />
                     </div>
                     <span className="text-[10px] uppercase font-bold tracking-wider mt-2 text-gray-600">Vị Trí</span>
                  </div>
                  <div className="flex flex-col items-center group cursor-pointer">
                     <div className="w-14 h-14 bg-white/80 opacity-50 rounded-2xl flex items-center justify-center text-[#1A1A1A] border border-white">
                        <Mic size={24} />
                     </div>
                     <span className="text-[10px] uppercase font-bold tracking-wider mt-2 text-gray-500">Ghi Âm</span>
                  </div>
               </div>
            </motion.div>
         )}
      </AnimatePresence>
    </div>
  );
}
