import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Heart, Music2, Upload, Shuffle, Repeat, Plus, Link, Check, X, Edit2 } from 'lucide-react';
import { format } from 'date-fns';
import { vi } from 'date-fns/locale';
import { useAppStore } from '../store/useAppStore';

export function ProfileWidget() {
  const { userProfile, themeSettings, updateUserProfile, pushScreen } = useAppStore();
  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const [tempStatus, setTempStatus] = useState(userProfile?.status || '');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!userProfile) return null;

  const handleSaveStatus = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    updateUserProfile({ status: tempStatus });
    setIsEditingStatus(false);
  };

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateUserProfile({ coverPhoto: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full h-full relative group">
      <div 
        className="w-full h-full backdrop-blur-xl bg-[#FFF0F5]/30 border border-white/60 rounded-[32px] p-5 relative z-10 shadow-[0_8px_32px_rgba(255,192,203,0.3)] cursor-pointer hover:bg-[#FFF0F5]/40 transition-colors flex flex-col justify-between overflow-hidden"
        onClick={() => pushScreen('settings')}
      >
        {userProfile.coverPhoto && (
           <div 
              className="absolute inset-0 z-[-1] bg-cover bg-center opacity-90" 
              style={{ backgroundImage: `url(${userProfile.coverPhoto})`}} 
           >
             <div className="absolute inset-0 bg-black/10" />
           </div>
        )}
        
        <div className="flex items-start gap-4">
          <div className="relative shrink-0">
             <div className="w-16 h-16 rounded-full border-[3px] border-[#F2C4CE] p-0.5 shadow-lg relative z-0">
               <img src={userProfile.avatar} alt="avatar" className="w-full h-full rounded-full object-cover" />
               <div className="absolute -bottom-1 -right-1 bg-white/80 rounded-full p-1 shadow-sm border border-pink-100 flex items-center justify-center min-w-[20px] min-h-[20px] z-20">
                 <span className="text-[10px] leading-none">{userProfile.badge}</span>
               </div>
             </div>
             {themeSettings.userFrame && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[82px] h-[82px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.userFrame})` }} />
             )}
          </div>
          <div className="flex-grow pt-1">
            <h2 className="text-[#FAFAFA] text-2xl font-serif italic leading-tight drop-shadow-sm">{userProfile.name}</h2>
            <div className="mt-1 flex items-center gap-2 bg-black/20 backdrop-blur-sm rounded-full pl-2 pr-3 py-1 border border-white/20 w-fit max-w-full">
              <div className="w-2 h-2 rounded-full bg-pink-300 shadow-[0_0_8px_rgba(244,143,177,0.8)] animate-pulse shrink-0"></div>
              <div className="flex items-center gap-1 group/status w-full">
                 <span className="text-[#FAFAFA] text-[13px] opacity-95 truncate italic drop-shadow-sm font-medium">{userProfile.status}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-white/40 to-transparent my-1"></div>
        
        <div className="flex justify-between items-center text-white/95 text-[11px] italic font-medium w-full">
           <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-pink-100/20 border border-pink-100/30 shadow-sm backdrop-blur-md">♡ Tham gia: Hôm nay</span>
        </div>
      </div>
      
      <label 
         className={`absolute top-4 right-4 z-20 text-white/70 hover:text-white p-1.5 bg-black/20 hover:bg-black/40 rounded-full cursor-pointer transition-colors ${userProfile.coverPhoto ? 'opacity-0 group-hover:opacity-100' : 'opacity-60 hover:opacity-100'}`}
         title="Tải ảnh bìa"
         onClick={(e) => e.stopPropagation()}
         onPointerDown={(e) => e.stopPropagation()}
      >
         <Upload size={14} />
         <input type="file" className="hidden" accept="image/*" onChange={handleCoverChange} />
      </label>
    </div>
  );
}

export function ClockWidget() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none">
      <div className="text-sm text-white/90 drop-shadow-md tracking-wider mb-1 font-medium">
        {format(time, 'M月d日 EEEE', { locale: vi }).replace('tháng ', '').replace('Thứ ', '星期')}
      </div>
      <div className="text-6xl font-black text-white tracking-widest drop-shadow-xl" style={{ textShadow: '0 4px 10px rgba(0,0,0,0.3)' }}>
        {format(time, 'HH:mm')}
      </div>
    </div>
  );
}

export function PhotoWidget({ widgetId = 'default', editMode = false }: { widgetId?: string, editMode?: boolean }) {
  const { customPhotoWidgets, updateCustomPhotoWidget } = useAppStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const placeholder = "https://images.unsplash.com/photo-1516962365319-35a8286a0b16?q=80&w=400&auto=format&fit=crop";
  const rawSource = customPhotoWidgets?.[widgetId];
  const [imageSource, setImageSource] = useState(rawSource && rawSource.trim() !== '' ? rawSource : placeholder);

  useEffect(() => {
    setImageSource(rawSource && rawSource.trim() !== '' ? rawSource : placeholder);
  }, [rawSource, placeholder]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateCustomPhotoWidget(widgetId, reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div 
      className="w-full h-full bg-white/40 backdrop-blur-md p-2 rounded-[28px] shadow-lg border border-white/40 flex flex-col relative overflow-hidden group cursor-pointer transition-transform active:scale-[0.98]"
      onClick={() => fileInputRef.current?.click()}
    >
      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
      <div className="absolute inset-2 rounded-[20px] overflow-hidden z-0 bg-pink-50/60">
        <img 
           src={imageSource} 
           alt="" 
           className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
           onError={() => setImageSource(placeholder)}
        />
      </div>
      {editMode && (
        <div 
          className="absolute inset-2 bg-black/30 rounded-[20px] flex items-center justify-center z-10 transition-opacity"
          onPointerDown={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
        >
           <div className="flex flex-col items-center">
              <Upload size={24} className="text-white drop-shadow-md" />
              <span className="text-white text-[10px] font-bold mt-1">Sửa ảnh</span>
           </div>
        </div>
      )}
    </div>
  );
}

export function MusicWidget() {
  const [isPlaying, setIsPlaying] = useState(false);
  return (
    <div className="w-full h-full bg-[#fff9fc]/80 backdrop-blur-xl p-4 rounded-[32px] shadow-[0_8px_30px_rgba(255,192,203,0.4)] border border-white/60 flex flex-col justify-between cursor-pointer transition-transform active:scale-95 relative overflow-hidden">
      <div className="flex justify-between items-start z-10">
        <div className="w-16 h-16 rounded-full bg-black shadow-xl flex items-center justify-center p-1 relative" style={{ animation: isPlaying ? 'spin 4s linear infinite' : 'none' }}>
           <div className="w-full h-full rounded-full border border-gray-600 relative overflow-hidden">
             {/* Vinyl grooves */}
             <div className="absolute inset-0 rounded-full border border-white/10 m-1"></div>
             <div className="absolute inset-0 rounded-full border border-white/10 m-2"></div>
             <div className="absolute inset-0 rounded-full border border-white/10 m-3"></div>
             <div className="absolute inset-0 bg-pink-200 rounded-full w-6 h-6 m-auto flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-black rounded-full"></div>
             </div>
           </div>
        </div>
        <button className="text-pink-400 hover:text-pink-600 transition-colors">
          <Heart size={16} fill="currentColor" />
        </button>
      </div>

      <div className="z-10 mt-2">
        <h3 className="text-sm font-bold text-gray-800 leading-tight">My Melody</h3>
        <p className="text-[10px] text-gray-500 mt-0.5">Kawaii artist</p>
      </div>

      <div className="flex items-center justify-between text-pink-500 mt-2 z-10 bg-white/50 rounded-2xl p-1.5 border border-white/60">
        <button className="p-1 hover:bg-pink-100 rounded-full transition-colors"><SkipBack size={14} /></button>
        <button 
          className="w-8 h-8 flex items-center justify-center bg-pink-400 text-white rounded-full shadow-md hover:bg-pink-500 transition-colors"
          onClick={(e) => { e.stopPropagation(); setIsPlaying(!isPlaying); }}
        >
          {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
        </button>
        <button className="p-1 hover:bg-pink-100 rounded-full transition-colors"><SkipForward size={14} /></button>
      </div>

      {/* Decorative background note */}
      <div className="absolute -right-4 -bottom-4 text-pink-200/40 rotate-12 pointer-events-none">
        <svg width="100" height="100" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
          <path d="M9 18V5L21 3V16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="6" cy="18" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <circle cx="18" cy="16" r="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
    </div>
  );
}

import localforage from 'localforage';
import ReactPlayer from 'react-player';

export function PlayerWidget({ widgetId, editMode }: { widgetId?: string, editMode?: boolean }) {
  const { playerWidgets, updatePlayerWidget, globalMediaId, globalMediaUrl, isGlobalPlaying, setGlobalMedia, toggleGlobalPlay, globalMediaProgress, globalMediaCurrentTime, globalMediaDuration } = useAppStore();
  const wId = widgetId || 'default-player';
  const data = playerWidgets?.[wId] || { 
    title: 'carpe diem', 
    coverImage: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=1000&auto=format&fit=crop', 
    thumbnail: 'https://ui-avatars.com/api/?name=CD&background=333&color=fff', 
    mediaUrl: '' 
  };

  const isPlaying = globalMediaId === data.mediaUrl && isGlobalPlaying;

  const displayProgress = isPlaying ? globalMediaProgress : 0;
  const displayCurrentTime = isPlaying ? globalMediaCurrentTime : 0;
  const displayDuration = isPlaying ? globalMediaDuration : 0;

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const [isEditing, setIsEditing] = useState(false);
  const [tempData, setTempData] = useState(data);

  const coverInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'coverImage' | 'thumbnail') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempData(prev => ({ ...prev, [field]: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAudioFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const localKey = `localforage:media-${wId}`;
      try {
        await localforage.setItem(localKey, file);
        setTempData(prev => ({ ...prev, mediaUrl: localKey }));
      } catch (err) {
        console.error("Failed to save audio to localforage", err);
      }
    }
  };

  useEffect(() => { 
    setTempData(data); 
  }, [data.title, data.coverImage, data.thumbnail, data.mediaUrl]); 

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    updatePlayerWidget(wId, tempData);
    setIsEditing(false);
  };

  const handlePlayClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!data.mediaUrl) {
      alert("Vui lòng thiết lập File nhạc trước (nhấn nút sửa bên phải -> Upload MP3)");
      return;
    }
    
    if (globalMediaId === data.mediaUrl) {
      toggleGlobalPlay();
    } else {
      if (data.mediaUrl.startsWith('localforage:')) {
        const file = await localforage.getItem<Blob | File>(data.mediaUrl);
        if (file) {
          const blobUrl = URL.createObjectURL(file);
          setGlobalMedia(data.mediaUrl, blobUrl, true);
        } else {
          alert('Không tìm thấy file nhạc đã lưu. Vui lòng tải lại.');
        }
      } else {
        setGlobalMedia(data.mediaUrl, data.mediaUrl, true); // Fallback for old string URLs
      }
    }
  };

  return (
    <div className="w-full h-full relative rounded-[32px] overflow-hidden shadow-lg group">
      {/* Background Cover */}
      <div 
        className="absolute inset-0 bg-cover bg-center grayscale opacity-80"
        style={{ backgroundImage: `url(${data.coverImage})` }}
      />
      <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" />

      {!isEditing ? (
        <div className="absolute inset-0 p-4 sm:p-5 flex flex-col justify-between z-10 text-white">
           <div className="flex items-center gap-3">
              <img src={data.thumbnail} className="w-10 h-10 rounded-full border border-white/40 shadow-sm object-cover" />
              <span className="font-bold text-white/90 drop-shadow-md text-sm truncate max-w-[150px]">{data.title}</span>
           </div>

           <div className="flex flex-col gap-2 mt-auto">
              <div className="flex items-center justify-between text-[10px] font-medium text-white/80 font-mono">
                 <span>{formatTime(displayCurrentTime)}</span>
                 <div className="flex-grow mx-3 h-1 bg-white/20 rounded-full relative">
                    <div className="absolute left-0 top-0 bottom-0 bg-white/80 rounded-full opacity-80" style={{ width: `${displayProgress * 100}%` }}></div>
                 </div>
                 <span>{formatTime(displayDuration)}</span>
              </div>

              <div className="flex items-center justify-between mt-1 px-1">
                 <button className="text-white/70 hover:text-white transition-colors active:scale-95"><Shuffle size={18} strokeWidth={2} /></button>
                 <button className="text-white/90 hover:text-white transition-colors active:scale-95"><SkipBack size={20} fill="currentColor" /></button>
                 <button 
                  className="w-10 h-10 flex items-center justify-center bg-white/80 text-black rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all"
                  onClick={handlePlayClick}
                 >
                   {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                 </button>
                 <button className="text-white/90 hover:text-white transition-colors active:scale-95"><SkipForward size={20} fill="currentColor" /></button>
                 <button className="text-white/70 hover:text-white transition-colors active:scale-95"><Repeat size={18} strokeWidth={2} /></button>
                 <button 
                  className="text-white/70 hover:text-white transition-colors active:scale-95"
                  onClick={(e) => {
                     e.stopPropagation();
                     if (editMode) setIsEditing(true);
                  }}
                 >
                   {editMode ? <Link size={18} strokeWidth={2} /> : <Plus size={20} strokeWidth={2} />}
                 </button>
              </div>
           </div>
        </div>
      ) : (
        <form onSubmit={handleSave} onPointerDown={e => e.stopPropagation()} className="absolute inset-0 bg-black/80 backdrop-blur-md z-30 p-4 flex flex-col gap-2 justify-center">
           <input type="file" accept="image/*" className="hidden" ref={coverInputRef} onChange={e => handleImageFileChange(e, 'coverImage')} />
           <input type="file" accept="image/*" className="hidden" ref={thumbInputRef} onChange={e => handleImageFileChange(e, 'thumbnail')} />
           
           <input type="text" value={tempData.title} onChange={e => setTempData({...tempData, title: e.target.value})} placeholder="Title" className="bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
           <div className="flex gap-2">
             <input type="text" value={tempData.coverImage} onChange={e => setTempData({...tempData, coverImage: e.target.value})} placeholder="Cover Image URL" className="flex-grow bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors empty:min-w-0" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
             <button type="button" onClick={(e) => { e.stopPropagation(); coverInputRef.current?.click(); }} className="p-2 bg-white/10 rounded-lg text-white hover:bg-white/20"><Upload size={14} /></button>
           </div>
           <div className="flex gap-2">
             <input type="text" value={tempData.thumbnail} onChange={e => setTempData({...tempData, thumbnail: e.target.value})} placeholder="Thumbnail URL" className="flex-grow bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors empty:min-w-0" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
             <button type="button" onClick={(e) => { e.stopPropagation(); thumbInputRef.current?.click(); }} className="p-2 bg-white/10 rounded-lg text-white hover:bg-white/20"><Upload size={14} /></button>
           </div>
           
           {/* Audio Input instead of old media text input */}
           <input type="file" accept="audio/*" className="hidden" ref={audioInputRef} onChange={handleAudioFileChange} />
           <button 
             type="button" 
             onClick={(e) => { e.stopPropagation(); audioInputRef.current?.click(); }}
             onPointerDown={(e) => { e.stopPropagation(); audioInputRef.current?.click(); }}
             className="w-full mt-1 bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none hover:bg-white/20 transition-colors flex justify-center items-center gap-2 z-50 cursor-pointer text-white relative"
           >
             <Music2 size={14} />
             {tempData.mediaUrl?.startsWith('localforage:') ? 'Update Audio File' : 'Upload MP3'}
           </button>

           <div className="flex justify-end gap-2 mt-2">
             <button type="button" onClick={(e) => { e.stopPropagation(); setIsEditing(false); }} className="text-xs p-2 text-white/60 hover:text-white"><X size={16} /></button>
             <button type="submit" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} className="text-xs bg-white/80 hover:bg-gray-200 transition-colors text-black p-2 px-3 rounded-lg flex items-center"><Check size={14} className="mr-1"/> Save</button>
           </div>
        </form>
      )}
    </div>
  );
}

export function StatusWidget({ widgetId, editMode }: { widgetId?: string, editMode?: boolean }) {
  const wId = widgetId || 'status-1';
  const { userProfile, statusWidgets, updateStatusWidget } = useAppStore();
  const data = statusWidgets?.[wId] || {
    batteryText: '电量',
    nameText: userProfile?.name || 'SanYa',
    subText: '椰梦',
    avatarUrl: userProfile?.avatar || 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?q=80&w=200'
  };

  const [time, setTime] = useState(new Date());
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [tempData, setTempData] = useState(data);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTempData(data);
  }, [data.batteryText, data.nameText, data.subText, data.avatarUrl]);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let batteryMockTimer: any;
    const fetchBattery = async () => {
      try {
        if ('getBattery' in navigator) {
          const battery: any = await (navigator as any).getBattery();
          setBatteryLevel(Math.floor(battery.level * 100));
          
          battery.addEventListener('levelchange', () => {
            setBatteryLevel(Math.floor(battery.level * 100));
          });
        } else {
          // Fallback if not supported
          setBatteryLevel(35);
        }
      } catch (err) {
        console.warn("Battery API not available/failed", err);
        setBatteryLevel(35);
      }
    };
    
    fetchBattery();
  }, []);

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempData({ ...tempData, avatarUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    updateStatusWidget(wId, tempData);
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <div className="w-full h-full bg-black/80 rounded-[32px] p-3 flex flex-col items-center justify-center z-50 text-white shadow-xl backdrop-blur-md">
        <div className="text-xs font-semibold mb-2 text-white/80">Edit Status Widget</div>
        <div className="flex flex-col gap-2 w-full max-h-full overflow-y-auto hide-scrollbar pb-1">
          <input type="text" value={tempData.batteryText} onChange={e => setTempData({...tempData, batteryText: e.target.value})} placeholder="Battery Text" className="bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
          <input type="text" value={tempData.nameText} onChange={e => setTempData({...tempData, nameText: e.target.value})} placeholder="Name" className="bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
          <input type="text" value={tempData.subText} onChange={e => setTempData({...tempData, subText: e.target.value})} placeholder="Subtext" className="bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
          
           <div className="flex gap-1 w-full relative">
             <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageFileChange} />
             <input type="text" value={tempData.avatarUrl} onChange={e => setTempData({...tempData, avatarUrl: e.target.value})} placeholder="Image URL" className="flex-grow bg-white/10 border border-white/20 text-white text-xs p-2 rounded-lg outline-none focus:bg-white/20 transition-colors empty:min-w-0" onClick={e => e.stopPropagation()} onPointerDown={e => e.stopPropagation()} />
             <button type="button" onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }} onPointerDown={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }} className="p-2 bg-white/10 rounded-lg text-white hover:bg-white/20 z-50 relative"><Upload size={14} /></button>
           </div>
           
           <div className="flex justify-end gap-2 mt-1">
             <button type="button" onClick={(e) => { e.stopPropagation(); setIsEditing(false); }} className="text-xs p-2 text-white/60 hover:text-white"><X size={16} /></button>
             <button type="button" onClick={handleSave} onPointerDown={handleSave} className="text-xs bg-white/80 hover:bg-gray-200 transition-colors text-black p-2 px-3 rounded-lg flex items-center relative z-50"><Check size={14} className="mr-1"/> Save</button>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full p-0 flex flex-col justify-between cursor-pointer transition-transform active:scale-95 z-0 group relative rounded-[32px] border border-white/30 bg-white/5 backdrop-blur-[2px] shadow-[inset_0_0_10px_rgba(255,255,255,0.1)]">
      {editMode && (
        <button 
          onClick={(e) => { e.stopPropagation(); setIsEditing(true); }}
          className="absolute -top-2 -right-2 bg-black/60 backdrop-blur text-white p-1.5 rounded-full z-[100] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto shadow-lg hover:bg-black/80"
        >
          <Edit2 size={12} />
        </button>
      )}

      {/* Top half: Battery Pill */}
      <div className="h-1/2 w-full flex items-center justify-center pt-2 pointer-events-none">
        <div className="w-[85%] h-[75%] bg-white/20 backdrop-blur-xl border border-white/50 rounded-full flex items-center justify-center shadow-[inset_0_1px_3px_rgba(255,255,255,0.7),0_4px_12px_rgba(0,0,0,0.1)] relative overflow-hidden">
             {/* Text elements */}
             <div className="flex items-center gap-4 text-white font-mono z-10 font-bold tracking-wider relative drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]" style={{ fontFamily: '"VT323", "DotGothic16", monospace', letterSpacing: '0.05em' }}>
                <span className="text-base" style={{ fontFamily: '"DotGothic16", sans-serif' }}>{data.batteryText}</span>
                <span className="text-xl">{batteryLevel !== null ? `${batteryLevel}%` : '35%'}</span>
             </div>
        </div>
      </div>

      {/* Bottom half: Profile Pill */}
      <div className="h-1/2 w-full flex items-center justify-center pb-2 pointer-events-none">
        <div className="w-[90%] h-[85%] bg-white/20 backdrop-blur-xl border border-white/50 rounded-[40px] flex shadow-[inset_0_1px_3px_rgba(255,255,255,0.7),0_4px_12px_rgba(0,0,0,0.1)] relative overflow-hidden px-2 items-center gap-3">
             {/* Left Avatar Area */}
             <div className="w-[50px] h-[50px] ml-1 rounded-full overflow-hidden border border-white/30 flex-shrink-0 relative mix-blend-luminosity z-10 opacity-90 grayscale">
                 <img src={data.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                 <div className="absolute inset-0 border-[2px] border-black/10 rounded-full z-20"></div>
                 <div className="absolute inset-0 bg-gradient-to-tr from-black/30 to-transparent z-20 mix-blend-overlay"></div>
             </div>

             {/* Right Text Area */}
             <div className="flex flex-col justify-center gap-[2px] min-w-0 z-10">
                 <div className="text-white text-[12px] font-semibold tracking-wide drop-shadow-md whitespace-nowrap overflow-hidden text-ellipsis" style={{ fontFamily: '"Inter", sans-serif' }}>
                     {data.nameText} · {data.subText}
                 </div>
                 <div className="text-white text-[28px] font-mono leading-[1.1] tracking-tight drop-shadow-md" style={{ fontFamily: '"VT323", "DotGothic16", monospace' }}>
                    {format(time, 'HH:mm')}
                 </div>
             </div>
        </div>
      </div>
    </div>
  );
}

export function SmallControlWidget() {
  return (
    <div className="bg-white/40 backdrop-blur-md p-3 rounded-[24px] shadow-md border border-white/60 aspect-square flex flex-col justify-between">
      <div className="flex justify-between items-center text-gray-500">
        <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_5px_#4ade80]"></div>
        <span className="text-[9px] font-bold uppercase tracking-wider">Status</span>
      </div>
      <div className="flex gap-2 justify-center">
         <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.55a11 11 0 0 1 14.08 0"></path><path d="M1.42 9a16 16 0 0 1 21.16 0"></path><path d="M8.53 16.11a6 6 0 0 1 6.95 0"></path><line x1="12" y1="20" x2="12.01" y2="20"></line></svg>
         </div>
         <div className="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-500">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m14 7 3-3 3 3"></path><path d="M17 4v16"></path><path d="m10 17-3 3-3-3"></path><path d="M7 20V4"></path></svg>
         </div>
      </div>
    </div>
  );
}
