import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';
import { MapPin, Navigation } from 'lucide-react';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function MapScreen() {
  const { currentCharacter, themeSettings } = useAppStore();
  if (!currentCharacter) return null;

  const currentTime = format(new Date(), 'HH:mm');
  const isNight = parseInt(format(new Date(), 'HH')) >= 18 || parseInt(format(new Date(), 'HH')) < 5;

  return (
    <AppLayout title="Vị trí" bgClass={isNight ? "bg-[#1A1A1A]" : "bg-[#F8E8EE]"} appId="map">
      <div className="relative w-full h-[60vh] overflow-hidden rounded-b-[40px] shadow-lg">
         {/* Fake Map Background */}
         <img 
            src={isNight 
                ? "https://images.unsplash.com/photo-1519069399451-b96ab3f898a3?q=80&w=1000&auto=format&fit=crop" 
                : "https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1000&auto=format&fit=crop"} 
            className="w-full h-full object-cover opacity-60" 
         />
         <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
         
         {/* Current Location Pin */}
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center animate-bounce duration-200">
            <div className="relative w-16 h-16 mb-2 shrink-0">
               <div className="w-16 h-16 rounded-full border-4 border-white shadow-xl overflow-hidden bg-white/80 relative z-0">
                  <img src={currentCharacter.avatar} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 ring-inset ring-2 ring-[#C9748A] rounded-full pointer-events-none"></div>
               </div>
               {themeSettings?.characterFrame && (
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[82px] h-[82px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
               )}
            </div>
            <div className="bg-white/80 text-[#1A1A1A] font-bold text-[10px] px-3 py-1.5 rounded-full shadow-lg border border-gray-100 flex items-center">
               <Navigation size={10} className="mr-1 text-[#C9748A]" /> Đang ở đây
            </div>
         </div>
      </div>

      <div className={cn("px-6 pt-8 pb-24", isNight ? "text-white" : "text-[#1A1A1A]")}>
         {/* Status Card */}
         <div className={cn(
             "rounded-[32px] p-6 shadow-xl border relative overflow-hidden",
             isNight ? "bg-[#2D2D2D]/80 border-[#D4D4D4]/20 backdrop-blur-md" : "bg-white/80 border-[#F2C4CE]"
         )}>
             <div className="flex justify-between items-start mb-4">
                 <div>
                    <div className={cn("text-[10px] uppercase tracking-widest font-bold mb-1", isNight ? "text-white/60" : "text-gray-500")}>Vị trí hiện hành</div>
                    <h2 className="font-serif italic text-2xl">Quán Café Nguyệt</h2>
                 </div>
                 <div className="text-xs bg-[#C9748A] text-white px-2 py-1 rounded-full font-bold">{currentTime}</div>
             </div>
             
             <p className={cn("text-sm italic leading-relaxed", isNight ? "text-white/80" : "text-gray-700")}>
                "Đang uống cà phê một mình, nghĩ linh tinh... Giá mà có ai đó ngồi đối diện lúc này thì tốt biết mấy ✦"
             </p>
         </div>

         <div className="mt-8 flex justify-between items-center border-b border-opacity-20 border-[#D4D4D4] pb-2 mb-4">
             <h3 className="font-serif italic text-lg opacity-80">Địa điểm yêu thích</h3>
         </div>

         <div className="space-y-3">
             <div className={cn("p-4 rounded-2xl flex items-center", isNight ? "bg-white/5" : "bg-white/80 shadow-sm")}>
                <div className="w-10 h-10 rounded-full bg-[#C9748A]/10 text-[#C9748A] flex items-center justify-center mr-4">
                   <MapPin size={18} />
                </div>
                <div>
                   <div className="text-sm font-bold">Công viên Hoa Mơ</div>
                   <div className={cn("text-[10px] mt-0.5", isNight ? "text-white/50" : "text-gray-500")}>Nơi hay dạo bước lúc chiều muộn</div>
                </div>
             </div>
         </div>

      </div>
    </AppLayout>
  );
}
