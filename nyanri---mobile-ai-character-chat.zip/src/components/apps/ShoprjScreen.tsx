import { useState, useMemo, useRef } from 'react';
import { useAppStore, ShoprjItem } from '../../store/useAppStore';
import { ChevronLeft, Search, Plus, Heart, ShoppingBag, Send, X, Image as ImageIcon, Sparkles } from 'lucide-react';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { generateGeminiResponse } from '../../services/geminiService';
import AppLayout from './AppLayout';

export default function ShoprjScreen() {
    const { userProfile, contacts, shoprjItems, shoprjTransactions, shoprjWishlist, buyShoprjItem, toggleShoprjWishlist, popScreen, addShoprjItem, updateUserProfile, updateShoprjItem } = useAppStore();
    const [activeTab, setActiveTab] = useState('destiny');
    const [selectedReceiver, setSelectedReceiver] = useState<string | null>(null);
    const [viewMode, setViewMode] = useState<'home' | 'buy'>('home');
    const [selectedItem, setSelectedItem] = useState<ShoprjItem | null>(null);
    const [showAddItem, setShowAddItem] = useState(false);
    const [newItemName, setNewItemName] = useState('');
    const [newItemPrice, setNewItemPrice] = useState('');
    const [newItemImage, setNewItemImage] = useState('');
    const [isGeneratingAI, setIsGeneratingAI] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleAIGenerate = async () => {
        setIsGeneratingAI(true);
        try {
            const prompt = `Tạo một món đồ nhỏ bé kỳ diệu hoặc lãng mạn. Trả về JSON với 3 trường: "name" (tên món đồ, ví dụ: "Lọ ước nguyện"), "price" (số ngẫu nhiên dưới 100), "imageQuery" (1 từ khóa duy nhất bằng tiếng anh để tìm ảnh unsplash). CHỈ TRẢ VỀ JSON.`;
            const result = await generateGeminiResponse(prompt, { temperature: 0.9 });
            const jsonText = result.replace(/```json/g, '').replace(/```/g, '').trim();
            const data = JSON.parse(jsonText);
            
            setNewItemName(data.name);
            setNewItemPrice(data.price.toString());
            setNewItemImage(`https://picsum.photos/seed/${encodeURIComponent(data.imageQuery)}/500/500`);
        } catch (e) {
            console.error("AI Gen error", e);
        }
        setIsGeneratingAI(false);
    };

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setNewItemImage(event.target?.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleUpdateProfileAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                updateUserProfile({ avatar: event.target?.result as string });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleUpdateItemImage = (itemId: string, e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                updateShoprjItem(itemId, { image: event.target?.result as string });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleAddItem = () => {
        if (!newItemName || !newItemImage || !newItemPrice) return;
        addShoprjItem({
            name: newItemName,
            price: parseFloat(newItemPrice) || 0,
            image: newItemImage
        });
        setShowAddItem(false);
        setNewItemName('');
        setNewItemPrice('');
        setNewItemImage('');
    };
    
    const inventory = shoprjTransactions.filter(tx => tx.receiverId === 'user');
    
    const tabs = [
        { id: 'wishlist', label: 'Wishlist', count: shoprjWishlist.length },
        { id: 'destiny', label: 'Destiny', count: shoprjTransactions.length },
        { id: 'inventory', label: 'Inventory', count: inventory.length }
    ];

    const handleBuyItem = (item: ShoprjItem, receiverId: string, note?: string) => {
        buyShoprjItem('user', receiverId, item.id, note);
        setViewMode('home');
    };

    if (viewMode === 'buy') {
        const item = selectedItem;
        return (
            <AppLayout 
                title={item ? "Mua Quà" : "Cửa hàng"} 
                appId="shoprj" 
                bgClass="bg-[#F7F7F7]"
                headerClass="text-gray-900"
                onBack={() => setViewMode('home')}
            >
                <div className="flex-grow overflow-y-auto px-6 py-4 hide-scrollbar">
                    {item ? (
                        <div className="space-y-6">
                            <div className="w-full aspect-square rounded-[32px] overflow-hidden bg-white shadow-sm border border-gray-100 relative">
                                <img src={item.image} className="w-full h-full object-cover" />
                            </div>
                            <div className="flex justify-between items-start">
                                <div>
                                    <h2 className="text-2xl font-serif text-gray-900">{item.name}</h2>
                                    <p className="text-gray-500 mt-1">${item.price.toFixed(2)}</p>
                                </div>
                                <button className="p-3 bg-white hover:bg-gray-50 rounded-full shadow-sm active:scale-95 transition-transform" onClick={() => toggleShoprjWishlist(item.id)}>
                                    <Heart className={cn("w-6 h-6 outline-none", shoprjWishlist.includes(item.id) ? "fill-red-500 text-red-500" : "text-gray-400")} />
                                </button>
                            </div>
                            
                            <div className="space-y-3">
                                <h3 className="text-sm font-medium text-gray-700">Người nhận</h3>
                                <div className="flex gap-3 overflow-x-auto pb-2 hide-scrollbar">
                                    <div 
                                        className={cn("flex flex-col items-center gap-1 min-w-[70px] cursor-pointer", selectedReceiver === 'user' ? 'opacity-100 ring-2 ring-pink-500 rounded-xl p-1' : 'opacity-50')}
                                        onClick={() => setSelectedReceiver('user')}
                                    >
                                        <img src={userProfile.avatar} className="w-12 h-12 rounded-[12px] object-cover" />
                                        <span className="text-xs truncate w-full text-center mt-1">Bản thân</span>
                                    </div>
                                    {contacts.map(c => (
                                        <div 
                                            key={c.id}
                                            className={cn("flex flex-col items-center gap-1 min-w-[70px] cursor-pointer", selectedReceiver === c.id ? 'opacity-100 ring-2 ring-pink-500 rounded-xl p-1' : 'opacity-50')}
                                            onClick={() => setSelectedReceiver(c.id)}
                                        >
                                            <img src={c.avatar} className="w-12 h-12 rounded-[12px] object-cover" />
                                            <span className="text-xs truncate w-full text-center mt-1">{c.name}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <button 
                                disabled={!selectedReceiver}
                                onClick={() => handleBuyItem(item, selectedReceiver!)}
                                className="w-full py-4 mt-4 bg-gray-900 text-white rounded-[24px] font-medium active:scale-[0.98] transition-transform disabled:opacity-50 disabled:active:scale-100"
                            >
                                Gửi quà
                            </button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 gap-4 pb-12">
                            {/* Add new item button */}
                            <div className="bg-white/50 rounded-[24px] p-2 border-2 border-dashed border-gray-200 cursor-pointer hover:bg-white/80 active:scale-95 transition-all flex flex-col items-center justify-center min-h-[200px]" onClick={() => setShowAddItem(true)}>
                                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm text-gray-400 mb-2">
                                    <Plus size={24} />
                                </div>
                                <span className="text-sm font-medium text-gray-500">Thêm Món Mới</span>
                            </div>
                            
                            {shoprjItems.map(item => (
                                <div key={item.id} className="bg-white rounded-[24px] p-2 shadow-sm border border-gray-100 cursor-pointer active:scale-[0.98] transition-transform" onClick={() => setSelectedItem(item)}>
                                    <div className="w-full aspect-square rounded-[20px] overflow-hidden mb-3 bg-gray-50">
                                        <img src={item.image} className="w-full h-full object-cover" />
                                    </div>
                                    <div className="px-2 pb-2 flex justify-between items-end">
                                        <div className="w-full pr-1">
                                            <h4 className="text-sm font-medium text-gray-900 truncate">{item.name}</h4>
                                            <span className="text-[11px] text-gray-500 font-serif">${item.price.toFixed(2)}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Add Item Modal */}
                <AnimatePresence>
                    {showAddItem && (
                        <motion.div 
                            initial={{ opacity: 0, y: 50 }} 
                            animate={{ opacity: 1, y: 0 }} 
                            exit={{ opacity: 0, y: 50 }}
                            className="absolute inset-0 z-50 bg-white/90 backdrop-blur-md flex flex-col p-6 pt-12"
                        >
                            <div className="flex justify-between items-center mb-8">
                                <h2 className="text-xl font-serif text-gray-900">Món đồ kỳ diệu</h2>
                                <button onClick={() => setShowAddItem(false)} className="p-2 bg-gray-100 rounded-full text-gray-600 active:scale-95">
                                    <X size={18} />
                                </button>
                            </div>
                            
                            <div className="space-y-4 overflow-y-auto hide-scrollbar pb-10">
                                <button 
                                    onClick={handleAIGenerate}
                                    disabled={isGeneratingAI}
                                    className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-pink-100 to-purple-100 text-purple-900 rounded-[16px] font-medium active:scale-95 transition-transform disabled:opacity-50"
                                >
                                    <Sparkles size={18} />
                                    {isGeneratingAI ? 'Đang tạo bằng AI...' : 'Tạo ngẫu nhiên bằng AI'}
                                </button>

                                <div className="text-center text-xs text-gray-400 font-medium uppercase tracking-wider my-2">hoặc tạo thủ công</div>

                                <div>
                                    <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2 block">Tên vật phẩm</label>
                                    <input value={newItemName} onChange={e => setNewItemName(e.target.value)} type="text" className="w-full bg-gray-50 border border-gray-200 rounded-[16px] px-4 py-3 outline-none focus:border-gray-400" placeholder="VD: Lọ ước nguyện..." />
                                </div>
                                
                                <div>
                                    <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2 block">Giá ($)</label>
                                    <input value={newItemPrice} onChange={e => setNewItemPrice(e.target.value)} type="number" className="w-full bg-gray-50 border border-gray-200 rounded-[16px] px-4 py-3 outline-none focus:border-gray-400" placeholder="VD: 99" />
                                </div>

                                <div>
                                    <label className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2 block">Hình ảnh</label>
                                    <div className="flex gap-4 items-center">
                                        <div 
                                            className="w-20 h-20 bg-gray-50 border border-gray-200 rounded-[16px] flex items-center justify-center overflow-hidden cursor-pointer active:scale-95 transition-transform shrink-0 relative"
                                            onClick={() => fileInputRef.current?.click()}
                                        >
                                            {newItemImage ? <img src={newItemImage} className="w-full h-full object-cover" /> : <ImageIcon className="text-gray-400" size={24} />}
                                            <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
                                        </div>
                                        <div className="text-xs text-gray-400 w-[60%]">Nhấn vào ô vuông để tải ảnh lên (hỗ trợ JPG, PNG)</div>
                                    </div>
                                </div>
                                
                                <button 
                                    disabled={!newItemName || !newItemImage || !newItemPrice}
                                    onClick={handleAddItem}
                                    className="w-full py-4 mt-6 bg-gray-900 text-white rounded-[24px] font-medium active:scale-[0.98] transition-transform disabled:opacity-50"
                                >
                                    Khởi tạo
                                </button>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </AppLayout>
        )
    }

    // Days of week
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const today = new Date().getDay();
    const currentDayIdx = today === 0 ? 6 : today - 1;

    // Latest transaction logic
    const latestTx = shoprjTransactions[0];
    const latestItem = latestTx ? shoprjItems.find(i => i.id === latestTx.itemId) : shoprjItems[0];
    const latestTotal = latestItem ? (latestItem.price * 1.23).toFixed(2) : '0.00';
    const latestTax = latestItem ? (latestItem.price * 0.23).toFixed(2) : '0.00';

    return (
        <AppLayout 
            title="Shoprj"
            appId="shoprj"
            bgClass="bg-[#F3F4F6]"
            headerClass="text-gray-900"
            rightButton={
                <button onClick={() => { setSelectedItem(null); setViewMode('buy'); }} className="w-8 h-8 flex justify-center items-center rounded-full bg-white shadow-sm border border-gray-100 active:scale-95 transition-transform">
                    <ShoppingBag size={14} className="text-gray-700" />
                </button>
            }
        >
            <div className="px-5 space-y-5 pb-10 pt-2 font-sans">
                {/* Greeting */}
                <div>
                    <h1 className="text-[17px] tracking-wide text-gray-900 mb-1">Good Evening, {userProfile.name}</h1>
                    <p className="text-gray-500 text-[13px] tracking-wide">How are you feeling today?</p>
                </div>

                {/* Days Tracker */}
                <div className="flex justify-between items-center px-1 mb-2">
                    {days.map((day, i) => (
                        <div key={day} className="flex flex-col items-center">
                            <span className={cn("text-[10px] mb-2.5", i === currentDayIdx ? "text-transparent" : "text-gray-400")}>{day}</span>
                            {i === currentDayIdx ? (
                                <div className="bg-black text-white w-10 py-2.5 flex flex-col items-center shadow-md -mt-7 relative z-10" style={{ borderRadius: '24px' }}>
                                    <span className="text-[10px] mb-2.5">{day}</span>
                                    <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                                </div>
                            ) : (
                                <div className="w-1.5 h-1.5 rounded-full bg-gray-300"></div>
                            )}
                        </div>
                    ))}
                </div>

                {/* Two Cards - Invoice & Profile */}
                <div className="flex gap-[12px] items-stretch">
                     {/* Invoice Card */}
                     <div className="relative w-[130px] shrink-0 flex flex-col items-center">
                        {/* Upper Solid Card */}
                        <div className="bg-white rounded-[20px] rounded-b-[16px] w-full pt-4 pb-3 shadow-[0_2px_12px_rgba(0,0,0,0.03)] z-10 flex flex-col items-center relative overflow-hidden text-center">
                            <div className="w-[46px] h-[46px] rounded-full overflow-hidden shadow-[0_0_0_2px_white,0_2px_10px_rgba(0,0,0,0.08)] mb-2.5 relative cursor-pointer group">
                                {latestItem && (
                                    <>
                                        <img src={latestItem.image} className="w-full h-full object-cover" />
                                        <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleUpdateItemImage(latestItem.id, e)} />
                                    </>
                                )}
                            </div>
                            <h3 className="text-[10px] text-gray-500 mb-1.5 w-full text-center tracking-wide px-2 truncate leading-tight">
                                {latestItem?.name || "Add Cuteness Potion"}
                            </h3>
                            <div className="bg-[#eff1f4] px-2.5 py-[3px] rounded-[6px] text-[9px] text-gray-600 mb-[2px] font-medium tracking-wide">
                                Completed
                            </div>
                            
                            {/* Slit */}
                            <div className="absolute bottom-[4px] left-1/2 -translate-x-1/2 w-[84%] h-[3px] bg-gradient-to-b from-gray-200 to-[#F9FAFB] rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.05)]"></div>
                        </div>

                        {/* Hanging Receipt */}
                        <motion.div 
                            initial={{ rotate: -1.5 }}
                            animate={{ rotate: [-0.5, 1, -0.5] }}
                            transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                            style={{ transformOrigin: 'top center' }}
                            className="bg-white w-[114px] mx-auto shadow-[0_8px_16px_rgba(0,0,0,0.04)] rounded-b-[14px] pt-[14px] pb-2.5 px-[14px] text-[10px] text-gray-400 relative -mt-1.5 z-0"
                        >
                            <div className="flex justify-between mb-1.5">
                                <span>service</span>
                                <span className="text-gray-700">${latestItem ? latestItem.price.toFixed(2) : '0.00'}</span>
                            </div>
                            <div className="flex justify-between mb-1.5">
                                <span>Tax 23%</span>
                                <span className="text-gray-700">${latestTax}</span>
                            </div>
                            <div className="flex justify-between mb-[14px]">
                                <span>Tip</span>
                                <span className="text-gray-700">$0.00</span>
                            </div>

                            {/* Cutout line area */}
                            <div className="w-[102px] -ml-[8px] border-t border-dashed border-gray-300 relative mb-[11px]">
                                <div className="absolute -left-[5px] -top-[5px] w-[10px] h-[10px] rounded-full bg-[#F3F4F6] shadow-[inset_-2px_0_3px_rgba(0,0,0,0.02)]"></div>
                                <div className="absolute -right-[5px] -top-[5px] w-[10px] h-[10px] rounded-full bg-[#F3F4F6] shadow-[inset_2px_0_3px_rgba(0,0,0,0.02)]"></div>
                            </div>

                            <div className="flex justify-between text-[11px] text-gray-800 pb-0.5">
                                <span>Total</span>
                                <span>${latestTotal}</span>
                            </div>
                        </motion.div>
                     </div>

                     {/* Profile Info Card */}
                     <div className="bg-white/90 backdrop-blur-md rounded-[24px] p-4 shadow-[0_2px_12px_rgba(0,0,0,0.03)] border border-gray-50 flex-grow flex flex-col justify-center min-w-0">
                         <div className="flex justify-between w-full items-center mb-4">
                            <div className="w-[60px] h-[60px] rounded-full border-[3px] border-white shadow-[0_2px_10px_rgba(0,0,0,0.08)] overflow-hidden relative cursor-pointer active:scale-95 transition-transform shrink-0">
                                <img src={userProfile.avatar} className="w-full h-full object-cover" />
                                <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer z-10" onChange={handleUpdateProfileAvatar} />
                                <div className="absolute right-0 bottom-0 w-[18px] h-[18px] bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-gray-900 shadow-sm border border-gray-200 pointer-events-none">
                                    <span className="text-[14px] leading-none -mt-[1px] font-medium">+</span>
                                </div>
                            </div>
                            <div className="flex gap-2 pr-0.5 pl-1 shrink-1 justify-around w-full">
                                <div className="text-center flex flex-col items-center">
                                    <div className="font-serif text-[15px] text-gray-800 leading-none mb-1">{shoprjWishlist.length + 50}</div>
                                    <div className="text-[9px] text-gray-500 tracking-wide uppercase">follow</div>
                                </div>
                                <div className="text-center flex flex-col items-center">
                                    <div className="font-serif text-[15px] text-gray-800 leading-none mb-1">{shoprjItems.length + 4}</div>
                                    <div className="text-[9px] text-gray-500 tracking-wide uppercase">post</div>
                                </div>
                                <div className="text-center flex flex-col items-center">
                                    <div className="font-serif text-[15px] text-gray-800 leading-none mb-1">{shoprjTransactions.length + 80}w</div>
                                    <div className="text-[9px] text-gray-500 tracking-wide uppercase">likes</div>
                                </div>
                            </div>
                         </div>
                         <h3 className="text-[13px] tracking-[0.1em] mb-4 w-full text-center text-gray-700 truncate">日記の第一ページ</h3>
                         <button 
                            className="w-full text-gray-400 text-[11px] py-1.5 rounded-[12px] shadow-[0_1px_4px_rgba(0,0,0,0.02)] active:scale-95 transition-transform bg-gradient-to-br from-[#FAFAFB] to-[#F1F2F4] border border-gray-100/80"
                            onClick={() => {
                                const newName = prompt('Tên hồ sơ mới:', userProfile.name);
                                if (newName) updateUserProfile({ name: newName });
                            }}
                         >
                            <span className="tracking-[0.05em]">Edit Profile</span>
                         </button>
                     </div>
                </div>

                {/* 4 small bubbles */}
                <div className="flex justify-center gap-5 mt-2 mb-2">
                    {[1, 2, 3, 4].map(idx => {
                        const item = shoprjItems[idx - 1];
                        return (
                            <div key={idx} className="w-12 h-12 rounded-[16px] overflow-hidden shadow-sm bg-white/50 border border-white relative cursor-pointer active:scale-95 transition-transform">
                                {item ? (
                                    <>
                                        <img src={item.image} className="w-full h-full object-cover" />
                                        <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" onChange={(e) => handleUpdateItemImage(item.id, e)} />
                                    </>
                                ) : (
                                    <div className="w-full h-full bg-gray-100 relative">
                                        <div className="absolute inset-0 flex items-center justify-center opacity-30">
                                           <span className="text-xl">+</span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        )
                    })}
                </div>

                {/* Destiny Tabs Area */}
                <div className="bg-white/90 backdrop-blur-md rounded-[28px] p-5 shadow-sm border border-white/40">
                    <div className="flex justify-between mb-4 items-center px-1">
                        {tabs.map(tab => (
                            <button 
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className="flex flex-col items-center gap-1 relative"
                            >   
                                {tab.count > 0 && <span className="absolute -top-3 -right-3 text-[8px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded-full">{tab.count}</span>}
                                <span className={cn("text-[11px] tracking-wide transition-colors", activeTab === tab.id ? "text-gray-800" : "text-gray-400")}>{tab.label}</span>
                                {activeTab === tab.id && <div className="w-8 h-0.5 bg-[#8b9ba7] rounded-full mt-1"></div>}
                            </button>
                        ))}
                    </div>

                    <div className="flex items-center text-[11px] text-gray-500 mt-5 pt-4 border-t border-gray-50/50">
                        <ShoppingBag size={14} className="mr-3 text-gray-800 shrink-0" />
                        Drifting ends when lovers meet.
                    </div>
                </div>

                {/* List Content */}
                <div className="space-y-3">
                    {/* Wishlist List */}
                    {activeTab === 'wishlist' && (
                        shoprjWishlist.length === 0 ? (
                            <div className="text-center py-6 text-gray-400 text-[12px] italic">Không có món đồ yêu thích.</div>
                        ) : (
                            shoprjWishlist.map(itemId => {
                                const item = shoprjItems.find(i => i.id === itemId);
                                if (!item) return null;
                                return (
                                    <div key={itemId} className="flex gap-4 items-center p-1 cursor-pointer" onClick={() => { setSelectedItem(item); setViewMode('buy'); }}>
                                        <div className="w-12 h-12 rounded-[14px] overflow-hidden flex-shrink-0 bg-white relative">
                                            <img src={item.image} className="w-full h-full object-cover" />
                                            <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" 
                                                   onClick={(e) => e.stopPropagation()} 
                                                   onChange={(e) => { e.stopPropagation(); handleUpdateItemImage(item.id, e); }} />
                                        </div>
                                        <div className="flex flex-col flex-grow">
                                            <div className="flex justify-between items-center mb-0.5">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] bg-gray-100/80 px-2 py-0.5 rounded-full text-gray-600">Wishlist</span>
                                                    <span className="text-[13px] font-medium text-gray-800 tracking-wide">{item.name}</span>
                                                </div>
                                                <span className="text-[10px] text-gray-400">18:18</span>
                                            </div>
                                            <p className="text-[11px] text-gray-500 tracking-wide mt-1">${item.price.toFixed(2)}</p>
                                        </div>
                                    </div>
                                )
                            })
                        )
                    )}

                    {/* Inventory List */}
                    {activeTab === 'inventory' && (
                        inventory.length === 0 ? (
                            <div className="text-center py-6 text-gray-400 text-[12px] italic">Bạn chưa nhận được món đồ nào.</div>
                        ) : (
                            inventory.map(tx => {
                                const item = shoprjItems.find(i => i.id === tx.itemId);
                                const isUserBuyer = tx.buyerId === 'user';
                                const buyer = isUserBuyer ? userProfile.name : contacts.find(c => c.id === tx.buyerId)?.name;
                                
                                return (
                                    <div key={tx.id} className="flex gap-4 p-1">
                                        <div className="w-12 h-12 rounded-[14px] overflow-hidden flex-shrink-0 bg-white relative">
                                            {item && (
                                                <>
                                                    <img src={item.image} className="w-full h-full object-cover" />
                                                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" 
                                                           onChange={(e) => handleUpdateItemImage(item.id, e)} />
                                                </>
                                            )}
                                        </div>
                                        <div className="flex flex-col flex-grow justify-center">
                                            <div className="flex justify-between items-center mb-0.5">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] bg-gray-100/80 px-2 py-0.5 rounded-full text-gray-600">Seraph</span>
                                                    <span className="text-[13px] font-medium text-gray-800 tracking-wide">{item?.name}</span>
                                                </div>
                                                <span className="text-[10px] text-gray-400">{new Date(tx.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                            </div>
                                            <p className="text-[11px] text-gray-500 tracking-wide mt-1">Từ: {buyer}</p>
                                        </div>
                                    </div>
                                )
                            })
                        )
                    )}

                    {/* Destiny List */}
                    {activeTab === 'destiny' && (
                        shoprjTransactions.length === 0 ? (
                            <div className="text-center py-6 text-gray-400 text-[12px] italic">Chưa có giao dịch nào.</div>
                        ) : (
                            shoprjTransactions.map(tx => {
                                const item = shoprjItems.find(i => i.id === tx.itemId);
                                const isUserBuyer = tx.buyerId === 'user';
                                const buyer = isUserBuyer ? userProfile.name : contacts.find(c => c.id === tx.buyerId)?.name;
                                const receiver = tx.receiverId === 'user' ? userProfile.name : contacts.find(c => c.id === tx.receiverId)?.name;

                                return (
                                    <div key={tx.id} className="flex gap-4 p-1">
                                        <div className="w-12 h-12 rounded-[14px] overflow-hidden flex-shrink-0 bg-white relative">
                                            {item && (
                                                <>
                                                    <img src={item.image} className="w-full h-full object-cover" />
                                                    <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer" 
                                                           onChange={(e) => handleUpdateItemImage(item.id, e)} />
                                                </>
                                            )}
                                        </div>
                                        <div className="flex flex-col flex-grow justify-center">
                                            <div className="flex justify-between items-center mb-0.5">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] bg-gray-100/80 px-2 py-0.5 rounded-full text-gray-600">Seraph</span>
                                                    <span className="text-[13px] font-medium text-gray-800 tracking-wide">{buyer}</span>
                                                </div>
                                                <span className="text-[10px] text-gray-400">{new Date(tx.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                            </div>
                                            <p className="text-[11px] text-gray-500 tracking-wide mt-1 line-clamp-1">{tx.note || `Drifting ends when lovers meet.`}</p>
                                        </div>
                                    </div>
                                )
                            })
                        )
                    )}
                </div>
            </div>
        </AppLayout>
    )
}
