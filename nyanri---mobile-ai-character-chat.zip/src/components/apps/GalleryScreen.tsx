import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';

const MOCK_PHOTOS = [
  "https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?auto=format&fit=crop&q=80&w=400",
  "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?auto=format&fit=crop&q=80&w=400",
  "https://images.unsplash.com/photo-1519069399451-b96ab3f898a3?auto=format&fit=crop&q=80&w=400",
  "https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=400",
  "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&q=80&w=400",
  "https://images.unsplash.com/photo-1481819613568-3701cbc70156?auto=format&fit=crop&q=80&w=400",
];

export default function GalleryScreen() {
  const { currentCharacter } = useAppStore();
  if (!currentCharacter) return null;

  return (
    <AppLayout title="Phòng Ảnh" bgClass="bg-[#F8E8EE]" appId="gallery">
      <div className="px-4 py-4 pb-24">
         
         <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6 px-2 -mx-2">
            <button className="px-4 py-1.5 bg-[#1A1A1A] text-white rounded-full text-[10px] uppercase font-bold tracking-widest shrink-0">Tất cả</button>
            <button className="px-4 py-1.5 bg-white/50 text-[#1A1A1A] rounded-full text-[10px] uppercase font-bold tracking-widest shrink-0 border border-white">Kỉ niệm</button>
            <button className="px-4 py-1.5 bg-white/50 text-[#1A1A1A] rounded-full text-[10px] uppercase font-bold tracking-widest shrink-0 border border-white">Thẩm mỹ</button>
            <button className="px-4 py-1.5 bg-white/50 text-[#1A1A1A] rounded-full text-[10px] uppercase font-bold tracking-widest shrink-0 border border-white flex items-center">Bí mật <span className="ml-1 opacity-50">🔒</span></button>
         </div>

         <div className="columns-2 gap-3 space-y-3">
            {MOCK_PHOTOS.map((url, i) => (
                <div key={i} className="break-inside-avoid relative group cursor-pointer">
                   {i % 3 === 0 ? (
                      // Polaroid style
                      <div className="bg-white/80 p-2 pb-8 rounded-lg shadow-md border border-gray-100 transform transition-transform hover:-translate-y-1">
                         <img src={url} className="w-full h-auto rounded-sm object-cover" />
                         <div className="absolute bottom-2 left-0 right-0 text-center font-serif italic text-xs text-gray-500 px-2 opacity-80">
                            {i === 0 ? '"Nhớ hôm đó..."' : 'Kỉ niệm ✦'}
                         </div>
                      </div>
                   ) : (
                      // Standard rounded photo
                      <div className="rounded-2xl overflow-hidden shadow-sm border border-white/50 transform transition-transform hover:-translate-y-1">
                          <img src={url} className="w-full h-auto object-cover" />
                      </div>
                   )}
                </div>
            ))}
         </div>

      </div>
    </AppLayout>
  );
}
