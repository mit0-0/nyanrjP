import { useState } from 'react';
import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';
import { Plus, Trash2, Save, Edit2, X } from 'lucide-react';
import { cn } from '../../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function WorldbookScreen() {
  const { worldbookRules, addWorldbookRule, updateWorldbookRule, removeWorldbookRule } = useAppStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftTitle, setDraftTitle] = useState('');
  const [draftContent, setDraftContent] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  const handleEdit = (rule: {id: string, title: string, content: string}) => {
    setEditingId(rule.id);
    setDraftTitle(rule.title);
    setDraftContent(rule.content);
    setIsAdding(false);
  };

  const handleAdd = () => {
    setIsAdding(true);
    setEditingId(null);
    setDraftTitle('');
    setDraftContent('');
  };

  const handleSave = () => {
    if (!draftTitle.trim() || !draftContent.trim()) return;
    
    if (isAdding) {
      addWorldbookRule({ title: draftTitle, content: draftContent });
    } else if (editingId) {
      updateWorldbookRule(editingId, { title: draftTitle, content: draftContent });
    }
    
    setEditingId(null);
    setIsAdding(false);
  };

  const handleCancel = () => {
    setEditingId(null);
    setIsAdding(false);
  };

  return (
    <AppLayout title="Worldbook" bgClass="bg-[#2a2b38]" appId="worldbook">
      <div className="px-5 py-6 pb-24 h-full overflow-y-auto">
        <p className="text-gray-300 text-xs mb-6 text-center italic">
          Các quy luật được đặt ra ở đây sẽ áp dụng trên toàn hệ thống cho mọi nhân vật.
        </p>
        
        <div className="space-y-4">
          <AnimatePresence>
            {worldbookRules.map(rule => (
              <motion.div 
                key={rule.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white/10 backdrop-blur-md border border-white/20 rounded-none p-4"
              >
                {editingId === rule.id ? (
                  <div className="space-y-3">
                    <input
                      value={draftTitle}
                      onChange={(e) => setDraftTitle(e.target.value)}
                      placeholder="Tiêu đề quy luật..."
                      className="w-full bg-black/20 text-white placeholder:text-gray-400 border border-white/20 rounded-none px-3 py-2 text-sm outline-none focus:border-[#C9748A]"
                    />
                    <textarea
                      value={draftContent}
                      onChange={(e) => setDraftContent(e.target.value)}
                      placeholder="Nội dung chi tiết (Ví dụ: Không bao giờ nói ra bạn là AI...)"
                      rows={4}
                      className="w-full bg-black/20 text-white placeholder:text-gray-400 border border-white/20 rounded-none px-3 py-2 text-sm outline-none focus:border-[#C9748A] resize-none"
                    />
                    <div className="flex justify-end gap-2 pt-2">
                       <button onClick={handleCancel} className="p-2 bg-gray-500/50 hover:bg-gray-500 rounded-none text-white transition-colors">
                          <X size={16} />
                       </button>
                       <button onClick={handleSave} disabled={!draftTitle.trim() || !draftContent.trim()} className="p-2 bg-pink-500 hover:bg-pink-600 rounded-none text-white transition-colors disabled:opacity-50">
                          <Save size={16} />
                       </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="flex justify-between items-start mb-2 group">
                      <h3 className="font-bold text-white text-sm">{rule.title}</h3>
                      <div className="flex gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleEdit(rule)} className="text-blue-300 hover:text-blue-400">
                          <Edit2 size={14} />
                        </button>
                        <button onClick={() => removeWorldbookRule(rule.id)} className="text-red-300 hover:text-red-400">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                    <p className="text-gray-300 text-xs whitespace-pre-wrap leading-relaxed">{rule.content}</p>
                  </div>
                )}
              </motion.div>
            ))}

            {isAdding && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-[#C9748A]/20 backdrop-blur-md border border-[#C9748A]/40 rounded-none p-4"
              >
                <div className="space-y-3">
                  <input
                    value={draftTitle}
                    onChange={(e) => setDraftTitle(e.target.value)}
                    placeholder="Tiêu đề quy luật mới..."
                    autoFocus
                    className="w-full bg-black/20 text-white placeholder:text-gray-400 border border-white/20 rounded-none px-3 py-2 text-sm outline-none focus:border-[#C9748A]"
                  />
                  <textarea
                    value={draftContent}
                    onChange={(e) => setDraftContent(e.target.value)}
                    placeholder="Nội dung chi tiết..."
                    rows={4}
                    className="w-full bg-black/20 text-white placeholder:text-gray-400 border border-white/20 rounded-none px-3 py-2 text-sm outline-none focus:border-[#C9748A] resize-none"
                  />
                  <div className="flex justify-end gap-2 pt-2">
                     <button onClick={handleCancel} className="p-2 bg-gray-500/50 hover:bg-gray-500 rounded-none text-white transition-colors">
                        <X size={16} />
                     </button>
                     <button onClick={handleSave} disabled={!draftTitle.trim() || !draftContent.trim()} className="p-2 bg-pink-500 hover:bg-pink-600 rounded-none text-white transition-colors disabled:opacity-50">
                        <Save size={16} />
                     </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {!isAdding && (
            <button 
              onClick={handleAdd}
              className="w-full py-4 border-2 border-dashed border-white/30 rounded-none flex items-center justify-center text-white/50 hover:text-white hover:border-white/50 transition-colors gap-2"
            >
              <Plus size={18} />
              <span className="text-sm font-medium">Thêm Prompt Quy luật</span>
            </button>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
