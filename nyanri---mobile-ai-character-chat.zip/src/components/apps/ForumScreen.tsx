import { useState, useRef, useEffect } from 'react';
import AppLayout from './AppLayout';
import { Heart, MessageCircle, Share2, MoreHorizontal, PawPrint, X, Search, User, Flame, TrendingUp, Camera, Send, Check, RefreshCw, MapPin, Eye } from 'lucide-react';
import { useAppStore, ForumPost, ForumComment } from '../../store/useAppStore';
import { cn } from '../../lib/utils';
import { generateGeminiResponse } from '../../services/geminiService';


const INITIAL_HOT_SEARCH = [
  { rank: 1, topic: 'Sếp lớn khu N109 lộ diện', heat: '2.5M' },
  { rank: 2, topic: 'Cách nuôi thú ảo Nyan', heat: '1.2M' },
  { rank: 3, topic: 'Nhạc Lofi study 24/7', heat: '890K' },
  { rank: 4, topic: 'Bí ẩn phòng thí nghiệm 404', heat: '650K' },
  { rank: 5, topic: 'Team build game đêm', heat: '430K' }
];

const INITIAL_POSTS: ForumPost[] = [
  {
    id: '1',
    authorId: 'sys-nyan',
    content: 'Hôm nay bầu trời thật đẹp, giống như tâm trạng của mình vậy đó (´,,•ω•,,)♡',
    image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=400',
    likes: 124,
    comments: [],
    isLiked: false,
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString() // 12 mins ago
  },
  {
    id: '2',
    authorId: 'sys-sleepy',
    content: 'Có ai đang nghe list nhạc Lofi này không? Cuốn quá đi mất zzz...',
    likes: 89,
    comments: [],
    isLiked: false,
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString() // 1 hour ago
  },
  {
    id: '3',
    authorId: 'sys-berry',
    content: 'Cần tìm người chơi game cùng lúc 10h tối nay ╰(*´︶`*)╯',
    likes: 245,
    comments: [],
    isLiked: false,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString() // 3 hours ago
  }
];

const MOCK_AUTHORS: Record<string, {name: string, avatar: string}> = {
  'sys-nyan': { name: 'Nyan ♥', avatar: 'https://ui-avatars.com/api/?name=Nyan&background=random&color=fff' },
  'sys-sleepy': { name: 'Sleepy Bear', avatar: 'https://ui-avatars.com/api/?name=Sleepy+Bear&background=random&color=fff' },
  'sys-berry': { name: 'Strawberry Milk', avatar: 'https://ui-avatars.com/api/?name=Strawberry&background=random&color=fff' }
};

export default function ForumScreen() {
  const { themeSettings, forumProfile, updateForumProfile, forumPosts, addForumPost, toggleLikeForumPost, addCommentToForumPost, toggleLikeForumComment } = useAppStore();
  const [activeTab, setActiveTab] = useState<'foryou' | 'following' | 'latest' | 'hot'>('foryou');
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [isGeneratingPost, setIsGeneratingPost] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');

  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [isGeneratingComment, setIsGeneratingComment] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [hotSearch, setHotSearch] = useState(INITIAL_HOT_SEARCH);
  const [isGeneratingHotSearch, setIsGeneratingHotSearch] = useState(false);

  // States for profile editing
  const [editName, setEditName] = useState(forumProfile.name);
  const [editAvatar, setEditAvatar] = useState(forumProfile.avatar);
  const [editBio, setEditBio] = useState(forumProfile.bio || '');

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Populate initial posts if empty
    if (forumPosts.length === 0) {
      useAppStore.setState({ forumPosts: INITIAL_POSTS });
    }
  }, []);

  const handleGenerateHotSearch = async () => {
    setIsGeneratingHotSearch(true);
    try {
      const prompt = `Tạo 5 chủ đề nóng (hot search) giả lập cho mạng xã hội. Trả về đúng định dạng JSON array: [{"rank": 1, "topic": "Tiêu đề", "heat": "1.2M"}, ...]. Không markdown.`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let arr = INITIAL_HOT_SEARCH;
      try {
        arr = JSON.parse(response.replace(/```json/g,'').replace(/```/g,'').trim());
      } catch (e) {}
      setHotSearch(arr);
    } catch (err) {
      console.error(err);
    }
    setIsGeneratingHotSearch(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = () => {
    updateForumProfile({ name: editName, avatar: editAvatar, bio: editBio });
    setShowProfileModal(false);
  };

  const handleAIGeneratePost = async () => {
    setIsGeneratingPost(true);
    try {
      const prompt = `Viết 3 bài đăng (status) siêu ngắn (dưới 30 chữ) trên diễn đàn dành cho giới trẻ. Phong cách GenZ, thoải mái, có emoji. Trả về đúng định dạng JSON array chứa 3 chuỗi. Không markdown. Ví dụ: ["stt 1", "stt 2", "stt 3"]`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let arr = ["Hôm nay buồn ngủ quá Zzz", "Chạy deadline mệt xỉu (╥﹏╥)", "Có ai đi cafe không nè?"];
      try {
        arr = JSON.parse(response.replace(/```json/g,'').replace(/```/g,'').trim());
      } catch (e) { }
      
      const keys = Object.keys(MOCK_AUTHORS);
      arr.forEach((content, i) => {
        const randomAuthor = keys[Math.floor(Math.random() * keys.length)];
        const newPost: ForumPost = {
          id: `post-${Date.now()}-${i}`,
          authorId: randomAuthor,
          content: content,
          timestamp: new Date().toISOString(),
          likes: Math.floor(Math.random() * 50),
          isLiked: false,
          comments: []
        };
        addForumPost(newPost);
      });
      setToastMessage('Đã tạo 3 bài viết mới');
      setTimeout(() => setToastMessage(null), 2000);
    } catch(err) {
      console.error(err);
      setToastMessage('Có lỗi khi tạo bài viết');
      setTimeout(() => setToastMessage(null), 2000);
    }
    setIsGeneratingPost(false);
  };

  const handleManualPost = () => {
    if (!newPostContent.trim()) return;
    const newPost: ForumPost = {
      id: `post-${Date.now()}`,
      authorId: 'me',
      content: newPostContent.trim(),
      timestamp: new Date().toISOString(),
      likes: 0,
      isLiked: false,
      comments: []
    };
    addForumPost(newPost);
    setNewPostContent('');
  };

  const handleShare = () => {
    setToastMessage('Đã chép liên kết cùa bài viết!');
    setTimeout(() => setToastMessage(null), 2000);
  };

  const attemptNpcInteraction = async (postId: string, userCommentText: string) => {
    // Followers influence probability of NPC interactions
    const followers = forumProfile.followers || 1;
    const probability = Math.min(0.2 + (followers / 5000), 0.8);
    
    if (Math.random() > probability) return;

    // Simulate delay for NPC reading and typing
    setTimeout(async () => {
      try {
        const keys = Object.keys(MOCK_AUTHORS);
        const randomAuthor = keys[Math.floor(Math.random() * keys.length)];
        
        const prompt = `Một người dùng tên "${forumProfile.name}" vừa bình luận: "${userCommentText}". Bạn là một người dùng khác trên diễn đàn tên "${MOCK_AUTHORS[randomAuthor].name}". Hãy viết một câu phản hồi ngắn gọn (dưới 20 chữ) để reply lại người dùng này. Bắt đầu bằng "@${forumProfile.name} ".`;
        const response = await generateGeminiResponse(prompt, { temperature: 0.8 });
        
        addCommentToForumPost(postId, {
          id: `comment-npc-${Date.now()}`,
          authorId: randomAuthor,
          content: response,
          timestamp: new Date().toISOString(),
          likes: Math.floor(Math.random() * 10),
          isLiked: false
        });
      } catch (e) {
        console.error(e);
      }
    }, 2000 + Math.random() * 3000);
  };

  const handleSendComment = () => {
    if (!selectedPostId || !commentText.trim()) return;
    addCommentToForumPost(selectedPostId, {
      id: `comment-${Date.now()}`,
      authorId: 'me',
      content: commentText.trim(),
      timestamp: new Date().toISOString(),
      likes: 0,
      isLiked: false
    });
    
    // Trigger possible NPC interactions
    attemptNpcInteraction(selectedPostId, commentText.trim());
    
    setCommentText('');
  };

  const handleAIGenerateComment = async () => {
    if (!selectedPostId) return;
    setIsGeneratingComment(true);
    
    try {
      const postContent = selectedPost?.content || '';
      const prompt = `Có bài đăng sau trên diễn đàn ẩn danh (như Reddit/VOZ/Threads): "${postContent}".
YÊU CẦU:
1. Tạo 3-5 bình luận phản hồi từ người lạ. Mỗi người 1 bình luận (không comment liên tiếp 1 người).
2. Mỗi bình luận mang 1 cá tính khác biệt (ví dụ: khịa, đồng tình, chia sẻ thêm kinh nghiệm, tò mò).
3. Bình luận KHÔNG được quá ngắn, dài tầm 2-4 câu, phải tự nhiên giống một cộng đồng thật. Liên quan chặt chẽ đến bài viết! Khác biệt hoàn toàn nhau.
TRẢ VỀ ĐÚNG ĐỊNH DẠNG JSON (KHÔNG MARKDOWN): { "comments": ["ý kiến 1", "ý kiến 2", "ý kiến 3", "ý kiến 4"] }`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let arr = ["Bài này hay đấy!", "Quan điểm của mình hơi khác chút...", "Thực sự thì cũng hợp lý", "Haha chủ thớt vui tính thế"];
      try {
        const parsed = JSON.parse(response.replace(/```json/g,'').replace(/```/g,'').trim());
        if (parsed.comments && Array.isArray(parsed.comments)) {
          arr = parsed.comments;
        }
      } catch (e) { }
      
      const keys = Object.keys(MOCK_AUTHORS);
      arr.forEach((content, i) => {
        const randomAuthor = keys[Math.floor(Math.random() * keys.length)];
        const delay = i * 1500;
        setTimeout(() => {
           addCommentToForumPost(selectedPostId, {
             id: `comment-ai-${Date.now()}-${i}`,
             authorId: randomAuthor,
             content: content,
             timestamp: new Date().toISOString(),
             likes: Math.floor(Math.random() * 20)
           });
        }, delay);
      });
      setTimeout(() => setIsGeneratingComment(false), arr.length * 1500 + 500);
      setToastMessage(`Đã tạo ${arr.length} bình luận mới`);
      setTimeout(() => setToastMessage(null), 2000);
    } catch (err) {
      console.error(err);
      setIsGeneratingComment(false);
      setToastMessage('Có lỗi xảy ra');
      setTimeout(() => setToastMessage(null), 2000);
    }
  };

  const getAuthorInfo = (authorId: string) => {
    if (authorId === 'me') {
      return { name: forumProfile.name, avatar: forumProfile.avatar };
    }
    return MOCK_AUTHORS[authorId] || { name: 'Unknown', avatar: 'https://ui-avatars.com/api/?name=Unk&background=random&color=fff' };
  };

  const formatTime = (ts: string) => {
    const d = new Date(ts);
    const diff = Date.now() - d.getTime();
    if (diff < 60000) return 'Vừa xong';
    if (diff < 3600000) return `${Math.floor(diff/60000)} phút trước`;
    if (diff < 86400000) return `${Math.floor(diff/3600000)} giờ trước`;
    return d.toLocaleDateString('vi-VN');
  };

  const filteredPosts = activeTab === 'hot' ? forumPosts.sort((a,b) => b.likes - a.likes) : forumPosts;
  const selectedPost = selectedPostId ? forumPosts.find(p => p.id === selectedPostId) : null;

  return (
    <AppLayout title="Forum" bgClass="bg-transparent" headerClass="text-[#5A4A4B]" overlayClass="bg-transparent" bgImageClassName="opacity-100" appId="forum">
      <div className="relative z-10 flex flex-col h-full overflow-hidden">
         {/* Categories / Tabs / Header */}
         <div className="flex px-5 py-4 gap-6 overflow-x-auto [&::-webkit-scrollbar]:hidden shrink-0 border-b border-pink-200 items-center bg-white/20 backdrop-blur-sm shadow-sm">
             {/* Profile Button Inside Header To Be Always Visible */}
             <button 
               onClick={() => setShowProfileModal(true)} 
               className="w-10 h-10 rounded-none overflow-hidden border-2 border-pink-200 shadow-sm shrink-0 active:scale-95 transition-transform bg-pink-50/60"
             >
                <img src={forumProfile.avatar} className="w-full h-full object-cover" />
             </button>
             <div className="w-[1px] h-5 bg-pink-200/50 shrink-0 mx-1"></div>
             
             <button 
               onClick={() => setActiveTab('foryou')} 
               className={cn("text-[15px] whitespace-nowrap transition-all", activeTab === 'foryou' ? "font-bold font-serif text-[#5A4A4B] border-b-[3px] border-pink-400 pb-1" : "font-medium text-gray-400 hover:text-gray-600")}
             >Dành cho bạn</button>
             <button 
               onClick={() => setActiveTab('following')} 
               className={cn("text-[15px] whitespace-nowrap transition-all", activeTab === 'following' ? "font-bold font-serif text-[#5A4A4B] border-b-[3px] border-pink-400 pb-1" : "font-medium text-gray-400 hover:text-gray-600")}
             >Đang theo dõi</button>
             <button 
               onClick={() => setActiveTab('latest')} 
               className={cn("text-[15px] whitespace-nowrap transition-all", activeTab === 'latest' ? "font-bold font-serif text-[#5A4A4B] border-b-[3px] border-pink-400 pb-1" : "font-medium text-gray-400 hover:text-gray-600")}
             >Mới nhất</button>
             <button 
               onClick={() => setActiveTab('hot')} 
               className={cn("flex items-center gap-1.5 text-[15px] whitespace-nowrap transition-all", activeTab === 'hot' ? "font-bold font-serif text-pink-600 border-b-[3px] border-pink-400 pb-1" : "font-medium text-pink-400/70 hover:text-pink-500")}
             ><Flame size={16} /> Hot Search</button>
         </div>

         {/* Feed / Content */}
         <div className="flex-grow overflow-y-auto bg-transparent pb-24 [&::-webkit-scrollbar]:hidden">
            {activeTab === 'hot' ? (
              <div className="bg-white/20 backdrop-blur-md p-5 m-4 border-2 border-double border-pink-200 rounded-none shadow-sm">
                  <div className="flex items-center justify-between mb-6">
                     <h3 className="font-bold font-serif text-[#5A4A4B] flex items-center gap-2 text-lg">
                       <TrendingUp className="text-pink-500" size={22} />
                       Xu hướng tìm kiếm
                     </h3>
                     <button 
                        onClick={handleGenerateHotSearch} 
                        disabled={isGeneratingHotSearch}
                        className="text-gray-400 hover:text-pink-500 disabled:opacity-50 transition-colors"
                     >
                        <RefreshCw size={20} className={cn(isGeneratingHotSearch && "animate-spin")} />
                     </button>
                  </div>
                  <div className="space-y-2">
                    {hotSearch.map((item, idx) => (
                     <div 
                       key={idx} 
                       onClick={async () => {
                          setToastMessage('Đang tải bài viết về chủ đề này...');
                          setActiveTab('latest');
                          try {
                            const prompt = `Viết một bài đăng ngắn gọn (dưới 20 chữ) trên diễn đàn nói về chủ đề HOT: "${item.topic}". Thể hiện sự ngỡ ngàng hoặc thích thú. Không dùng ngoặc kép.`;
                            const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
                            // Simulate character author
                            const keys = Object.keys(MOCK_AUTHORS);
                            const randomAuthor = keys[Math.floor(Math.random() * keys.length)];
                            addForumPost({
                              id: `post-hot-${Date.now()}`,
                              authorId: randomAuthor,
                              content: response,
                              timestamp: new Date().toISOString(),
                              likes: Math.floor(Math.random() * 500) + 100,
                              isLiked: false,
                              comments: []
                            });
                          } catch(e) {
                            console.error(e);
                          } finally {
                            setToastMessage(null);
                          }
                       }}
                       className="flex items-center gap-4 border-b border-pink-200 pb-4 mb-2 last:border-0 last:pb-0 last:mb-0 cursor-pointer hover:bg-[#F2C4CE]/5 p-3 transition-colors active:scale-95"
                     >
                       <span className={cn("text-[20px] font-bold font-serif w-6 text-center shrink-0 italic", item.rank <= 3 ? (item.rank === 1 ? 'text-pink-500' : 'text-pink-400') : 'text-gray-300')}>{item.rank}</span>
                       <div className="flex-grow overflow-hidden">
                         <div className="font-bold font-serif text-[#5A4A4B] text-[15px] truncate">{item.topic}</div>
                         <div className="text-[11px] text-gray-500 mt-0.5">{item.heat} lượt tương tác</div>
                       </div>
                       <button className="text-gray-400 hover:text-pink-500 shrink-0 transition-colors"><Share2 size={18}/></button>
                     </div>
                   ))}
                 </div>
              </div>
            ) : (
              <>
                {/* Create Post Input & AI Button */}
                <div className="p-5 border-2 border-double border-pink-200 flex flex-col gap-4 bg-white/20 backdrop-blur-md rounded-none mx-4 mt-4 shadow-sm">
                   <div className="flex items-start gap-4">
                     <div className="w-10 h-10 overflow-hidden bg-pink-50/60 shrink-0 relative mt-1 border-2 border-double border-pink-100 rounded-none">
                        <img src={forumProfile.avatar} className="w-full h-full object-cover" />
                     </div>
                     <textarea 
                       value={newPostContent}
                       onChange={e => setNewPostContent(e.target.value)}
                       onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleManualPost()}
                       placeholder="Hôm nay bạn thấy thế nào?"
                       className="flex-grow bg-transparent outline-none py-2 text-[15px] font-sans text-[#5A4A4B] resize-none h-14 w-full placeholder-gray-400"
                     />
                   </div>
                   
                   <div className="pl-14 space-y-3">
                     <div className="flex flex-col gap-2">
                        <button className="flex items-center justify-between py-2 border-b border-pink-200 text-gray-500 hover:text-pink-500 transition-colors group">
                           <div className="flex items-center gap-2">
                              <MapPin size={16} />
                              <span className="text-[14px]">Thêm địa điểm</span>
                           </div>
                           <span className="text-[12px] opacity-0 group-hover:opacity-100 transition-opacity">›</span>
                        </button>
                        <button className="flex items-center justify-between py-2 border-b border-pink-200 text-gray-500 hover:text-pink-500 transition-colors group">
                           <div className="flex items-center gap-2">
                              <Eye size={16} />
                              <span className="text-[14px]">Ai có thể xem?</span>
                           </div>
                           <span className="text-[13px] font-medium text-gray-400 group-hover:text-pink-400">Công khai ▾</span>
                        </button>
                     </div>
                     
                     <div className="flex justify-between items-center pt-2">
                       <button onClick={handleAIGeneratePost} disabled={isGeneratingPost} className="flex items-center justify-center w-8 h-8 text-pink-500 bg-pink-50/60 rounded-full hover:bg-pink-100 transition-colors disabled:opacity-50" title="AI Viết bài"><PawPrint size={16} /></button>
                       <button
                         onClick={handleManualPost}
                         disabled={!newPostContent.trim()}
                         className="px-6 py-2 flex items-center justify-center bg-pink-500 text-white rounded-none text-[13px] font-bold font-serif disabled:bg-gray-200 disabled:text-gray-400 transition-colors tracking-wide"
                       >
                         Post
                       </button>
                     </div>
                   </div>
                </div>

                {/* Posts List */}
                {filteredPosts.map(post => {
                  const author = getAuthorInfo(post.authorId);
                  return (
                    <div key={post.id} className="pt-4 pb-6 border-2 border-double border-pink-200 bg-white/20 backdrop-blur-md mb-4 mx-4 rounded-none shadow-sm hover:bg-white/40 transition-colors">
                       <div className="flex items-center gap-3 px-4 mb-3">
                          <div className="relative w-10 h-10 bg-pink-50/60 border-2 border-double border-pink-100 rounded-none overflow-hidden flex items-center justify-center text-pink-700 font-bold font-serif text-xs">
                             <img src={author.avatar} alt="avatar" className="w-full h-full absolute inset-0 object-cover" />
                             {!author.avatar && <span className="relative z-10 font-bold font-serif tracking-wider">{author.name.substring(0,2).toUpperCase()}</span>}
                          </div>
                          <div className="flex-grow flex flex-col justify-center">
                            <div className="font-bold font-serif text-[#5A4A4B] text-[14px] leading-tight">{author.name}</div>
                            <div className="text-gray-400 text-[10px] tracking-wide mt-0.5">{formatTime(post.timestamp)}</div>
                          </div>
                          <button className="text-gray-300 hover:text-gray-500 transition-colors"><MoreHorizontal size={20} /></button>
                       </div>

                       {post.image && (
                         <div className="w-full max-h-[600px] xl:max-h-[700px] overflow-hidden mb-4 bg-gray-100/50">
                            <img src={post.image} className="w-full h-full object-cover" />
                         </div>
                       )}

                       <p className="text-[#5A4A4B] text-[15px] leading-relaxed px-4 mb-4">{post.content}</p>
                       
                       <div className="flex items-center gap-6 text-gray-500 px-4">
                          <button 
                            onClick={() => toggleLikeForumPost(post.id)}
                            className={cn("flex items-center gap-1.5 transition-colors", post.isLiked ? 'text-pink-500' : 'hover:text-pink-500')}
                          >
                             <Heart size={22} strokeWidth={post.isLiked ? 2.5 : 1.5} className={post.isLiked ? 'fill-pink-500 text-pink-500' : ''} />
                             <span className="text-[13px] font-medium">{post.likes}</span>
                          </button>
                          <button 
                            onClick={() => setSelectedPostId(post.id)}
                            className="flex items-center gap-1.5 hover:text-pink-500 transition-colors"
                          >
                             <MessageCircle size={22} strokeWidth={1.5} />
                             <span className="text-[13px] font-medium">{post.comments.length}</span>
                          </button>
                          <button onClick={handleShare} className="flex items-center gap-1.5 bg-white/50 p-2 rounded-none hover:text-pink-500 hover:bg-white transition-colors">
                             <Send size={22} strokeWidth={1.5} />
                          </button>
                       </div>
                       
                       {/* Comments Preview if any */}
                       {post.comments.length > 0 && (
                          <div className="mt-4 bg-transparent px-4 space-y-3">
                             {post.comments.slice(0, 2).map((c, idx) => {
                               const cAuthor = getAuthorInfo(c.authorId);
                               return (
                                 <div key={idx} className="flex gap-2.5">
                                     <div className="w-7 h-7 bg-white/80 rounded-none shrink-0 relative overflow-hidden flex items-center justify-center text-pink-700 text-[8px] font-bold font-serif mt-0.5 border-2 border-double border-pink-100">
                                        <img src={cAuthor.avatar} className="w-full h-full absolute inset-0 object-cover" />
                                        {!cAuthor.avatar && <span className="relative z-10">{cAuthor.name.substring(0,2).toUpperCase()}</span>}
                                     </div>
                                     <div className="text-[14px] leading-snug pt-0.5">
                                        <span className="font-bold font-serif text-[#5A4A4B] mr-2">{cAuthor.name}</span>
                                        <span className="text-gray-700">{c.content}</span>
                                        <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest">{formatTime(c.timestamp)}</div>
                                     </div>
                                 </div>
                               )
                             })}
                             {post.comments.length > 2 && (
                                <button className="text-[13px] font-medium text-gray-500 hover:text-pink-500 mt-2 transition-colors" onClick={() => setSelectedPostId(post.id)}>
                                   Xem tất cả {post.comments.length} bình luận
                                </button>
                             )}
                          </div>
                       )}
                    </div>
                  );
                })}
              </>
            )}
         </div>
      </div>

      {/* Profile Edit Modal */}
      {showProfileModal && (
         <div className="absolute inset-0 bg-white/50 z-50 flex items-center justify-center p-4 backdrop-blur-md animate-in fade-in" onClick={() => setShowProfileModal(false)}>
            <div className="bg-white/80 w-full max-w-sm flex flex-col relative overflow-hidden animate-in zoom-in-95 border-2 border-double border-pink-200 shadow-2xl" onClick={e => e.stopPropagation()}>
               <div className="relative z-10 flex items-center justify-between p-5 border-b border-pink-200">
                  <h3 className="font-bold font-serif text-[#5A4A4B]">Profile</h3>
                  <button onClick={() => setShowProfileModal(false)} className="p-2 -mr-2 text-gray-400 hover:text-[#5A4A4B] hover:bg-gray-100/60 transition-colors"><X size={20} /></button>
               </div>
               
               <div className="p-6 space-y-6">
                 <div className="flex flex-col items-center justify-center">
                    <div className="relative w-24 h-24 group bg-[#F2C4CE] p-1 overflow-hidden">
                       <div 
                          className="w-full h-full bg-white/80 border-2 border-double border-pink-300 overflow-hidden relative cursor-pointer shadow-sm mix-blend-luminosity grayscale opacity-90"
                          onClick={() => fileInputRef.current?.click()}
                       >
                          <img src={editAvatar} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-[#F2C4CE]/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
                             <Camera className="text-white" size={24} />
                          </div>
                       </div>
                    </div>
                    <input type="file" accept="image/*" ref={fileInputRef} className="hidden" onChange={handleImageUpload} />
                    <span className="text-xs font-bold font-serif text-gray-400 mt-2 uppercase tracking-widest">Avatar</span>
                 </div>

                 <div className="space-y-4">
                    <div>
                      <label className="text-xs font-bold font-serif text-gray-500 mb-1.5 block tracking-wide uppercase">Display Name</label>
                      <input 
                         type="text" 
                         value={editName}
                         onChange={(e) => setEditName(e.target.value)}
                         className="w-full bg-white/40 border-2 border-double border-pink-300 px-4 py-3 outline-none focus:border-black transition-colors text-sm font-medium text-[#5A4A4B]"
                      />
                    </div>
                    
                    <div>
                      <label className="text-xs font-bold font-serif text-gray-500 mb-1.5 block tracking-wide uppercase">Bio</label>
                      <textarea 
                         value={editBio}
                         onChange={(e) => setEditBio(e.target.value)}
                         placeholder="Vài dòng về bạn..."
                         className="w-full bg-white/40 border-2 border-double border-pink-300 px-4 py-3 outline-none focus:border-black transition-colors text-sm font-medium text-[#5A4A4B] resize-none h-20"
                      />
                    </div>
                 </div>
               </div>

               <div className="p-5 border-t border-pink-200 bg-white/50 flex justify-end">
                  <button onClick={handleSaveProfile} className="bg-[#F2C4CE] hover:bg-gray-800 active:scale-95 text-white font-bold font-serif px-6 py-2.5 text-sm shadow-md transition-all">
                     Save changes
                  </button>
               </div>
            </div>
         </div>
      )}

      {/* Post Detail & Comment Modal */}
      {selectedPost && (
         <div className="absolute inset-0 bg-white/40 z-50 flex flex-col justify-end backdrop-blur-md animate-in fade-in" onClick={() => setSelectedPostId(null)}>
            <div className="bg-white/80 w-full h-[90%] shadow-2xl rounded-none-3xl flex flex-col relative overflow-hidden animate-in slide-in-from-bottom border-t border-pink-200" onClick={e => e.stopPropagation()}>
               <div className="relative z-10 flex justify-center py-4 border-b border-pink-200 bg-white/80">
                  <div className="w-12 h-1 bg-gray-200"></div>
                  <button onClick={() => setSelectedPostId(null)} className="absolute right-4 top-3 p-2 text-gray-400 hover:text-gray-600 bg-white/40 hover:bg-pink-50/60 transition-colors"><X size={18} /></button>
               </div>
               
               <div className="flex-grow overflow-y-auto px-5 py-6 space-y-6 bg-white/80">
                 {/* Original Post Recap */}
                 <div className="pb-6 border-b border-pink-50">
                    <div className="flex items-center gap-3 mb-4">
                       <div className="relative w-10 h-10 bg-pink-50/60 border-2 border-double border-pink-100 rounded-none overflow-hidden flex items-center justify-center text-pink-700 font-bold font-serif text-xs">
                          <img src={getAuthorInfo(selectedPost.authorId).avatar} className="w-full h-full absolute inset-0 object-cover" />
                          {!getAuthorInfo(selectedPost.authorId).avatar && <span className="relative z-10 font-bold font-serif">{getAuthorInfo(selectedPost.authorId).name.substring(0,2).toUpperCase()}</span>}
                       </div>
                       <div>
                         <div className="font-bold font-serif text-[#5A4A4B] text-[15px]">{getAuthorInfo(selectedPost.authorId).name}</div>
                         <div className="text-gray-400 text-[11px] uppercase tracking-widest">{formatTime(selectedPost.timestamp)}</div>
                       </div>
                    </div>
                    {selectedPost.image && (
                         <div className="w-full overflow-hidden mb-4 bg-white/40">
                            <img src={selectedPost.image} className="w-full h-full object-cover" />
                         </div>
                    )}
                    <p className="text-gray-800 text-[16px] leading-relaxed">{selectedPost.content}</p>
                 </div>

                 {/* Comments List */}
                 <div className="space-y-5">
                    <h4 className="font-bold font-serif text-[#5A4A4B] text-[15px]">Comments ({selectedPost.comments.length})</h4>
                    {selectedPost.comments.length === 0 ? (
                       <p className="text-gray-400 text-[14px] text-center py-10">Chưa có bình luận nào. Hãy là người đầu tiên!</p>
                    ) : (
                       selectedPost.comments.map(c => (
                         <div key={c.id} className="flex gap-3">
                           <div className="relative w-8 h-8 bg-pink-50/60 border-2 border-double border-pink-100 rounded-none overflow-hidden flex shrink-0 items-center justify-center text-pink-700 font-bold font-serif text-[10px]">
                              <img src={getAuthorInfo(c.authorId).avatar} className="w-full h-full absolute inset-0 object-cover" />
                              {!getAuthorInfo(c.authorId).avatar && <span className="relative z-10">{getAuthorInfo(c.authorId).name.substring(0,2).toUpperCase()}</span>}
                           </div>
                           <div className="flex-grow pb-4 border-b border-pink-50 last:border-0 last:pb-0">
                              <div className="flex justify-between items-start mb-1">
                                 <span className="font-bold font-serif text-[#5A4A4B] text-[14px]">{getAuthorInfo(c.authorId).name}</span>
                                 <span className="text-gray-400 text-[10px] uppercase tracking-wider mt-0.5">{formatTime(c.timestamp)}</span>
                              </div>
                              <p className="text-gray-800 text-[14px] mb-2">{c.content}</p>
                              <div className="flex items-center gap-1.5 justify-end">
                                 <button 
                                   onClick={() => toggleLikeForumComment(selectedPost.id, c.id)}
                                   className="flex items-center gap-1.5 text-[12px] font-medium text-gray-400 hover:text-pink-500 active:scale-95 transition-all"
                                 >
                                    <Heart size={14} className={c.isLiked ? 'fill-pink-500 text-pink-500' : ''} />
                                    <span className={c.isLiked ? 'text-pink-500' : ''}>{c.likes || 0}</span>
                                 </button>
                              </div>
                           </div>
                         </div>
                       ))
                    )}
                 </div>
               </div>

               {/* Comment Input */}
               <div className="p-4 border-t border-pink-100/50 bg-white/80">
                  <div className="flex justify-between mb-3 px-1">
                     <button onClick={handleAIGenerateComment} disabled={isGeneratingComment} className="flex items-center justify-center w-8 h-8 text-pink-500 bg-pink-50/60 rounded-full hover:bg-pink-100 transition-colors disabled:opacity-50" title="AI Phản hồi"><PawPrint size={16} /></button>
                  </div>
                  <div className="flex items-center gap-3">
                     <div className="w-10 h-10 border-2 border-double border-pink-200 bg-white/40 rounded-none overflow-hidden flex items-center justify-center shrink-0">
                        <img src={forumProfile.avatar} className="w-full h-full object-cover" />
                     </div>
                     <div className="flex-grow flex items-center bg-white/40 px-5 py-2 border-2 border-double border-pink-300 rounded-none focus-within:border-pink-300 transition-colors">
                        <input 
                           type="text" 
                           value={commentText}
                           onChange={e => setCommentText(e.target.value)}
                           onKeyDown={e => e.key === 'Enter' && handleSendComment()}
                           placeholder="Thêm bình luận..."
                           className="flex-grow bg-transparent outline-none py-1 text-[15px] font-sans text-[#5A4A4B]"
                        />
                        <button 
                           onClick={handleSendComment}
                           disabled={!commentText.trim()}
                           className="w-8 h-8 flex items-center justify-center bg-pink-500 text-white rounded-none disabled:bg-gray-300 disabled:opacity-50 transition-colors ml-2 shrink-0 hover:bg-pink-600"
                        >
                           <Send size={14} />
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
         <div className="absolute top-16 left-1/2 -translate-x-1/2 z-[100] bg-[#F2C4CE] text-white text-sm font-medium px-4 py-2 shadow-lg flex items-center gap-2 animate-in fade-in slide-in-from-top-4">
            <Check size={16} className="text-white" />
            {toastMessage}
         </div>
      )}
    </AppLayout>
  );
}

