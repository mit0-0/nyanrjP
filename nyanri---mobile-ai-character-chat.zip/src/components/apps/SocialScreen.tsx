import { useState } from 'react';
import AppLayout from './AppLayout';
import { LogOut, MapPin, Share, FileText, Book, Clock, Heart, Building, Mail, ShoppingBag, Search, PawPrint, Send, X, Plus, ChevronLeft, Camera } from 'lucide-react';
import { useAppStore, SocialPost } from '../../store/useAppStore';
import { formatDistanceToNow } from 'date-fns';
import { vi } from 'date-fns/locale';
import { cn } from '../../lib/utils';
import { generateGeminiResponse } from '../../services/geminiService';

export default function SocialScreen() {
  const { currentCharacter, userProfile, contacts, messagesByContact, socialPosts, addSocialPost, toggleLikePost, addCommentToPost, themeSettings, popScreen, updateUserProfile, updateThemeSettings, worldbookRules } = useAppStore();
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isWriting, setIsWriting] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'feed' | 'inbox' | 'wallet' | 'direct'>('profile');
  
  const [inboxItems, setInboxItems] = useState([
    { icon: '【', title: '【Cập nhật Treo thưởng】Khu N...', sender: 'Hội Thợ săn, Hôm qua', desc: 'Cập nhật thưởng hạng A: Mục tiêu “Dạ Hống”...' },
    { icon: 'R', title: 'Re: Tra cứu hồ sơ “Kế hoạch...”', sender: 'Cục Lưu trữ, 3 ngày trước', desc: 'Chào bạn, yêu cầu tra cứu của bạn...' },
    { icon: '(', title: '(Không tiêu đề)', sender: '[Bản nháp]', desc: 'Đã tìm được thông tin về sếp lớn khu N109 chưa? Tên là...' },
    { icon: 'Ê', title: 'Ê! Còn sống không?', sender: 'Người gửi: Lâm Tiêu, 2 giờ trước', desc: 'Đại tiểu thư, lại mất tích à? Lần trước tớ đề cử...' },
  ]);

  const [walletItems, setWalletItems] = useState([
    { icon: 'Nhận', title: 'Từ Cục Thuế', desc: 'Hoàn thuế · 28 Th11 16:15', amount: '+ 800', isPos: true },
    { icon: 'Gửi', title: 'Chuyển cho Tiệm giặt ủi', desc: 'Sửa đồ · 28 Th11 16:10', amount: '- 800', isPos: false },
    { icon: 'Gửi', title: 'Chuyển cho Cố Hành Chỉ', desc: 'Phí cầu đường · 28 Th11 16:07', amount: '- 60', isPos: false },
    { icon: 'Gửi', title: 'Chuyển cho Cục Thuế', desc: 'Phạt tài chính · 27 Th11 17:42', amount: '- 1,884', isPos: false },
    { icon: 'Nhận', title: 'Từ Sotheby', desc: 'Đấu giá · 27 Th11 17:41', amount: '+ 4,000', isPos: true },
  ]);

  const [directItems, setDirectItems] = useState([
    { icon: '秦', title: 'Tần Triệt', desc: 'Tần Triệt: Mở cửa...', time: 'Hôm nay 00:51' },
    { icon: '测', title: 'Người thử nghiệm', desc: 'Người thử nghiệm: Vậy... có nhiệm vụ khẩn cấp ban đêm cần tôi...', time: 'Hôm qua 23:40' },
    { icon: '顾', title: 'Cố Hành Chỉ', desc: 'Cố Hành Chỉ: Nhịp điệu bài hát này làm người ta muốn chìm xuống...', time: '09 Th12 16:15' },
    { icon: '[', title: '[Nhóm] Căn cứ bí mật', desc: 'System: (Dịch: Miệng thì bảo không, nhưng tim thì...)', time: '03 Th12 22:37' },
  ]);
  
  const [editName, setEditName] = useState(userProfile.name);
  const [editAvatar, setEditAvatar] = useState(userProfile.socialAvatar || userProfile.avatar);
  const [editStatus, setEditStatus] = useState(userProfile.status);
  const [editBalance, setEditBalance] = useState(userProfile.socialStats?.balance || '0');
  const [editMsgs, setEditMsgs] = useState(userProfile.socialStats?.msgs || '0');
  const [editTime, setEditTime] = useState(userProfile.socialStats?.time || '0');
  const [editFrame, setEditFrame] = useState(userProfile.avatarFrame || '');
  
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostImage, setNewPostImage] = useState('');
  const [isGeneratingPost, setIsGeneratingPost] = useState(false);
  
  const [activeCommentPost, setActiveCommentPost] = useState<string | null>(null);
  const [newCommentContent, setNewCommentContent] = useState('');
  const [isGeneratingComment, setIsGeneratingComment] = useState(false);

  const [isGeneratingInbox, setIsGeneratingInbox] = useState(false);
  const [isGeneratingWallet, setIsGeneratingWallet] = useState(false);
  const [isGeneratingDirect, setIsGeneratingDirect] = useState(false);

  const [selectedDetail, setSelectedDetail] = useState<{ type: 'inbox' | 'wallet' | 'direct', index: number } | null>(null);
  const [isGeneratingDetail, setIsGeneratingDetail] = useState(false);

  const handleItemClick = async (type: 'inbox' | 'wallet' | 'direct', index: number) => {
    const list = type === 'inbox' ? inboxItems : type === 'wallet' ? walletItems : directItems;
    const item = list[index] as any;
    
    setSelectedDetail({ type, index });

    if (!item.fullContent) {
      setIsGeneratingDetail(true);
      try {
         let prompt = "";
         if (type === 'inbox') {
            prompt = `Bạn là hệ thống viết thư/email trong một thế giới giả tưởng đô thị đen tối. Viết chi tiết toàn văn (khoảng 100-200 chữ) cho email/tin nhắn này:
Tiêu đề: ${item.title}
Người gửi: ${item.sender}
Đoạn trích: ${item.desc}
Chỉ trả về nội dung chi tiết (không cần định dạng JSON). Văn phong hợp với bối cảnh (ngôn từ chuyên nghiệp, có thể có chút bí ẩn, giật gân, công nghệ, hoặc hài hước tùy theo thông tin).`;
         } else if (type === 'wallet') {
            prompt = `Viết một thông báo giao dịch chuyển tiền/nhận tiền chi tiết trong thế giới giả tưởng đô thị ngầm.
Giao dịch: ${item.title}
Số tiền: ${item.amount}
Mô tả ngắn: ${item.desc}
Tạo ra một đoạn mô tả chi tiết khoảng 50-100 chữ lý giải vì sao có giao dịch này, có thể kèm theo một lời ghi chú nhỏ từ hệ thống ngân hàng hoặc tin nhắn bí mật đính kèm. Trả về văn bản.`;
         } else {
            prompt = `Tạo một đoạn hội thoại chi tiết / nội dung tin nhắn giữa tôi và ${item.title} dựa vào đoạn trích: ${item.desc}. Đoạn hội thoại gồm 3-5 câu thoại qua lại ngắn gọn, mang phong cách roleplay bí ẩn/lãng mạn/hành động. Trả về dạng đối thoại rõ ràng.`;
         }

         const response = await generateGeminiResponse(prompt, { temperature: 0.8 });
         if (type === 'inbox') {
             const newItems = [...inboxItems];
             (newItems[index] as any).fullContent = response;
             setInboxItems(newItems);
         } else if (type === 'wallet') {
             const newItems = [...walletItems];
             (newItems[index] as any).fullContent = response;
             setWalletItems(newItems);
         } else {
             const newItems = [...directItems];
             (newItems[index] as any).fullContent = response;
             setDirectItems(newItems);
         }
      } catch(e) {
         console.error(e);
      } finally {
         setIsGeneratingDetail(false);
      }
    }
  };

  const activeDetailItem = selectedDetail ? 
    (selectedDetail.type === 'inbox' ? inboxItems[selectedDetail.index] : 
     selectedDetail.type === 'wallet' ? walletItems[selectedDetail.index] : 
     directItems[selectedDetail.index]) as any : null;

  const handleGenerateInbox = async () => {
    setIsGeneratingInbox(true);
    try {
      const prompt = `Tạo một thông báo email/hộp thư ngắn (dưới 15 chữ) cho một ứng dụng giả lập gồm 4 thành phần (trả về đúng định dạng JSON, không có ký tự khác): {"icon": "Một ký tự đầu tiên", "title": "Tiêu đề", "sender": "Người gửi", "desc": "Mô tả ngắn"}. Ngôn ngữ: Tiếng Việt.`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data = { icon: '🤖', title: 'Thông báo', sender: 'Hệ thống', desc: 'Có lỗi xảy ra' };
      try {
        data = JSON.parse(response.replace(/```json/gi, '').replace(/```/gi, '').trim());
      } catch(e) {}
      setInboxItems([data, ...inboxItems]);
    } catch(err) {
      console.error(err);
    }
    setIsGeneratingInbox(false);
  };

  const handleGenerateWallet = async () => {
    setIsGeneratingWallet(true);
    try {
      const prompt = `Tạo một giao dịch ví giả lập gồm 5 thành phần (trả về JSON): {"icon": "Nhận hoặc Gửi", "title": "Tên đối tác", "desc": "Mô tả · Hôm nay", "amount": "+ hoặc - số tiền", "isPos": true hoặc false}. Ngôn ngữ: Tiếng Việt.`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data = { icon: '💸', title: 'Chi tiêu', desc: 'Mua sắm', amount: '-100', isPos: false };
      try {
        data = JSON.parse(response.replace(/```json/gi, '').replace(/```/gi, '').trim());
      } catch(e) {}
      setWalletItems([data, ...walletItems]);
    } catch(err) {
      console.error(err);
    }
    setIsGeneratingWallet(false);
  };

  const handleGenerateDirect = async () => {
    setIsGeneratingDirect(true);
    try {
      const char = contacts.length > 0 ? contacts[Math.floor(Math.random() * contacts.length)] : null;
      const prompt = `Tạo một thông báo tin nhắn trực tiếp giả lập gồm (trả về JSON): {"icon": "Chữ cái đầu", "title": "${char ? char.name : 'Vô danh'}", "desc": "Nội dung ngắn gọn", "time": "Vừa xong"}. Tiếng Việt.`;
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data = { icon: '👋', title: 'Vô danh', desc: 'Chào bạn', time: 'Vừa xong' };
      try {
        data = JSON.parse(response.replace(/```json/gi, '').replace(/```/gi, '').trim());
      } catch(e) {}
      setDirectItems([data, ...directItems]);
    } catch(err) {
      console.error(err);
    }
    setIsGeneratingDirect(false);
  };

  const stats = userProfile.socialStats || { balance: '860,260', msgs: '1831', time: '420' };

  const handlePost = () => {
    if (!newPostContent.trim() && !newPostImage) return;
    addSocialPost({
      id: "sp-" + Date.now().toString() + Math.random().toString(36).substr(2, 5),
      authorId: 'user',
      content: newPostContent,
      image: newPostImage,
      timestamp: new Date().toISOString(),
      likes: 0,
      isLiked: false,
      comments: []
    });
    setNewPostContent('');
    setNewPostImage('');
    setIsWriting(false);
    setActiveTab('feed');
  };

  const handlePostImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewPostImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGeneratePost = async () => {
    if (contacts.length === 0) return alert('Hãy tạo ít nhất một nhân vật (contact) để AI có thể đăng bài thay họ!');
    setIsGeneratingPost(true);
    try {
      const char = currentCharacter || contacts[Math.floor(Math.random() * contacts.length)];
      const prompt = `Bạn đóng vai nhân vật ${char.name}. Viết MỘT (1) dòng trạng thái ngắn (status) để đăng lên mạng xã hội. Thể hiện rõ tính cách của nhân vật. Sử dụng tiếng Việt tự nhiên. KHÔNG dùng ngoặc kép.`;
      
      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      
      addSocialPost({
        id: "spb-" + Date.now().toString() + Math.random().toString(36).substr(2, 5),
        authorId: char.id,
        content: response,
        timestamp: new Date().toISOString(),
        likes: Math.floor(Math.random() * 50),
        isLiked: false,
        comments: []
      });
    } catch(err) {
      console.error(err);
    }
    setIsGeneratingPost(false);
  };


  const handleSendComment = (postId: string) => {
    if (!newCommentContent.trim()) return;
    addCommentToPost(postId, {
      id: "spc-" + Date.now().toString() + Math.random().toString(36).substr(2, 5),
      authorId: 'user',
      content: newCommentContent,
      timestamp: new Date().toISOString()
    });
    setNewCommentContent('');
  };

  const handleGenerateComment = async (postId: string) => {
    const post = socialPosts.find(p => p.id === postId);
    if (!post) return;
    
    // Valid contacts for commenting
    const validContacts = contacts.filter(c => c.id !== 'user');
    if (validContacts.length === 0) return alert('Hãy tạo ít nhất một nhân vật (contact) để sử dụng tính năng này!');
    
    setIsGeneratingComment(true);
    
    try {
      // Pick randomly 3-5 unique contacts
      let shuffled = [...validContacts].sort(() => 0.5 - Math.random());
      const selectedContacts = shuffled.slice(0, Math.floor(Math.random() * 3) + 3);
      
      const rulesStr = worldbookRules.length > 0 ? '\nLuật/Worldbook chung:\n' + worldbookRules.map(r => r.title + ': ' + r.content).join('\n') : '';

      const contactsData = selectedContacts.map(c => {
         const msgs = messagesByContact[c.id] || [];
         const recentHistory = msgs.slice(-3).map(m => (m.role === 'user' ? 'Tôi' : c.name) + ': ' + m.content).join(' | ');
         return '- ID: ' + c.id + '\nTên: ' + c.name + '\nTính cách: ' + c.personalityParams + '\nLịch sử chat gần đây: ' + (recentHistory || 'Chưa trò chuyện');
      }).join('\n\n');
      
      const authorText = post.authorId === 'user' ? 'Tôi' : (contacts.find(c => c.id === post.authorId)?.name || 'Một người');
      
      const prompt = `Bài đăng của "${authorText}": "${post.content}"${rulesStr}\n\nCác nhân vật bạn bè (bình luận viên):\n${contactsData}\n\nYÊU CẦU QUAN TRỌNG:\n1. Đóng vai các nhân vật trên, mỗi người viết 1 bình luận cho bài đăng. (Tổng cộng ${selectedContacts.length} bình luận).\n2. BẮT BUỘC từng người bình luận phải ĐÚNG TÍNH CÁCH, THIẾT LẬP VÀ LỊCH SỬ. Bình luận DÀI KHOẢNG 2-4 CÂU, tự nhiên giống người dùng mạng xã hội trò chuyện. Không comment cụt lủn.\n3. Không comment liên tiếp từ 1 nhân vật.\nTRẢ VỀ JSON DUY NHẤT (không bọc markdown): { "comments": [{ "contactId": "id", "content": "..." }] }`;

      const response = await generateGeminiResponse(prompt, { temperature: 0.9 });
      let data = { comments: [] };
      try {
         data = JSON.parse(response.replace(/```json/gi, '').replace(/```/gi, '').trim());
      } catch (e) {}

      if (data.comments && Array.isArray(data.comments)) {
        data.comments.forEach((c: any, index: number) => {
           setTimeout(() => {
              addCommentToPost(postId, {
                id: Date.now().toString() + Math.random(),
                authorId: c.contactId,
                content: c.content,
                timestamp: new Date().toISOString()
              });
           }, index * 1800);
        });
      }
    } catch(err) {
      console.error(err);
    } finally {
      setTimeout(() => setIsGeneratingComment(false), 2000);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFrameUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditFrame(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const getAuthorInfo = (authorId: string) => {
    if (authorId === 'user') return userProfile;
    return contacts.find(c => c.id === authorId) || userProfile; // fallback
  };

  return (
    <div 
      className="w-full h-full bg-white/80 text-[#111] font-sans flex flex-col relative overflow-hidden animate-in fade-in zoom-in-95 duration-300"
      style={themeSettings.appBackgrounds['social'] ? { backgroundImage: `url(${themeSettings.appBackgrounds['social']})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}
    >
       <div className={cn("absolute inset-0 bg-white/40 backdrop-blur-[1px] z-0 pointer-events-none", !themeSettings.appBackgrounds['social'] && "hidden")}></div>
       {/* Top Bar */}
       <div className="flex items-center justify-between px-6 py-5 bg-white/50 backdrop-blur-md shrink-0 shadow-sm border-b border-gray-50/50 z-20">
          <button onClick={() => popScreen()} className="text-[10px] font-bold tracking-widest text-gray-400 uppercase outline-none">ĐÓNG</button>
          <span className="text-[14px] font-black tracking-[0.2em] text-[#111] uppercase">Nj</span>
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400"></div>
       </div>

       <div className="flex-grow overflow-y-auto pb-10 relative z-10">
          {/* Profile Section */}
          <div className="px-6 pt-10 pb-6">
            <div className="flex items-center justify-between">
              <div className="relative w-[110px] h-[110px] shrink-0">
                 <div className="w-full h-full rounded-full border border-gray-100 p-1 shadow-sm relative">
                    <img src={userProfile.socialAvatar || userProfile.avatar} className="w-full h-full object-cover rounded-full relative z-10" />
                    {userProfile.avatarFrame && (
                       <img src={userProfile.avatarFrame} className="absolute inset-[-10%] w-[120%] h-[120%] object-contain pointer-events-none scale-105 z-20" />
                    )}
                 </div>
              </div>
              <div className="flex justify-around flex-grow pl-6 gap-2">
                 <div className="flex flex-col items-center">
                   <span className="text-[20px] font-bold text-[#111] tracking-tight">{stats.balance}</span>
                   <span className="text-[9px] font-bold text-gray-400 tracking-widest mt-1">THEO DÕI</span>
                 </div>
                 <div className="flex flex-col items-center">
                   <span className="text-[20px] font-bold text-[#111] tracking-tight">{stats.msgs}</span>
                   <span className="text-[9px] font-bold text-gray-400 tracking-widest mt-1">TIN NHẮN</span>
                 </div>
                 <div className="flex flex-col items-center">
                   <span className="text-[20px] font-bold text-[#111] tracking-tight">{stats.time}</span>
                   <span className="text-[9px] font-bold text-gray-400 tracking-widest mt-1">THỜI GIAN</span>
                 </div>
              </div>
            </div>

            <div className="mt-8 space-y-1.5">
               <h1 className="text-xl font-bold text-[#111] tracking-tight">{userProfile.name}</h1>
               <p className="text-[13px] text-gray-500">Mô tả: {userProfile.status}</p>
               <p className="text-[13px] text-gray-400 flex items-center gap-1.5 mt-1">
                 <MapPin size={12} className="text-red-500 fill-red-50" /> 
                 <span>Thế giới số</span>
               </p>
            </div>

            <div className="flex items-center gap-3 mt-8">
               <button onClick={() => setIsEditingProfile(true)} className="flex-1 bg-[#111] hover:bg-black text-white py-3.5 rounded-xl text-[13px] font-bold active:scale-95 transition-transform flex items-center justify-center gap-2">
                 Chỉnh sửa hồ sơ
               </button>
               <button className="flex-1 bg-[#F5F5F5] hover:bg-gray-200 text-[#111] py-3.5 rounded-xl text-[13px] font-bold active:scale-95 transition-transform flex items-center justify-center gap-2">
                 Chia sẻ
               </button>
            </div>
          </div>

          {/* Horizontal Actions Widget */}
          <div className="px-4 py-8 flex overflow-x-auto gap-4 [-ms-overflow-style:'none'] [scrollbar-width:'none'] [&::-webkit-scrollbar]:hidden">
            {[
              { id: 'memo', label: 'Bài viết', icon: FileText, onClick: () => setIsWriting(true) },
              { id: 'diary', label: 'Bảng tin', icon: Book, onClick: () => setActiveTab('feed') },
              { id: 'time', label: 'Kỷ niệm', icon: Clock },
              { id: 'likes', label: 'Đã thích', icon: Heart },
              { id: 'hotel', label: 'Hoạt động', icon: Building, onClick: () => setActiveTab('wallet') },
            ].map((item, i) => (
              <div key={i} onClick={item.onClick} className="flex flex-col items-center gap-3 shrink-0 cursor-pointer group active:scale-95 transition-transform">
                 <div className="w-[72px] h-[72px] rounded-full border border-gray-200 bg-white/80 group-hover:bg-gray-50/60 flex items-center justify-center text-gray-800 shadow-sm transition-colors">
                   <item.icon size={22} strokeWidth={1.5} />
                 </div>
                 <span className="text-[11px] font-bold text-[#111] tracking-wide uppercase">{item.label}</span>
              </div>
            ))}
          </div>

          {/* Bottom Grid */}
          <div className="grid grid-cols-3 border-t border-b border-gray-100 min-h-[160px] bg-[#FAFAFA]">
             <div onClick={() => setActiveTab('inbox')} className="flex flex-col items-center justify-center gap-4 border-r border-gray-100 p-4 cursor-pointer hover:bg-gray-50/60 transition-colors">
                <Mail size={20} className="text-gray-400" strokeWidth={1.5} />
                <span className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">Thư</span>
             </div>
             <div onClick={() => setActiveTab('wallet')} className="flex flex-col items-center justify-center gap-4 border-r border-gray-100 p-4 cursor-pointer hover:bg-gray-50/60 transition-colors">
                <ShoppingBag size={20} className="text-gray-400" strokeWidth={1.5} />
                <span className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">Ví</span>
             </div>
             <div onClick={() => setActiveTab('direct')} className="flex flex-col items-center justify-center gap-4 p-4 cursor-pointer hover:bg-gray-50/60 transition-colors">
                <Search size={20} className="text-gray-400" strokeWidth={1.5} />
                <span className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">Tin nhắn</span>
             </div>
             <div className="col-span-3 text-center py-6">
                <p className="text-[9px] text-gray-200 font-bold uppercase tracking-widest">rednote ID: 495597809</p>
             </div>
          </div>
       </div>

       {/* Feed Modal */}
       {activeTab === 'feed' && (
          <div className="absolute inset-0 bg-black/60 z-50 flex flex-col items-center justify-end sm:justify-center p-0 sm:p-4 backdrop-blur-sm animate-in fade-in" onClick={() => setActiveTab('profile')}>
             <div className="bg-[#f0f0f0] w-full sm:max-w-md h-[95%] sm:h-[85%] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col relative overflow-hidden animate-in slide-in-from-bottom-5" onClick={e => e.stopPropagation()} style={themeSettings.appBackgrounds['social'] ? { backgroundImage: `url(${themeSettings.appBackgrounds['social']})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
                <div className={cn("absolute inset-0 bg-white/40 backdrop-blur-[1px] z-0 pointer-events-none", !themeSettings.appBackgrounds['social'] && "hidden")}></div>
                <div className="relative z-10 flex items-center justify-between p-4 border-b border-gray-200 bg-white/50 backdrop-blur-md shrink-0">
                   <button onClick={handleGeneratePost} disabled={isGeneratingPost} className="text-pink-500 font-bold text-xs flex items-center gap-1 active:scale-95 transition-transform disabled:opacity-50">
                      <PawPrint size={20} />
                   </button>
                   <h2 className="font-bold text-gray-800 text-sm tracking-wide uppercase">Bảng tin</h2>
                   <button onClick={() => setActiveTab('profile')} className="w-8 h-8 flex items-center justify-center text-gray-500 bg-gray-100/50 backdrop-blur-sm rounded-full hover:bg-gray-200 active:scale-95 transition-all">
                      <X size={16} />
                   </button>
                </div>
                
                <div className="flex-grow overflow-y-auto p-4 space-y-4 relative z-10">
                  {socialPosts.map(post => {
                    const author = getAuthorInfo(post.authorId);
                    return (
                      <div key={post.id} className="bg-white/50 backdrop-blur-md rounded-2xl shadow-sm border border-white/50 p-5">
                         <div className="flex items-center gap-3 border-b border-gray-100 pb-4 mb-4">
                            <div className="w-10 h-10 rounded-full bg-black shrink-0 relative overflow-hidden">
                               <img src={author.avatar} className="w-full h-full object-cover" />
                            </div>
                            <span className="font-bold text-[#111] text-sm">Đã đăng một khoảnh khắc</span>
                         </div>
                         <h3 className="font-bold text-[#111] text-lg mb-4 whitespace-pre-wrap">{post.content}</h3>
                         {post.image && (
                            <div className="mb-4 rounded-xl overflow-hidden border border-gray-100">
                               <img src={post.image} className="w-full h-auto object-cover max-h-[400px]" />
                            </div>
                         )}
                         
                         <div className="bg-[#f8f9fa] rounded-xl p-4">
                            <div className="flex items-center gap-2 text-pink-500 mb-3 text-xs font-bold border-b border-gray-100 pb-3">
                               <Heart size={14} className="fill-current" />
                               {post.likes > 0 ? `${post.likes} Người` : '0 Người'}
                            </div>
                            
                            <div className="space-y-4 text-sm mt-3">
                              {post.comments.length === 0 && <p className="text-gray-400 italic text-xs">Chưa có bình luận.</p>}
                              {post.comments.map(cmt => (
                                <div key={cmt.id} className="flex flex-col">
                                   <span className="font-bold text-[#627299] text-xs mb-0.5">{getAuthorInfo(cmt.authorId).name}:</span>
                                   <span className="text-[#111] text-[13px]">{cmt.content}</span>
                                </div>
                              ))}
                            </div>
                            
                            {/* Comment Input */}
                            <div className="mt-4 pt-3 flex items-center gap-2 border-t border-gray-200">
                               <input 
                                 type="text" 
                                 value={activeCommentPost === post.id ? newCommentContent : ''}
                                 onChange={e => {
                                   setActiveCommentPost(post.id);
                                   setNewCommentContent(e.target.value);
                                 }}
                                 onKeyDown={e => {
                                   if(e.key === 'Enter') handleSendComment(post.id);
                                 }}
                                 placeholder="Thêm tin nhắn..."
                                 className="flex-grow bg-transparent text-xs outline-none placeholder-gray-400 text-gray-800"
                               />
                               {newCommentContent.trim() && activeCommentPost === post.id ? (
                                 <button onClick={() => handleSendComment(post.id)} className="text-pink-500 font-bold text-xs">Gửi</button>
                               ) : (
                                 <button onClick={() => handleGenerateComment(post.id)} disabled={isGeneratingComment} className={cn("text-pink-400 hover:text-pink-600 transition-colors flex items-center gap-1", isGeneratingComment && "opacity-50")} title="AI phản hồi">
                                    <PawPrint size={16} />
                                 </button>
                               )}
                            </div>
                         </div>
                         
                         <div className="flex items-center gap-5 mt-4 text-gray-800">
                            <button onClick={() => toggleLikePost(post.id)} className="active:scale-90 transition-transform">
                               <Heart size={20} className={cn(post.isLiked && "fill-pink-500 text-pink-500")} />
                            </button>
                            <button className="active:scale-90 transition-transform">
                               <Share size={20} />
                            </button>
                         </div>
                      </div>
                    )
                  })}
                  {socialPosts.length === 0 && (
                    <div className="text-center py-10 text-gray-400 text-sm italic">
                       Bảng tin trống. Viết gì đó nhé!
                    </div>
                  )}
                </div>
             </div>
          </div>
       )}

       {/* Wallet Modal */}
       {activeTab === 'wallet' && (
          <div className="absolute inset-0 bg-white/80 z-50 flex flex-col items-center justify-start animate-in slide-in-from-right-full" style={themeSettings.appBackgrounds['social'] ? { backgroundImage: `url(${themeSettings.appBackgrounds['social']})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
             <div className={cn("absolute inset-0 bg-white/40 backdrop-blur-[1px] z-0 pointer-events-none", !themeSettings.appBackgrounds['social'] && "hidden")}></div>
             <div className="w-full flex items-center justify-between p-6 bg-white/50 backdrop-blur-md shrink-0 relative z-10 border-b border-gray-100/50">
                <button onClick={() => setActiveTab('profile')} className="text-gray-400 active:scale-95 transition-all w-8 h-8 flex justify-center items-center rounded-full hover:bg-gray-100/50">
                   <ChevronLeft size={24} />
                </button>
                <div className="flex items-center gap-2">
                   <button onClick={handleGenerateWallet} disabled={isGeneratingWallet} className="text-pink-500 hover:bg-pink-50/60 p-1.5 rounded-full transition-colors disabled:opacity-50">
                      <PawPrint size={16} />
                   </button>
                   <h2 className="font-bold text-[#111] text-xs tracking-widest uppercase">Ví Của Bạn</h2>
                </div>
                <div className="w-6"></div>
             </div>
             
             <div className="flex-grow overflow-y-auto w-full px-6 space-y-6 pt-6 relative z-10">
                {walletItems.map((txn, i) => (
                  <div key={i} onClick={() => handleItemClick('wallet', i)} className="flex justify-between items-center pb-6 border-b border-black/5 last:border-0 cursor-pointer active:scale-95 transition-transform hover:bg-white/50 p-2 -mx-2 rounded-xl">
                     <div className="flex items-center gap-4">
                        <div className="w-[42px] h-[42px] rounded-full bg-gray-100/60 flex items-center justify-center text-sm font-bold text-[#111]">
                           {txn.icon}
                        </div>
                        <div className="flex flex-col">
                           <span className="font-bold text-[#111] text-[15px]">{txn.title}</span>
                           <span className="text-[12px] text-gray-400 mt-0.5">{txn.desc}</span>
                        </div>
                     </div>
                     <div className="flex flex-col items-end">
                        <span className="font-bold text-[#111] text-[15px]">{txn.amount}</span>
                        <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest mt-1">Xem</span>
                     </div>
                  </div>
                ))}
             </div>
          </div>
       )}

       {/* Inbox Modal */}
       {activeTab === 'inbox' && (
          <div className="absolute inset-0 bg-white/80 z-50 flex flex-col items-center justify-start animate-in slide-in-from-right-full" style={themeSettings.appBackgrounds['social'] ? { backgroundImage: `url(${themeSettings.appBackgrounds['social']})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
             <div className={cn("absolute inset-0 bg-white/40 backdrop-blur-[1px] z-0 pointer-events-none", !themeSettings.appBackgrounds['social'] && "hidden")}></div>
             <div className="w-full flex items-center justify-between p-6 bg-white/50 backdrop-blur-md shrink-0 relative z-10 border-b border-gray-100/50">
                <button onClick={() => setActiveTab('profile')} className="text-gray-400 active:scale-95 transition-all w-8 h-8 flex justify-center items-center rounded-full hover:bg-gray-100/50">
                   <ChevronLeft size={24} />
                </button>
                <div className="flex items-center gap-2">
                   <button onClick={handleGenerateInbox} disabled={isGeneratingInbox} className="text-pink-500 hover:bg-pink-50/60 p-1.5 rounded-full transition-colors disabled:opacity-50">
                      <PawPrint size={16} />
                   </button>
                   <h2 className="font-bold text-[#111] text-xs tracking-widest uppercase">Hộp thư</h2>
                </div>
                <button className="w-[28px] h-[28px] rounded-full bg-gray-100/50 backdrop-blur-sm flex items-center justify-center text-white"><Heart size={14} className="fill-white" /></button>
             </div>
             
             <div className="flex-grow overflow-y-auto w-full px-6 space-y-6 pt-6 relative z-10">
                {inboxItems.map((mail, i) => (
                  <div key={i} onClick={() => handleItemClick('inbox', i)} className="flex justify-between items-center pb-6 border-b border-black/5 last:border-0 cursor-pointer active:scale-95 transition-transform hover:bg-white/50 p-2 -mx-2 rounded-xl">
                     <div className="flex items-center gap-4 flex-grow overflow-hidden relative">
                        <div className="w-[42px] h-[42px] shrink-0 rounded-full bg-gray-100/60 flex items-center justify-center text-sm font-bold text-[#111]">
                           {mail.icon}
                        </div>
                        <div className="flex flex-col min-w-0 pr-4 w-full">
                           <div className="flex justify-between items-center w-full">
                              <span className="font-bold text-[#111] text-[15px] truncate max-w-[65%]">{mail.title}</span>
                              <span className="text-[12px] font-bold text-[#111] whitespace-nowrap">{mail.sender}</span>
                           </div>
                           <span className="text-[12px] text-gray-400 mt-1 truncate w-[80%]">{mail.desc}</span>
                        </div>
                     </div>
                  </div>
                ))}
             </div>
          </div>
       )}

       {/* Direct Modal */}
       {activeTab === 'direct' && (
          <div className="absolute inset-0 bg-white/80 z-50 flex flex-col items-center justify-start animate-in slide-in-from-right-full" style={themeSettings.appBackgrounds['social'] ? { backgroundImage: `url(${themeSettings.appBackgrounds['social']})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
             <div className={cn("absolute inset-0 bg-white/40 backdrop-blur-[1px] z-0 pointer-events-none", !themeSettings.appBackgrounds['social'] && "hidden")}></div>
             <div className="w-full flex items-center justify-between p-6 bg-white/50 backdrop-blur-md shrink-0 relative z-10 border-b border-gray-100/50">
                <button onClick={() => setActiveTab('profile')} className="text-gray-400 active:scale-95 transition-all w-8 h-8 flex justify-center items-center rounded-full hover:bg-gray-100/50">
                   <ChevronLeft size={24} />
                </button>
                <div className="flex items-center gap-2">
                   <button onClick={handleGenerateDirect} disabled={isGeneratingDirect} className="text-pink-500 hover:bg-pink-50/60 p-1.5 rounded-full transition-colors disabled:opacity-50">
                      <PawPrint size={16} />
                   </button>
                   <h2 className="font-bold text-[#111] text-xs tracking-widest uppercase">Nhắn tin trực tiếp</h2>
                </div>
                <div className="w-6"></div>
             </div>
             
             <div className="flex-grow overflow-y-auto w-full px-6 space-y-6 pt-6 relative z-10">
                {directItems.map((msg, i) => (
                  <div key={i} onClick={() => handleItemClick('direct', i)} className="flex justify-between items-center pb-6 border-b border-black/5 last:border-0 cursor-pointer active:scale-95 transition-transform hover:bg-white/50 p-2 -mx-2 rounded-xl">
                     <div className="flex items-center gap-4 max-w-[70%]">
                        <div className="w-[42px] h-[42px] shrink-0 rounded-full bg-gray-100/60 flex items-center justify-center text-sm font-bold text-[#111]">
                           {msg.icon}
                        </div>
                        <div className="flex flex-col truncate">
                           <span className="font-bold text-[#111] text-[15px]">{msg.title}</span>
                           <span className="text-[12px] text-gray-400 mt-0.5 truncate">{msg.desc}</span>
                        </div>
                     </div>
                     <div className="flex flex-col items-end">
                        <span className="font-bold text-[#111] text-[12px]">{msg.time}</span>
                        <span className="text-[10px] text-gray-300 font-bold uppercase tracking-widest mt-1">Xem</span>
                     </div>
                  </div>
                ))}
             </div>
          </div>
       )}

       {/* Write Post Modal */}
       {isWriting && (
          <div className="absolute inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center sm:p-4 backdrop-blur-sm animate-in fade-in" onClick={() => setIsWriting(false)}>
             <div className="bg-white/80 w-full sm:max-w-md h-[90%] sm:h-auto sm:max-h-[80%] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col relative overflow-hidden animate-in slide-in-from-bottom" onClick={e => e.stopPropagation()}>
                <div className="relative z-10 flex items-center justify-between p-4 border-b border-gray-100">
                   <button onClick={() => setIsWriting(false)} className="px-2 text-gray-500 font-medium">Hủy</button>
                   <h2 className="font-bold text-gray-800 text-sm tracking-wide uppercase">Viết bài</h2>
                   <button 
                      onClick={handlePost}
                      className={cn("px-4 py-1.5 rounded-full text-white font-bold text-[13px] transition-colors", newPostContent.trim() ? "bg-[#111] hover:bg-black" : "bg-gray-200 cursor-not-allowed")}
                   >
                      Đăng
                   </button>
                </div>

                <div className="p-5 flex-grow flex flex-col items-start overflow-y-auto">
                   <textarea 
                      autoFocus
                      value={newPostContent}
                      onChange={e => setNewPostContent(e.target.value)}
                      placeholder="Chia sẻ khoảnh khắc của bạn..."
                      className="w-full flex-grow bg-transparent outline-none resize-none text-[16px] leading-relaxed text-gray-800 placeholder-gray-400 min-h-[100px]"
                   ></textarea>
                   {newPostImage && (
                     <div className="relative w-full mt-4 rounded-xl overflow-hidden border border-gray-100">
                        <img src={newPostImage} className="w-full h-auto object-cover max-h-[300px]" />
                        <button onClick={() => setNewPostImage('')} className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors">
                           <X size={16} />
                        </button>
                     </div>
                   )}
                   <label className="mt-4 flex items-center justify-center p-3 rounded-xl border border-gray-200 bg-gray-50/60 text-gray-500 cursor-pointer hover:bg-gray-100/60 w-full active:scale-[0.98] transition-transform">
                      <Camera size={18} className="mr-2" />
                      <span className="text-sm font-medium">Thêm ảnh</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handlePostImageUpload} />
                   </label>
                </div>
             </div>
          </div>
       )}

       {/* Edit Profile Modal */}
       {isEditingProfile && (
          <div className="absolute inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in" onClick={() => setIsEditingProfile(false)}>
             <div className="bg-white/80 w-full max-w-sm rounded-3xl shadow-2xl flex flex-col relative overflow-hidden animate-in zoom-in-95" onClick={e => e.stopPropagation()}>
                <div className="relative z-10 flex items-center justify-between p-4 border-b border-gray-100">
                   <button onClick={() => setIsEditingProfile(false)} className="p-2 text-gray-500 hover:text-gray-800 transition-colors">
                      <X size={20} />
                   </button>
                   <h2 className="font-bold text-gray-800 text-sm tracking-wide uppercase">Thông tin</h2>
                   <button 
                      onClick={() => {
                       updateUserProfile({ 
                           name: editName, 
                           socialAvatar: editAvatar, 
                           status: editStatus,
                           avatarFrame: editFrame,
                           socialStats: { balance: editBalance, msgs: editMsgs, time: editTime }
                        });
                        setIsEditingProfile(false);
                      }}
                      className="px-4 py-1.5 rounded-full font-bold text-[13px] transition-colors bg-[#111] text-white hover:bg-black"
                   >
                      Lưu
                   </button>
                </div>

                <div className="p-6 flex-col space-y-4 overflow-y-auto max-h-[60vh]">
                   <div>
                     <label className="text-[11px] font-bold text-gray-500 mb-1.5 block tracking-wide uppercase">Tên hiển thị</label>
                     <input 
                        type="text" 
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-gray-400 text-sm font-medium text-gray-800"
                     />
                   </div>
                   <div>
                     <label className="text-[11px] font-bold text-gray-500 mb-1.5 block tracking-wide uppercase">Trạng thái (Summary)</label>
                     <input 
                        type="text" 
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value)}
                        className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-gray-400 text-sm font-medium text-gray-800"
                     />
                   </div>
                   <div className="grid grid-cols-2 gap-4">
                     <div>
                       <label className="text-[11px] font-bold text-gray-500 mb-1.5 block tracking-wide uppercase">Followers</label>
                       <input 
                          type="text" 
                          value={editBalance}
                          onChange={(e) => setEditBalance(e.target.value)}
                          className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-gray-400 text-sm font-medium text-gray-800 font-mono"
                       />
                     </div>
                     <div>
                       <label className="text-[11px] font-bold text-gray-500 mb-1.5 block tracking-wide uppercase">Time</label>
                       <input 
                          type="text" 
                          value={editTime}
                          onChange={(e) => setEditTime(e.target.value)}
                          className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-gray-400 text-sm font-medium text-gray-800 font-mono"
                       />
                     </div>
                   </div>
                   <div>
                     <label className="text-[11px] font-bold text-gray-500 mb-1.5 block tracking-wide uppercase">Ảnh đại diện (Tùy chọn tải lên)</label>
                     <div className="flex gap-2">
                        <input 
                           type="text" 
                           value={editAvatar}
                           onChange={(e) => setEditAvatar(e.target.value)}
                           className="flex-grow bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-gray-400 text-sm font-medium text-gray-800"
                           placeholder="URL avatar..."
                        />
                        <label className="bg-gray-100/60 shrink-0 border border-gray-200 rounded-xl px-4 py-3 cursor-pointer hover:bg-gray-200 transition-colors flex items-center justify-center">
                           <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                           <span className="text-sm font-medium text-gray-600">Tải lên</span>
                        </label>
                     </div>
                     {editAvatar.startsWith('data:image') && (
                        <div className="mt-3 relative w-16 h-16 rounded-full overflow-hidden border border-gray-200 shadow-sm">
                           <img src={editAvatar} className="w-full h-full object-cover" />
                        </div>
                     )}
                   </div>
                   <div>
                     <label className="text-[11px] font-bold text-gray-500 mb-1.5 block tracking-wide uppercase">Khung ảnh đại diện (Tùy chọn)</label>
                     <div className="flex gap-2">
                        <input 
                           type="text" 
                           value={editFrame}
                           onChange={(e) => setEditFrame(e.target.value)}
                           className="flex-grow bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-3 outline-none focus:border-gray-400 text-sm font-medium text-gray-800"
                           placeholder="URL khung ảnh..."
                        />
                        <label className="bg-gray-100/60 shrink-0 border border-gray-200 rounded-xl px-4 py-3 cursor-pointer hover:bg-gray-200 transition-colors flex items-center justify-center">
                           <input type="file" accept="image/*" className="hidden" onChange={handleFrameUpload} />
                           <span className="text-sm font-medium text-gray-600">Tải lên</span>
                        </label>
                     </div>
                     {editFrame && (
                         <div className="mt-3 relative w-16 h-16 rounded-full overflow-hidden border border-gray-200 shadow-sm relative">
                            <img src={editAvatar} className="w-full h-full object-cover rounded-full" />
                            <img src={editFrame} className="absolute inset-[-10%] w-[120%] h-[120%] object-contain pointer-events-none scale-105" />
                         </div>
                     )}
                   </div>
                </div>
             </div>
          </div>
       )}
       {/* Detail Modal */}
       {selectedDetail && activeDetailItem && (
          <div className="absolute inset-0 bg-white/80 z-[60] flex flex-col items-center justify-start animate-in slide-in-from-bottom" style={themeSettings.appBackgrounds['social'] ? { backgroundImage: `url(${themeSettings.appBackgrounds['social']})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}>
             <div className={cn("absolute inset-0 bg-white/60 backdrop-blur-md z-0 pointer-events-none")}></div>
             
             <div className="w-full flex items-center justify-between p-6 bg-white/60 backdrop-blur-xl shrink-0 relative z-10 border-b border-gray-200">
                <button onClick={() => setSelectedDetail(null)} className="text-gray-600 active:scale-95 transition-all w-8 h-8 flex justify-center items-center rounded-full hover:bg-gray-100/60">
                   <ChevronLeft size={24} />
                </button>
                <div className="flex items-center justify-center flex-col">
                   <h2 className="font-bold text-[#111] text-xs tracking-widest uppercase truncate max-w-[200px]">
                      {activeDetailItem.title}
                   </h2>
                </div>
                <div className="w-8"></div>
             </div>

             <div className="flex-grow w-full overflow-y-auto relative z-10 p-6">
                <div className="bg-white/40 p-6 rounded-2xl shadow-sm border border-gray-100 mb-6">
                   <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 rounded-full bg-pink-100 text-pink-600 flex items-center justify-center font-bold text-lg shrink-0">
                         {activeDetailItem.icon}
                      </div>
                      <div className="flex flex-col">
                         <span className="font-bold text-gray-900">{activeDetailItem.sender || activeDetailItem.title}</span>
                         <span className="text-xs text-gray-500">{activeDetailItem.time || activeDetailItem.desc}</span>
                      </div>
                   </div>
                   
                   {activeDetailItem.amount && (
                      <div className={cn("text-2xl font-bold mb-4", activeDetailItem.isPos ? "text-emerald-600" : "text-gray-900")}>
                         {activeDetailItem.amount} N
                      </div>
                   )}
                   
                   <div className="h-px w-full bg-gray-200 my-4" />
                   
                   {isGeneratingDetail && !activeDetailItem.fullContent ? (
                      <div className="py-8 flex flex-col items-center justify-center gap-3">
                         <PawPrint className="animate-spin text-pink-400" size={24} />
                         <span className="text-xs text-gray-400 tracking-widest uppercase">Đang giải mã dữ liệu...</span>
                      </div>
                   ) : (
                      <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap font-serif">
                         {activeDetailItem.fullContent}
                      </div>
                   )}
                </div>
             </div>
          </div>
       )}
    </div>
  );
}
