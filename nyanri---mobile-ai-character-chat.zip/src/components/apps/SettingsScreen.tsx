import AppLayout from './AppLayout';
import { useAppStore, saveAppData, clearAppData } from '../../store/useAppStore';
import { Camera, Save, Palette, Image as ImageIcon, AlertTriangle, Plus } from 'lucide-react';
import { useState, useRef } from 'react';
import { cn } from '../../lib/utils';
import localforage from 'localforage';

export default function SettingsScreen() {
  const { currentCharacter, userProfile, updateUserProfile, updateContact, themeSettings, updateThemeSettings, setHomeEditMode, replaceScreen, playerWidgets, updatePlayerWidget } = useAppStore();
  const [userName, setUserName] = useState(userProfile.name);
  const [userStatus, setUserStatus] = useState(userProfile.status);
  const [userBadge, setUserBadge] = useState(userProfile.badge);
  const [charName, setCharName] = useState(currentCharacter?.name || '');
  const [isSaved, setIsSaved] = useState(false);

  const [homeBackground, setHomeBackground] = useState(themeSettings.homeBackground);
  const [chatBackground, setChatBackground] = useState(themeSettings.chatBackground);
  const [appBackground, setAppBackground] = useState(themeSettings.appBackground || '');
  const [appBackgrounds, setAppBackgrounds] = useState<Record<string, string>>(themeSettings.appBackgrounds || {});
  const [appIcons, setAppIcons] = useState<Record<string, string>>(themeSettings.appIcons || {});
  const [userFrame, setUserFrame] = useState(themeSettings.userFrame || '');
  const [characterFrame, setCharacterFrame] = useState(themeSettings.characterFrame || '');
  const [appFrame, setAppFrame] = useState(themeSettings.appFrame || '');

  const APPS_LIST = [
    { id: 'chat', name: 'Nhắn tin' },
    { id: 'contacts', name: 'Danh bạ' },
    { id: 'forum', name: 'Diễn đàn' },
    { id: 'diary', name: 'Nhật ký' },
    { id: 'shoprj', name: 'Shoprj' },
    { id: 'social', name: 'Nj' },
    { id: 'worldbook', name: 'Worldbook' },
    { id: 'settings', name: 'Cài đặt' },
  ];

  const userFileInput = useRef<HTMLInputElement>(null);
  const charFileInput = useRef<HTMLInputElement>(null);
  const homeBgInput = useRef<HTMLInputElement>(null);
  const chatBgInput = useRef<HTMLInputElement>(null);
  const appBgInput = useRef<HTMLInputElement>(null);
  const userFrameInput = useRef<HTMLInputElement>(null);
  const charFrameInput = useRef<HTMLInputElement>(null);
  const appFrameInput = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (url: string) => void) => {
     if (e.target.files && e.target.files[0]) {
        const reader = new FileReader();
        reader.onload = (ev) => {
           if (typeof ev.target?.result === 'string') {
              setter(ev.target.result);
           }
        };
        reader.readAsDataURL(e.target.files[0]);
     }
  };

  const handleSave = () => {
     updateUserProfile({ name: userName, status: userStatus, badge: userBadge });
     if (currentCharacter) {
        updateContact(currentCharacter.id, { name: charName });
     }
     updateThemeSettings({
        homeBackground,
        chatBackground,
        appBackground,
        appBackgrounds,
        appIcons,
        userFrame,
        characterFrame,
        appFrame
     });
     saveAppData(); // Ensure data is saved manually
     setIsSaved(true);
     setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <AppLayout title="Cài đặt" bgClass="bg-[#FAFAFA]" appId="settings">
      <div className="px-5 py-6 pb-24 text-[#1A1A1A] space-y-8 h-full overflow-y-auto">
         
         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer active:scale-[0.98] transition-transform" onClick={() => {
            setHomeEditMode(true);
            replaceScreen('home');
         }}>
            <h3 className="font-bold text-gray-800 text-sm">Sắp xếp Màn hình chính</h3>
            <span className="text-pink-500 font-medium text-xs bg-pink-50/60 px-3 py-1.5 rounded-full inline-block">Mở »</span>
         </div>

         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer active:scale-[0.98] transition-transform" onClick={() => {
            saveAppData();
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 2000);
         }}>
            <h3 className="font-bold text-gray-800 text-sm">Lưu nhanh dữ liệu</h3>
            <span className={cn(
               "font-medium text-xs px-3 py-1.5 rounded-full inline-block transition-colors",
               isSaved ? "bg-green-100 text-green-600" : "bg-blue-50 text-blue-500"
            )}>
               {isSaved ? "Đã lưu ✓" : "Lưu ngay"}
            </span>
         </div>

         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 relative">
            <h3 className="font-bold text-gray-800 mb-4 text-center">Hồ sơ Của Bạn</h3>
            
            {/* Avatars */}
            <div className="flex justify-center gap-6 mb-6">
               <div className="flex flex-col items-center">
                  <span className="text-[10px] font-bold text-gray-400 mb-2 uppercase">Chính</span>
                  <div className="relative w-16 h-16 group">
                     <div 
                        className="w-16 h-16 rounded-full bg-gray-100/60 border border-gray-200 overflow-hidden relative cursor-pointer"
                        onClick={() => userFileInput.current?.click()}
                     >
                        <img src={userProfile.avatar} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
                           <Camera className="text-white" size={20} />
                        </div>
                     </div>
                     {userFrame && (
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[92px] h-[92px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${userFrame})` }} />
                     )}
                  </div>
                  <input type="file" accept="image/*" ref={userFileInput} className="hidden" onChange={(e) => handleImageUpload(e, (url) => updateUserProfile({ avatar: url }))} />
               </div>

               <div className="flex flex-col items-center">
                  <span className="text-[10px] font-bold text-gray-400 mb-2 uppercase">Chat</span>
                  <div className="relative w-16 h-16 group">
                     <div 
                        className="w-16 h-16 rounded-full bg-gray-100/60 border border-gray-200 overflow-hidden relative cursor-pointer"
                        onClick={() => {
                           const el = document.getElementById('chatAvatarUpload') as HTMLInputElement;
                           if(el) el.click();
                        }}
                     >
                        <img src={userProfile.chatAvatar || userProfile.avatar} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
                           <Camera className="text-white" size={20} />
                        </div>
                     </div>
                  </div>
                  <input id="chatAvatarUpload" type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, (url) => updateUserProfile({ chatAvatar: url }))} />
               </div>

               <div className="flex flex-col items-center">
                  <span className="text-[10px] font-bold text-gray-400 mb-2 uppercase">Nj</span>
                  <div className="relative w-16 h-16 group">
                     <div 
                        className="w-16 h-16 rounded-full bg-gray-100/60 border border-gray-200 overflow-hidden relative cursor-pointer"
                        onClick={() => {
                           const el = document.getElementById('socialAvatarUpload') as HTMLInputElement;
                           if(el) el.click();
                        }}
                     >
                        <img src={userProfile.socialAvatar || userProfile.avatar} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
                           <Camera className="text-white" size={20} />
                        </div>
                     </div>
                  </div>
                  <input id="socialAvatarUpload" type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, (url) => updateUserProfile({ socialAvatar: url }))} />
               </div>
            </div>
            
            <div className="flex flex-col items-center justify-center">
               <div className="w-full">
                  <label className="text-xs font-medium text-gray-500 mb-1 block">Tên hiển thị</label>
                  <input 
                     type="text" 
                     value={userName}
                     onChange={(e) => setUserName(e.target.value)}
                     className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors"
                  />
               </div>

               <div className="mt-4 w-full">
                  <label className="text-xs font-medium text-gray-500 mb-1 block">Trạng thái</label>
                  <input 
                     type="text" 
                     value={userStatus}
                     onChange={(e) => setUserStatus(e.target.value)}
                     className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors"
                  />
               </div>
               
               <div className="mt-4 w-full">
                  <label className="text-xs font-medium text-gray-500 mb-1 block">Icon góc</label>
                  <input 
                     type="text" 
                     value={userBadge}
                     onChange={(e) => setUserBadge(e.target.value)}
                     maxLength={2}
                     className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors"
                  />
               </div>
            </div>
         </div>

         {currentCharacter && (
         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 relative">
            <h3 className="font-bold text-gray-800 mb-4 text-center">Hồ sơ Nhân vật</h3>
            <div className="flex flex-col items-center justify-center">
               <div className="relative w-20 h-20 group">
                  <div 
                     className="w-20 h-20 rounded-full bg-gray-100/60 border border-gray-200 overflow-hidden relative cursor-pointer"
                     onClick={() => charFileInput.current?.click()}
                  >
                     <img src={currentCharacter.avatar} className="w-full h-full object-cover" />
                     <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-active:opacity-100 transition-opacity">
                        <Camera className="text-white" size={24} />
                     </div>
                  </div>
                  {characterFrame && (
                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[116px] h-[116px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${characterFrame})` }} />
                  )}
               </div>
               <input type="file" accept="image/*" ref={charFileInput} className="hidden" onChange={(e) => currentCharacter && handleImageUpload(e, (url) => updateContact(currentCharacter.id, { avatar: url }))} />
               
               <div className="mt-4 w-full">
                  <label className="text-xs font-medium text-gray-500 mb-1 block">Tên nhân vật</label>
                  <input 
                     type="text" 
                     value={charName}
                     onChange={(e) => setCharName(e.target.value)}
                     className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors"
                  />
               </div>
            </div>
         </div>
         )}

         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 relative">
            <h3 className="font-bold text-gray-800 mb-4 text-center">Giao diện (Theme)</h3>
            <div className="space-y-4">
               <div>
                  <label className="text-xs font-medium text-gray-500 mb-2 flex items-center justify-between">
                     <span>Nền Màn hình chính</span>
                     <button onClick={() => homeBgInput.current?.click()} className="text-pink-500 font-medium active:scale-95 transition-transform"><ImageIcon size={14} /></button>
                  </label>
                  <input type="file" accept="image/*" ref={homeBgInput} className="hidden" onChange={(e) => handleImageUpload(e, setHomeBackground)} />
                  <div className="flex space-x-2">
                     <input 
                        type="text" 
                        value={homeBackground}
                        onChange={(e) => setHomeBackground(e.target.value)}
                        placeholder="Image URL"
                        className="flex-1 bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors text-xs"
                     />
                  </div>
                  {homeBackground && (
                     <div className="mt-2 h-20 w-full rounded-xl bg-cover bg-center border border-gray-200" style={{ backgroundImage: `url(${homeBackground})` }}></div>
                  )}
               </div>

               <div className="pt-2 border-t border-gray-100">
                  <label className="text-xs font-medium text-gray-500 mb-2 flex items-center justify-between">
                     <span>Nền Màn hình Chat</span>
                     <button onClick={() => chatBgInput.current?.click()} className="text-pink-500 font-medium active:scale-95 transition-transform"><ImageIcon size={14} /></button>
                  </label>
                  <input type="file" accept="image/*" ref={chatBgInput} className="hidden" onChange={(e) => handleImageUpload(e, setChatBackground)} />
                  <div className="flex space-x-2">
                     <input 
                        type="text" 
                        value={chatBackground}
                        onChange={(e) => setChatBackground(e.target.value)}
                        placeholder="Image URL"
                        className="flex-1 bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors text-xs"
                     />
                  </div>
                  {chatBackground && (
                     <div className="mt-2 h-20 w-full rounded-xl bg-cover bg-center border border-gray-200" style={{ backgroundImage: `url(${chatBackground})` }}></div>
                  )}
               </div>

               <div className="pt-2 border-t border-gray-100">
                  <label className="text-xs font-medium text-gray-500 mb-2 flex items-center justify-between">
                     <span>Nền Mặc định Trong các App Khác</span>
                     <label htmlFor="appBgInput" className="text-pink-500 font-medium active:scale-95 transition-transform cursor-pointer"><ImageIcon size={14} /></label>
                  </label>
                  <input id="appBgInput" type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, setAppBackground)} />
                  <div className="flex space-x-2">
                     <input 
                        type="text" 
                        value={appBackground}
                        onChange={(e) => setAppBackground(e.target.value)}
                        placeholder="Image URL"
                        className="flex-1 bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors text-xs"
                     />
                  </div>
                  {appBackground && (
                     <div className="mt-2 h-20 w-full rounded-xl bg-cover bg-center border border-gray-200" style={{ backgroundImage: `url(${appBackground})` }}></div>
                  )}
               </div>

               <div className="pt-4 border-t border-gray-100">
                  <span className="text-sm font-bold text-gray-800 mb-3 block">Nền Riêng Từng Ứng dụng</span>
                  <div className="space-y-4">
                     {APPS_LIST.map(app => (
                        <div key={app.id} className="bg-gray-50/60 p-3 rounded-xl border border-gray-100">
                           <label className="text-xs font-bold text-gray-700 mb-2 flex items-center justify-between">
                              <span>Nền "{app.name}"</span>
                              <label htmlFor={`appBg_${app.id}`} className="text-pink-500 font-medium active:scale-95 transition-transform cursor-pointer">
                                 <ImageIcon size={14} />
                              </label>
                           </label>
                           <input id={`appBg_${app.id}`} type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, (url) => setAppBackgrounds(prev => ({...prev, [app.id]: url})))} />
                           <div className="flex space-x-2">
                              <input 
                                 type="text" 
                                 value={appBackgrounds[app.id] || ''}
                                 onChange={(e) => setAppBackgrounds(prev => ({...prev, [app.id]: e.target.value}))}
                                 placeholder="Image URL"
                                 className="flex-1 bg-white/80 border border-gray-200 rounded-xl px-3 py-2 outline-none focus:border-pink-300 transition-colors text-xs"
                              />
                           </div>
                           {appBackgrounds[app.id] && (
                              <div className="mt-2 h-16 w-full rounded-xl bg-cover bg-center border border-gray-200" style={{ backgroundImage: `url(${appBackgrounds[app.id]})` }}></div>
                           )}
                        </div>
                     ))}
                  </div>
               </div>

               <div className="pt-4 border-t border-gray-100">
                  <span className="text-sm font-bold text-gray-800 mb-3 block">Icon Riêng Từng Ứng dụng</span>
                  <div className="space-y-4">
                     {APPS_LIST.map(app => (
                        <div key={`icon_${app.id}`} className="bg-gray-50/60 p-3 rounded-xl border border-gray-100">
                           <label className="text-xs font-bold text-gray-700 mb-2 flex items-center justify-between">
                              <span>Icon "{app.name}"</span>
                              <label htmlFor={`appIcon_${app.id}`} className="text-pink-500 font-medium active:scale-95 transition-transform cursor-pointer">
                                 <ImageIcon size={14} />
                              </label>
                           </label>
                           <input id={`appIcon_${app.id}`} type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, (url) => setAppIcons(prev => ({...prev, [app.id]: url})))} />
                           <div className="flex space-x-2">
                              <input 
                                 type="text" 
                                 value={appIcons[app.id] || ''}
                                 onChange={(e) => setAppIcons(prev => ({...prev, [app.id]: e.target.value}))}
                                 placeholder="Image URL"
                                 className="flex-1 bg-white/80 border border-gray-200 rounded-xl px-3 py-2 outline-none focus:border-pink-300 transition-colors text-xs"
                              />
                           </div>
                           {appIcons[app.id] && (
                              <div className="mt-2 h-12 w-12 mx-auto rounded-xl bg-cover bg-center border border-gray-200 shadow-sm" style={{ backgroundImage: `url(${appIcons[app.id]})` }}></div>
                           )}
                        </div>
                     ))}
                  </div>
               </div>

               {/* Khung Trang Trí */}
               <div className="pt-4 border-t border-gray-100">
                  <span className="text-sm font-bold text-gray-800 mb-3 block">Khung Trang Trí (Ảnh PNG trong suốt)</span>
                  <div className="space-y-4">
                     {/* Khung User */}
                     <div className="bg-gray-50/60 p-3 rounded-xl border border-gray-100">
                        <label className="text-xs font-bold text-gray-700 mb-2 flex items-center justify-between">
                           <span>Khung Avatar Của Bạn</span>
                           <button onClick={() => userFrameInput.current?.click()} className="text-pink-500 font-medium active:scale-95 transition-transform"><ImageIcon size={14} /></button>
                        </label>
                        <input type="file" accept="image/png,image/gif" ref={userFrameInput} className="hidden" onChange={(e) => handleImageUpload(e, setUserFrame)} />
                        <div className="flex space-x-2">
                           <input 
                              type="text" 
                              value={userFrame}
                              onChange={(e) => setUserFrame(e.target.value)}
                              placeholder="Image URL (PNG/GIF)"
                              className="flex-1 bg-white/80 border border-gray-200 rounded-xl px-3 py-2 outline-none focus:border-pink-300 transition-colors text-xs"
                           />
                        </div>
                        {userFrame && (
                           <div className="mt-2 h-16 w-16 mx-auto rounded-xl bg-contain bg-center bg-no-repeat border border-gray-200 bg-white/80" style={{ backgroundImage: `url(${userFrame})` }}></div>
                        )}
                     </div>

                     {/* Khung Character */}
                     <div className="bg-gray-50/60 p-3 rounded-xl border border-gray-100">
                        <label className="text-xs font-bold text-gray-700 mb-2 flex items-center justify-between">
                           <span>Khung Avatar Nhân Vật</span>
                           <button onClick={() => charFrameInput.current?.click()} className="text-pink-500 font-medium active:scale-95 transition-transform"><ImageIcon size={14} /></button>
                        </label>
                        <input type="file" accept="image/png,image/gif" ref={charFrameInput} className="hidden" onChange={(e) => handleImageUpload(e, setCharacterFrame)} />
                        <div className="flex space-x-2">
                           <input 
                              type="text" 
                              value={characterFrame}
                              onChange={(e) => setCharacterFrame(e.target.value)}
                              placeholder="Image URL (PNG/GIF)"
                              className="flex-1 bg-white/80 border border-gray-200 rounded-xl px-3 py-2 outline-none focus:border-pink-300 transition-colors text-xs"
                           />
                        </div>
                        {characterFrame && (
                           <div className="mt-2 h-16 w-16 mx-auto rounded-xl bg-contain bg-center bg-no-repeat border border-gray-200 bg-white/80" style={{ backgroundImage: `url(${characterFrame})` }}></div>
                        )}
                     </div>

                     {/* Khung App */}
                     <div className="bg-gray-50/60 p-3 rounded-xl border border-gray-100">
                        <label className="text-xs font-bold text-gray-700 mb-2 flex items-center justify-between">
                           <span>Khung Icon Ứng Dụng</span>
                           <button onClick={() => appFrameInput.current?.click()} className="text-pink-500 font-medium active:scale-95 transition-transform"><ImageIcon size={14} /></button>
                        </label>
                        <input type="file" accept="image/png,image/gif" ref={appFrameInput} className="hidden" onChange={(e) => handleImageUpload(e, setAppFrame)} />
                        <div className="flex space-x-2">
                           <input 
                              type="text" 
                              value={appFrame}
                              onChange={(e) => setAppFrame(e.target.value)}
                              placeholder="Image URL (PNG/GIF)"
                              className="flex-1 bg-white/80 border border-gray-200 rounded-xl px-3 py-2 outline-none focus:border-pink-300 transition-colors text-xs"
                           />
                        </div>
                        {appFrame && (
                           <div className="mt-2 h-16 w-16 mx-auto rounded-xl bg-contain bg-center bg-no-repeat border border-gray-200 bg-white/80" style={{ backgroundImage: `url(${appFrame})` }}></div>
                        )}
                     </div>
                  </div>
               </div>
            </div>
         </div>

         <button 
            onClick={handleSave}
            className={cn(
               "w-full py-3.5 rounded-xl flex items-center justify-center gap-2 font-medium transition-colors shadow-sm",
               isSaved ? "bg-green-500 text-white" : "bg-pink-500 text-white active:bg-pink-600"
            )}
         >
            <Save size={20} />
            {isSaved ? "Đã lưu" : "Lưu thay đổi"}
         </button>

         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 relative mt-4">
            <h3 className="font-bold text-gray-800 mb-4 text-center">Cài đặt Widget Nhạc</h3>
            <div className="space-y-4 mb-4">
               <div>
                  <label className="text-xs font-medium text-gray-500 mb-1 block">Tên bài hát / Tiêu đề</label>
                  <input 
                     type="text" 
                     value={playerWidgets?.['widget-player-DEFAULT']?.title || 'carpe diem'}
                     onChange={(e) => updatePlayerWidget('widget-player-DEFAULT', { title: e.target.value })}
                     className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none focus:border-pink-300 transition-colors"
                  />
               </div>
               <div>
                  <label className="text-xs font-medium text-gray-500 mb-1 block">Tải lên File Nhạc (MP3...)</label>
                  <input 
                    type="file" 
                    accept="audio/*" 
                    className="hidden" 
                    id="settingsAudioUpload"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const localKey = `localforage:media-widget-player-DEFAULT`;
                        try {
                          await localforage.setItem(localKey, file);
                          updatePlayerWidget('widget-player-DEFAULT', { mediaUrl: localKey });
                        } catch (err) {
                          console.error("Failed to save audio", err);
                        }
                      }
                    }}
                  />
                  <button 
                    type="button" 
                    onClick={(e) => { e.preventDefault(); document.getElementById('settingsAudioUpload')?.click(); }}
                    className="w-full bg-gray-50/60 border border-gray-200 rounded-xl px-4 py-2.5 outline-none hover:border-pink-300 transition-colors text-left text-gray-600 flex justify-between items-center"
                  >
                    <span>{playerWidgets?.['widget-player-DEFAULT']?.mediaUrl?.startsWith('localforage:') ? 'Đã tải lên Audio File. Bấm để đổi.' : 'Bấm để tải file nhạc lên'}</span>
                    <Plus size={16} className="text-gray-400" />
                  </button>
               </div>
            </div>
            
            <p className="text-[11px] text-gray-400 text-center mb-4">Mẹo: Bạn có thể đăng tải trực tiếp Ảnh Bìa từ điện thoại bằng cách bấm Sửa (icon Link / +) trên từng Widget ở Màn hình chính.</p>
            <button 
               onClick={() => {
                  const items = useAppStore.getState().homeItems || [];
                  useAppStore.getState().setHomeItems([...items, `widget-player-${Date.now()}`]);
                  saveAppData();
                  setIsSaved(true);
                  setTimeout(() => setIsSaved(false), 2000);
               }}
               className="w-full bg-pink-50/60 text-pink-500 py-3 rounded-xl flex items-center justify-center gap-2 font-bold transition-colors active:bg-pink-100 border border-pink-100"
            >
               <Plus size={18} />
               Thêm 1 Widget Nhạc Mới
            </button>
         </div>

         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-gray-100 relative mt-4">
            <h3 className="font-bold text-gray-800 mb-4 text-center">Tiện ích Khác</h3>
            <button 
               onClick={() => {
                  const items = useAppStore.getState().homeItems || [];
                  useAppStore.getState().setHomeItems([...items, `widget-photo-${Date.now()}`]);
                  saveAppData(); // Ensure explicit save
                  setIsSaved(true);
                  setTimeout(() => setIsSaved(false), 2000);
               }}
               className="w-full bg-pink-50/60 text-pink-500 py-3 rounded-xl flex items-center justify-center gap-2 font-bold transition-colors active:bg-pink-100 border border-pink-100"
            >
               <ImageIcon size={18} />
               Thêm Widget Ảnh vào Home
            </button>
            <p className="text-[10px] text-gray-400 text-center mt-3">Widget sẽ được thêm vào màn hình chính, bạn có thể bấm "Sắp xếp" ở màn hình chính để di chuyển hoặc xóa.</p>
         </div>

         <div className="bg-white/80 p-5 rounded-2xl shadow-sm border border-red-100 relative mt-4">
            <h3 className="font-bold text-red-600 mb-4 text-center flex items-center justify-center gap-2">
               <AlertTriangle size={18} /> Khôi phục Dữ liệu
            </h3>
            <p className="text-xs text-gray-500 text-center mb-4 leading-relaxed">
               Nếu ứng dụng bị lỗi không thể hoạt động do dữ liệu cũ từ phiên bản trước đó, bạn có thể xóa toàn bộ dữ liệu lưu trữ để đặt lại ứng dụng về trạng thái ban đầu.
            </p>
            <button 
               onClick={() => {
                  if (window.confirm("Hành động này sẽ xóa toàn bộ tin nhắn, cài đặt và hồ sơ. Bạn có chắc chắn muốn khôi phục?")) {
                     clearAppData();
                  }
               }}
               className="w-full bg-red-50 text-red-600 border border-red-200 py-3 rounded-xl flex items-center justify-center gap-2 font-bold active:bg-red-100 transition-colors"
            >
               <AlertTriangle size={18} />
               Xóa Toàn bộ Dữ liệu
            </button>
         </div>

      </div>
    </AppLayout>
  );
}
