import { useState } from 'react';
import { useAppStore, DiaryEntry } from '../../store/useAppStore';
import { ChevronLeft, PenLine, CloudRain, Sun, Moon, Cloud, PawPrint, User as UserIcon, Trash2, X, Check } from 'lucide-react';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function DiaryScreen() {
  const { currentCharacter, userProfile, contacts, popScreen, diaries, addDiaryEntry, deleteDiaryEntry, messagesByContact, themeSettings } = useAppStore();
  const [viewingAuthor, setViewingAuthor] = useState<string | null>(null);
  const [isWriting, setIsWriting] = useState(false);
  const [draftContent, setDraftContent] = useState('');
  const [draftMood, setDraftMood] = useState('');
  const [draftWeather, setDraftWeather] = useState<'sun' | 'cloud' | 'rain' | 'moon'>('sun');
  const [isGenerating, setIsGenerating] = useState(false);

  // Author Selection View
  if (!viewingAuthor) {
    return (
      <div className="absolute inset-0 bg-[#F5F0F5] flex flex-col pt-12">
        <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-multiply" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cream-paper.png')" }}></div>
        <div className="flex items-center px-4 mb-2 z-10 relative">
          <button onClick={popScreen} className="p-2 -ml-2 text-[#1A1A1A] active:scale-95">
            <ChevronLeft />
          </button>
          <h1 className="font-serif italic text-2xl flex-grow text-center text-[#1A1A1A] border-b border-[#D4D4D4] pb-2 mx-4">
            Góc Nhật Ký
          </h1>
          <div className="w-10"></div>
        </div>

        <div className="flex-grow px-6 py-6 overflow-y-auto space-y-4 relative z-10">
          <div 
            onClick={() => setViewingAuthor('user')}
            className="bg-white/80 p-4 rounded-3xl shadow-sm border border-[#F2C4CE] flex items-center gap-4 cursor-pointer active:scale-95 transition-transform"
          >
             <div className="relative w-14 h-14 shrink-0">
                <div className="w-14 h-14 rounded-full border-2 border-pink-200 overflow-hidden relative z-0 bg-white/80">
                   <img src={userProfile.avatar} className="w-full h-full object-cover" />
                </div>
                {themeSettings?.userFrame && (
                   <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[72px] h-[72px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.userFrame})` }} />
                )}
             </div>
             <div>
                <h3 className="font-serif text-lg italic text-gray-800">Nhật ký của tôi</h3>
                <p className="text-xs text-gray-500">{diaries['user']?.length || 0} bài viết</p>
             </div>
          </div>

          <div className="text-sm font-semibold text-gray-500 mt-8 mb-4 uppercase tracking-wider pl-2">Nhật ký của người ấy</div>
          
          {contacts.map(c => (
            <div 
              key={c.id}
              onClick={() => setViewingAuthor(c.id)}
              className="bg-white/60 p-4 rounded-3xl shadow-sm border border-gray-200 flex items-center gap-4 cursor-pointer active:scale-95 transition-transform"
            >
               <div className="relative w-14 h-14 shrink-0">
                  <div className="w-14 h-14 rounded-full border-2 border-gray-200 overflow-hidden relative z-0 bg-white/80">
                     <img src={c.avatar} className="w-full h-full object-cover" />
                  </div>
                  {themeSettings?.characterFrame && (
                     <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[72px] h-[72px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${themeSettings.characterFrame})` }} />
                  )}
               </div>
               <div>
                  <h3 className="font-serif text-lg italic text-gray-800">{c.name}</h3>
                  <p className="text-xs text-gray-500">{diaries[c.id]?.length || 0} bài viết</p>
               </div>
            </div>
          ))}

          {contacts.length === 0 && (
            <p className="text-center text-sm text-gray-400 mt-10 italic">Hãy tạo nhân vật để đọc nhật ký của họ.</p>
          )}
        </div>
      </div>
    );
  }

  const isUser = viewingAuthor === 'user';
  const authorInfo = isUser ? userProfile : contacts.find(c => c.id === viewingAuthor);
  const authorEntries = diaries[viewingAuthor] || [];

  const handleSaveDraft = () => {
     if (!draftContent.trim()) return;
     addDiaryEntry(viewingAuthor, {
        id: Date.now().toString(),
        authorId: viewingAuthor,
        date: new Date().toISOString(),
        content: draftContent,
        moodTag: draftMood || 'bình thường',
        weatherIcon: draftWeather
     });
     setIsWriting(false);
     setDraftContent('');
     setDraftMood('');
  };

  const handleGenerateDiary = () => {
     if (isUser) return;
     setIsGenerating(true);
     // Simulate AI generation based on messages context
     setTimeout(() => {
        const msgs = messagesByContact[viewingAuthor] || [];
        const hasMessages = msgs.length > 0;
        let generatedContent = '';
        let generatedMood = 'vui vẻ';
        
        if (hasMessages) {
           generatedContent = `Hôm nay mình và user đã trò chuyện rất nhiều. ${msgs[msgs.length - 1].content.substring(0, 50)}... Họ thật ấm áp, làm mình cảm thấy rất đặc biệt.`;
           generatedMood = 'hạnh phúc';
        } else {
           generatedContent = `Một ngày trôi qua, tự nhiên muốn nói chuyện với họ một chút nhưng lại ngần ngại. Không biết họ đang làm gì nhỉ?`;
           generatedMood = 'nhớ nhung';
        }

        addDiaryEntry(viewingAuthor, {
           id: Date.now().toString(),
           authorId: viewingAuthor,
           date: new Date().toISOString(),
           content: generatedContent,
           moodTag: generatedMood,
           weatherIcon: 'cloud'
        });
        setIsGenerating(false);
     }, 2000);
  };

  const WeatherIcon = ({ type }: { type: string }) => {
     switch(type) {
        case 'sun': return <Sun size={14} />;
        case 'cloud': return <Cloud size={14} />;
        case 'rain': return <CloudRain size={14} />;
        case 'moon': return <Moon size={14} />;
        default: return <Sun size={14} />;
     }
  };

  return (
    <div className="absolute inset-0 bg-[#F5F0F5] flex flex-col pt-12">
      <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-multiply" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cream-paper.png')" }}></div>

      {/* Header */}
      <div className="flex items-center px-4 mb-2 z-10 relative bg-[#F5F0F5]/80 backdrop-blur-sm pb-2">
        <button onClick={() => setViewingAuthor(null)} className="p-2 -ml-2 text-[#1A1A1A] active:scale-95">
          <ChevronLeft />
        </button>
        <h1 className="font-serif italic text-2xl flex-grow text-center text-[#1A1A1A] truncate px-2">
          {authorInfo?.name}
        </h1>
        <div className="w-auto flex justify-end">
           <div className="relative w-8 h-8 shrink-0">
              <img src={authorInfo?.avatar} className="w-8 h-8 rounded-full border border-[#D4D4D4] object-cover" />
              {(viewingAuthor === 'user' ? themeSettings?.userFrame : themeSettings?.characterFrame) && (
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[44px] h-[44px] pointer-events-none bg-contain bg-no-repeat bg-center z-10" style={{ backgroundImage: `url(${viewingAuthor === 'user' ? themeSettings?.userFrame : themeSettings?.characterFrame})` }} />
              )}
           </div>
        </div>
      </div>

      <div className="h-[1px] bg-[#D4D4D4] mx-4 relative z-10 mb-4 opacity-50"></div>

      {/* Diary Entries */}
      <div className="flex-grow overflow-y-auto px-6 pb-24 space-y-6 relative z-10 no-scrollbar">
        {authorEntries.map(entry => (
          <div key={entry.id} className="bg-white/80 p-6 rounded-3xl shadow-sm border border-[#F2C4CE] relative group">
             {isUser && (
                <button 
                  onClick={() => deleteDiaryEntry(viewingAuthor, entry.id)}
                  className="absolute top-4 right-4 text-red-300 opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-red-50 rounded-full"
                >
                   <Trash2 size={14} />
                </button>
             )}
             <div>
                <div className="flex justify-between items-end mb-4 border-b border-[#F8E8EE] pb-3 pr-6">
                   <div className="font-serif italic text-2xl text-[#1A1A1A]">{format(new Date(entry.date), 'dd/MM/yyyy')}</div>
                   <div className="flex items-center space-x-2 text-[#C9748A] text-xs">
                     <span className="bg-[#F8E8EE] px-3 py-1 rounded-full uppercase tracking-wider text-[9px] font-bold">♡ {entry.moodTag}</span>
                     <WeatherIcon type={entry.weatherIcon} />
                   </div>
                </div>
                <p className="font-sans text-sm text-[#2D2D2D] leading-relaxed whitespace-pre-wrap">
                   {entry.content}
                </p>
             </div>
          </div>
        ))}
        {authorEntries.length === 0 && (
           <div className="text-center text-gray-400 italic text-sm mt-10">
              Trang giấy trắng tinh. Chưa có dòng nhật ký nào.
           </div>
        )}
      </div>

      {/* Floating Buttons */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center z-20 gap-4">
         {isUser ? (
             <button 
                onClick={() => setIsWriting(true)}
                className="w-14 h-14 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center shadow-lg hover:bg-black active:scale-95 transition-transform border-4 border-[#F5F0F5]"
             >
                <PenLine size={20} />
             </button>
         ) : (
            <button 
               onClick={handleGenerateDiary}
               disabled={isGenerating}
               className={cn(
                  "h-14 px-6 bg-pink-500 text-white rounded-full flex items-center justify-center gap-2 shadow-lg hover:bg-pink-600 active:scale-95 transition-all border-4 border-[#F5F0F5]",
                  isGenerating && "opacity-70 cursor-not-allowed scale-95"
               )}
            >
               {isGenerating ? (
                  <span className="animate-pulse">Đang viết...</span>
               ) : (
                  <>
                    <PawPrint size={24} />
                  </>
               )}
            </button>
         )}
      </div>

      {/* Write Diary Modal */}
      {isWriting && (
         <div className="absolute inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center sm:p-4 backdrop-blur-sm">
            <div className="bg-[#F5F0F5] w-full sm:max-w-md h-[90%] sm:h-auto sm:max-h-[90%] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col relative overflow-hidden animate-in slide-in-from-bottom flex">
               <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-multiply" style={{ backgroundImage: "url('https://www.transparenttextures.com/patterns/cream-paper.png')" }}></div>
               
               <div className="relative z-10 flex items-center justify-between p-4 border-b border-[#D4D4D4]">
                  <button onClick={() => setIsWriting(false)} className="p-2 text-gray-500">
                     <X size={20} />
                  </button>
                  <h2 className="font-serif italic font-bold">Trang mới</h2>
                  <button 
                     onClick={handleSaveDraft}
                     className={cn("p-2 text-pink-500 font-medium flex items-center gap-1", !draftContent.trim() && "opacity-50")}
                  >
                     <Check size={18} /> Lưu
                  </button>
               </div>

               <div className="p-5 flex-grow overflow-y-auto relative z-10 flex flex-col">
                  <div className="flex justify-between items-center mb-6">
                     <div className="flex gap-2">
                        {(['sun', 'cloud', 'rain', 'moon'] as const).map(w => (
                           <button 
                             key={w}
                             onClick={() => setDraftWeather(w)}
                             className={cn("p-2 rounded-full border transition-colors", draftWeather === w ? "border-pink-300 bg-pink-100 text-pink-600" : "border-gray-200 text-gray-400 bg-white/80")}
                           >
                              <WeatherIcon type={w} />
                           </button>
                        ))}
                     </div>
                     <input 
                        type="text" 
                        value={draftMood}
                        onChange={e => setDraftMood(e.target.value)}
                        placeholder="Tâm trạng (bình yên...)" 
                        className="bg-transparent border-b border-[#D4D4D4] text-right text-sm outline-none w-32 placeholder-gray-400 italic font-serif text-pink-700"
                        maxLength={20}
                     />
                  </div>

                  <textarea 
                     autoFocus
                     value={draftContent}
                     onChange={e => setDraftContent(e.target.value)}
                     placeholder="Hôm nay của bạn thế nào?..."
                     className="w-full flex-grow bg-transparent outline-none resize-none font-sans leading-loose text-gray-800 placeholder-gray-400"
                     style={{
                        backgroundImage: "repeating-linear-gradient(transparent, transparent 31px, #e5e7eb 31px, #e5e7eb 32px)",
                        lineHeight: "32px",
                        backgroundAttachment: "local"
                     }}
                  ></textarea>
               </div>
            </div>
         </div>
      )}
    </div>
  );
}
