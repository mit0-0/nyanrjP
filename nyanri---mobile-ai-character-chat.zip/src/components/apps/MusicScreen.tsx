import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';
import { Play, SkipBack, SkipForward, Pause, Heart, Shuffle, Repeat } from 'lucide-react';
import { cn } from '../../lib/utils';
import { useState } from 'react';

export default function MusicScreen() {
  const { currentCharacter, themeSettings } = useAppStore();
  const [isPlaying, setIsPlaying] = useState(false);

  if (!currentCharacter) return null;

  return (
    <AppLayout title="Âm nhạc" bgClass="bg-[#FFF0F5]" appId="music">
      {/* Optional decorative background from theme */}
      {themeSettings.homeBackground && (
        <div 
          className="absolute inset-0 opacity-40 mix-blend-overlay pointer-events-none bg-cover bg-center"
          style={{ backgroundImage: `url(${themeSettings.homeBackground})` }}
        />
      )}
      
      <div className="relative z-10 px-6 py-8 pb-24 text-gray-800 flex flex-col items-center h-full">
         
         {/* Vinyl Player UI */}
         <div className="relative w-64 h-64 mb-12 flex items-center justify-center mt-8">
            {/* Record grooves */}
            <div className={cn(
              "absolute inset-0 rounded-full bg-[#111] shadow-[0_20px_50px_rgba(201,116,138,0.2)] border-2 border-white/40 flex items-center justify-center",
              isPlaying ? "animate-[spin_4s_linear_infinite]" : ""
            )}>
                <div className="w-full h-full rounded-full border-[12px] border-[#222] relative flex items-center justify-center">
                    <div className="w-[85%] h-[85%] rounded-full border-[2px] border-white/10"></div>
                    <div className="absolute w-[70%] h-[70%] rounded-full border-[1px] border-white/5"></div>
                    <div className="absolute w-[50%] h-[50%] rounded-full border-[1px] border-white/5"></div>
                </div>
                {/* Album Art inside record */}
                <div className="absolute w-24 h-24 rounded-full bg-pink-100 flex items-center justify-center border-4 border-white shadow-inner overflow-hidden">
                   <img 
                      src="https://images.unsplash.com/photo-1518020382113-a7e8fc38eac9?auto=format&fit=crop&q=80&w=400" 
                      className="w-full h-full object-cover"
                   />
                </div>
                {/* Spindle hole */}
                <div className="absolute w-3 h-3 rounded-full bg-[#FFF0F5] z-10 shadow-inner border border-gray-300"></div>
            </div>
         </div>

         {/* Song Info */}
         <div className="text-center mb-8 w-full">
            <h2 className="font-sans font-bold text-2xl mb-1 text-gray-800 tracking-tight">Happy Together</h2>
            <p className="text-pink-500 font-medium text-sm">Maximillian</p>
         </div>

         {/* Lyrics excerpt (decorative) */}
         <div className="text-center mb-10 text-gray-500 text-sm italic space-y-1">
            <p>So fast, I almost missed it</p>
            <p>I spill another glass of wine...</p>
         </div>

         <div className="flex-grow"></div>

         {/* Progress Bar */}
         <div className="w-full mb-8 px-4">
            <div className="h-1.5 w-full bg-pink-100/80 rounded-full overflow-hidden mb-3 shadow-inner">
               <div className="h-full bg-pink-500 w-1/3 rounded-full relative">
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white/80 rounded-full shadow border-2 border-pink-500"></div>
               </div>
            </div>
            <div className="flex justify-between text-[11px] font-bold text-gray-400">
               <span>1:24</span>
               <span>3:45</span>
            </div>
         </div>

         {/* Controls */}
         <div className="flex items-center justify-between w-full px-4">
            <button className="text-gray-400 hover:text-pink-500 transition-colors"><Shuffle size={20} strokeWidth={2.5} /></button>
            
            <div className="flex items-center space-x-6">
               <button className="text-gray-600 hover:text-pink-500 active:scale-90 transition-all"><SkipBack size={32} fill="currentColor" /></button>
               <button 
                  className="w-20 h-20 rounded-full bg-gradient-to-tr from-pink-400 to-pink-300 text-white flex items-center justify-center shadow-[0_8px_20px_rgba(244,143,177,0.4)] hover:scale-105 active:scale-95 transition-all"
                  onClick={() => setIsPlaying(!isPlaying)}
               >
                  {isPlaying ? (
                    <Pause size={32} fill="currentColor" className="ml-0" />
                  ) : (
                    <Play size={32} fill="currentColor" className="ml-1" />
                  )}
               </button>
               <button className="text-gray-600 hover:text-pink-500 active:scale-90 transition-all"><SkipForward size={32} fill="currentColor" /></button>
            </div>

            <button className="text-gray-400 hover:text-pink-500 transition-colors"><Repeat size={20} strokeWidth={2.5} /></button>
         </div>

      </div>
    </AppLayout>
  );
}
