import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';
import { ArrowUpRight, ArrowDownLeft, Wallet } from 'lucide-react';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function BankScreen() {
  const { currentCharacter } = useAppStore();
  if (!currentCharacter) return null;

  return (
    <AppLayout title="Ngân hàng" bgClass="bg-[#F8E8EE]" appId="bank">
      <div className="px-6 py-6 pb-24">
        {/* Account Card */}
        <div className="backdrop-blur-md bg-white/80 border border-white shadow-xl rounded-[32px] p-6 mb-8 relative overflow-hidden">
           <div className="absolute top-0 right-0 p-4 opacity-10">
              <span className="text-8xl">🎀</span>
           </div>
           <div className="flex justify-between items-start mb-6 relative z-10">
              <div className="flex items-center text-[#C9748A]">
                 <Wallet size={20} className="mr-2" />
                 <span className="font-bold text-xs uppercase tracking-widest">Tài khoản chính</span>
              </div>
              <span className="text-xs font-serif italic text-gray-500">**** 8429</span>
           </div>
           
           <div className="relative z-10">
              <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-1">Số dư hiện tại</div>
              <div className="font-serif italic text-4xl text-[#1A1A1A]">¥ 52,000</div>
           </div>
        </div>

        {/* Transfer Action */}
        <div className="flex justify-center mb-8">
           <button className="flex items-center space-x-2 bg-[#1A1A1A] text-white px-8 py-4 rounded-full shadow-lg active:scale-95 transition-transform hover:bg-[#2D2D2D]">
              <ArrowUpRight size={18} />
              <span className="font-bold text-xs uppercase tracking-widest">Chuyển khoản mới</span>
           </button>
        </div>

        {/* Transactions */}
        <h3 className="font-serif italic text-xl text-[#1A1A1A] mb-4 border-b border-[#D4D4D4] pb-2">Lịch sử giao dịch</h3>
        
        <div className="space-y-4">
           {/* Transaction 1 */}
           <div className="bg-white/80 rounded-3xl p-4 shadow-sm border border-white flex items-center">
              <div className="w-12 h-12 rounded-full bg-pink-50/60 text-pink-500 flex items-center justify-center mr-4 shrink-0">
                 <ArrowDownLeft size={20} />
              </div>
              <div className="flex-grow">
                 <div className="flex justify-between items-center mb-0.5">
                    <span className="font-bold text-[#1A1A1A] text-sm">Từ: Người dùng</span>
                    <span className="font-bold text-[#C9748A]">+ ¥ 20.00</span>
                 </div>
                 <div className="text-[10px] text-gray-400 font-medium mb-1">{format(new Date(), 'dd/MM/yyyy')}</div>
                 <p className="text-xs italic text-gray-600 bg-gray-50/60 p-2 rounded-lg border border-gray-100">"tiền mua trà sữa cho mèo nhỏ"</p>
              </div>
           </div>

           {/* Transaction 2 */}
           <div className="bg-white/80 rounded-3xl p-4 shadow-sm border border-white flex items-center">
              <div className="w-12 h-12 rounded-full bg-gray-50/60 text-gray-500 flex items-center justify-center mr-4 shrink-0">
                 <ArrowUpRight size={20} />
              </div>
              <div className="flex-grow">
                 <div className="flex justify-between items-center mb-0.5">
                    <span className="font-bold text-[#1A1A1A] text-sm">Gửi: Người dùng</span>
                    <span className="font-bold text-gray-600">- ¥ 520,000</span>
                 </div>
                 <div className="text-[10px] text-gray-400 font-medium mb-1">10/02/2026</div>
                 <p className="text-xs italic text-gray-600 bg-gray-50/60 p-2 rounded-lg border border-gray-100">"cho em vì em xinh"</p>
              </div>
           </div>

           {/* Transaction 3 */}
           <div className="bg-white/80 rounded-3xl p-4 shadow-sm border border-white flex items-center">
              <div className="w-12 h-12 rounded-full bg-gray-50/60 text-gray-500 flex items-center justify-center mr-4 shrink-0">
                 <ArrowUpRight size={20} />
              </div>
              <div className="flex-grow">
                 <div className="flex justify-between items-center mb-0.5">
                    <span className="font-bold text-[#1A1A1A] text-sm">Gửi: Người dùng</span>
                    <span className="font-bold text-gray-600">- ¥ 1.00</span>
                 </div>
                 <div className="text-[10px] text-gray-400 font-medium mb-1">05/02/2026</div>
                 <p className="text-xs italic text-gray-600 bg-gray-50/60 p-2 rounded-lg border border-gray-100">"1 yên = 1 lần tôi nghĩ đến bạn hôm nay"</p>
              </div>
           </div>
        </div>

      </div>
    </AppLayout>
  );
}
