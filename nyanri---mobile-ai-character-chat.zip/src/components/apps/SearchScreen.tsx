import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';
import { Search as SearchIcon, Clock, X, Navigation } from 'lucide-react';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';

export default function SearchScreen() {
  const { currentCharacter } = useAppStore();
  if (!currentCharacter) return null;

  return (
    <AppLayout title="Lịch sử tìm kiếm" bgClass="bg-[#FAFAFA]" appId="search">
      <div className="px-5 py-6 pb-24 text-[#1A1A1A]">
        
        {/* Fake Search Bar */}
        <div className="w-full bg-white/80 border border-[#D4D4D4] rounded-full px-5 py-3.5 mb-8 shadow-sm flex items-center">
            <SearchIcon size={18} className="text-[#C9748A] mr-3 shrink-0" />
            <span className="text-gray-400 text-sm font-medium italic select-none">Tìm kiếm...</span>
        </div>

        <div className="flex justify-between items-center mb-6">
            <h3 className="font-serif italic text-xl">Tìm kiếm gần đây</h3>
            <span className="text-[10px] text-[#C9748A] uppercase tracking-widest font-bold">Làm mới</span>
        </div>

        {/* History List */}
        <div className="space-y-0 relative">
            <div className="absolute left-[19px] top-4 bottom-4 w-px bg-gray-100/60 z-0"></div>

            {/* Entry 1 */}
            <div className="flex items-start group relative z-10 py-3">
               <div className="w-10 h-10 rounded-full bg-white/80 border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 mr-4 shrink-0 transition-colors group-hover:border-[#F2C4CE] group-hover:text-[#C9748A]">
                  <Clock size={16} />
               </div>
               <div className="flex-grow pt-1">
                  <div className="text-sm font-medium text-gray-800 break-words group-hover:text-black">tại sao tim đập nhanh khi nghĩ đến một người</div>
                  <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider font-bold">12:30 • Mới tinh</div>
               </div>
               <button className="pt-1.5 opacity-0 group-hover:opacity-100 text-gray-300 hover:text-[#C9748A] transition-opacity">
                  <X size={16} />
               </button>
            </div>

            {/* Entry 2 */}
            <div className="flex items-start group relative z-10 py-3">
               <div className="w-10 h-10 rounded-full bg-white/80 border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 mr-4 shrink-0 transition-colors group-hover:border-[#F2C4CE] group-hover:text-[#C9748A]">
                  <Clock size={16} />
               </div>
               <div className="flex-grow pt-1">
                  <div className="text-sm font-medium text-gray-800 break-words group-hover:text-black">làm thế nào để nói 'tôi cần bạn' mà không nghe yếu đuối</div>
                  <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider font-bold">03:15 Sáng nay</div>
               </div>
               <button className="pt-1.5 opacity-0 group-hover:opacity-100 text-gray-300 hover:text-[#C9748A] transition-opacity">
                  <X size={16} />
               </button>
            </div>

            {/* Entry 3 */}
            <div className="flex items-start group relative z-10 py-3">
               <div className="w-10 h-10 rounded-full bg-white/80 border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 mr-4 shrink-0 transition-colors group-hover:border-[#F2C4CE] group-hover:text-[#C9748A]">
                  <Navigation size={14} />
               </div>
               <div className="flex-grow pt-1">
                  <div className="text-sm font-medium text-gray-800 break-words group-hover:text-black">quán cafe nào yên tĩnh mở muộn ở gần đây</div>
                  <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider font-bold">Hôm qua</div>
               </div>
               <button className="pt-1.5 opacity-0 group-hover:opacity-100 text-gray-300 hover:text-[#C9748A] transition-opacity">
                  <X size={16} />
               </button>
            </div>
            
            {/* Entry 4 */}
            <div className="flex items-start group relative z-10 py-3">
               <div className="w-10 h-10 rounded-full bg-white/80 border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 mr-4 shrink-0 transition-colors group-hover:border-[#F2C4CE] group-hover:text-[#C9748A]">
                  <Clock size={16} />
               </div>
               <div className="flex-grow pt-1">
                  <div className="text-sm font-medium text-gray-800 break-words group-hover:text-black">làm thế nào để không thể hiện rằng mình đang ghen</div>
                  <div className="text-[10px] text-gray-400 mt-1 uppercase tracking-wider font-bold">Hôm qua</div>
               </div>
               <button className="pt-1.5 opacity-0 group-hover:opacity-100 text-gray-300 hover:text-[#C9748A] transition-opacity">
                  <X size={16} />
               </button>
            </div>

        </div>
        
      </div>
    </AppLayout>
  );
}
