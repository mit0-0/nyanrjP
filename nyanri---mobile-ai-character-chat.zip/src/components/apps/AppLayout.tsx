import { ReactNode } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { ChevronLeft } from 'lucide-react';
import { cn } from '../../lib/utils';

interface AppLayoutProps {
  title: string;
  children: ReactNode;
  bgClass?: string;
  headerClass?: string;
  overlayClass?: string;
  bgImageClassName?: string;
  appId?: string;
  onBack?: () => void;
  rightButton?: ReactNode;
}

export default function AppLayout({ title, children, bgClass = 'bg-[#1A1A1A]', headerClass = 'text-white', overlayClass, bgImageClassName = 'opacity-60', appId, onBack, rightButton }: AppLayoutProps) {
  const { popScreen, themeSettings } = useAppStore();

  const bgImage = appId && themeSettings.appBackgrounds?.[appId] 
    ? themeSettings.appBackgrounds[appId] 
    : themeSettings.appBackground;

  return (
    <div className={cn("absolute inset-0 flex flex-col pt-12 overflow-hidden", bgClass, headerClass)}>
      {bgImage && (
        <div 
          className={cn("absolute inset-0 bg-cover bg-center pointer-events-none", bgImageClassName)}
          style={{ backgroundImage: `url("${bgImage}")` }}
        ></div>
      )}
      {overlayClass && (
        <div className={cn("absolute inset-0 pointer-events-none", overlayClass)}></div>
      )}
      {/* Header */}
      <div className="flex items-center px-4 mb-2 z-10 relative shrink-0">
        <button onClick={onBack || popScreen} className="p-2 -ml-2 active:scale-95 transition-transform" style={{ color: 'inherit' }}>
          <ChevronLeft />
        </button>
        <h1 className="font-serif italic text-xl flex-grow text-center pb-2 mx-4 border-b border-current/20 opacity-90" style={{ color: 'inherit' }}>
          {title}
        </h1>
        <div className="w-10 flex items-center justify-end">
           {rightButton || null}
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto no-scrollbar relative z-10">
         {children}
      </div>
    </div>
  );
}
