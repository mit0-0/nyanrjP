import { useState, useRef, useEffect } from 'react';
import AppLayout from './AppLayout';
import { useAppStore } from '../../store/useAppStore';
import { Plus, Edit2, Check, ArrowLeft, ArrowRight, Heart, Star, Sparkles, MessageCircle, X, Trash2, Send, Activity, Brain, Zap, Shield, BookOpen, Clock } from 'lucide-react';
import { cn } from '../../lib/utils';
import { CharacterProfile } from '../../store/useAppStore';

const getHue = (str: string) => {
   let hash = 0;
   for (let i = 0; i < str.length; i++) {
       hash = str.charCodeAt(i) + ((hash << 5) - hash);
   }
   return Math.abs(hash % 360);
};

// Map hash to a value between min and max
const getStat = (id: string, factor: number, min: number, max: number) => {
    let hash = 0;
    const str = id + factor.toString();
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const normalized = Math.abs(hash) / 2147483648; 
    return Math.floor(normalized * (max - min + 1)) + min;
};

export default function ContactsScreen() {
   const { contacts, pushScreen, setCharacter, removeContact, addMessage, themeSettings } = useAppStore();
   const [selectedCharId, setSelectedCharId] = useState<string | null>(null);
   const [activeStitch2Index, setActiveStitch2Index] = useState(0);
   const [chatInput, setChatInput] = useState('');
   const [activeTab, setActiveTab] = useState<'ARCHIVE' | 'ATTRIBUTES' | 'MEMORIES'>('ARCHIVE');

   const selectedChar = contacts.find(c => c.id === selectedCharId);

   const STITCH_2_DATA = selectedChar ? [
      { title: 'SYSTEM PROMPT', content: selectedChar.specialNotes || selectedChar.background || '[ NO DATA AVAILABLE ]' },
      { title: 'PERSONALITY', content: selectedChar.personalityParams || '[ NO DATA AVAILABLE ]' },
      { title: 'SCENARIO', content: selectedChar.scenario || '[ NO DATA AVAILABLE ]' }
   ] : [];

   const handleConnect = () => {
      if (!selectedChar) return;
      if (chatInput.trim()) {
         addMessage({
            id: Date.now().toString(),
            role: 'user',
            content: chatInput.trim(),
            timestamp: new Date().toISOString(),
            type: 'text'
         });
         setChatInput('');
      }
      setCharacter(selectedChar);
      pushScreen('chat-detail');
   };

   const [activeCharColor, setActiveCharColor] = useState<{ bgTone: string, accentTone: string, cardBg: string } | null>(null);

   useEffect(() => {
      if (selectedChar && selectedChar.avatar) {
         import('fast-average-color').then(({ FastAverageColor }) => {
            const fac = new FastAverageColor();
            fac.getColorAsync(selectedChar.avatar)
               .then(color => {
                  const [r,g,b] = color.value;
                  const isDark = color.isDark;
                  setActiveCharColor({
                     bgTone: `rgba(${r}, ${g}, ${b}, 0.15)`,
                     accentTone: color.hex,
                     cardBg: isDark ? `rgba(255, 255, 255, 0.85)` : `rgba(0, 0, 0, 0.05)`
                  });
               })
               .catch(e => {
                  const charHue = getHue(selectedChar.name);
                  setActiveCharColor({
                     bgTone: `hsl(${charHue}, 30%, 90%)`,
                     accentTone: `hsl(${charHue}, 40%, 25%)`,
                     cardBg: `hsla(${charHue}, 20%, 85%, 0.5)`
                  });
               });
         });
      } else if (selectedChar) {
          const charHue = getHue(selectedChar.name);
          setActiveCharColor({
             bgTone: `hsl(${charHue}, 30%, 90%)`,
             accentTone: `hsl(${charHue}, 40%, 25%)`,
             cardBg: `hsla(${charHue}, 20%, 85%, 0.5)`
          });
      } else {
         setActiveCharColor(null);
      }
   }, [selectedChar]);

   const colors = activeCharColor || { bgTone: '#EFECE1', accentTone: '#3A3831', cardBg: 'rgba(255,255,255,0.5)' };

   return (
      <AppLayout title="KẾT NỐI" bgClass={themeSettings.appBackgrounds?.['contacts'] ? 'bg-black/90' : 'bg-[#E5E3D8]'} headerClass={themeSettings.appBackgrounds?.['contacts'] ? 'text-white' : 'text-[#3A3831]'} appId="contacts">
         <div className="flex-grow overflow-y-auto px-4 py-6 space-y-6 pb-24">
            <h2 className={cn("text-[10px] tracking-[0.3em] font-medium uppercase mb-4 pl-1", themeSettings.appBackgrounds?.['contacts'] ? 'text-white/60' : 'text-[#7D786D]')}>VÒNG KẾT NỐI / NHÂN VẬT</h2>
            
            {contacts.map((contact, i) => (
               <div key={contact.id} className="relative bg-[#DDDCD2] p-5 shadow-[0_2px_10px_rgba(0,0,0,0.05)] cursor-pointer hover:bg-[#D5D3CA] transition-colors flex gap-5 min-h-[160px]" onClick={() => setSelectedCharId(contact.id)}>
                  <div className="w-[110px] h-[140px] shrink-0 bg-[#C3C1B5] overflow-hidden">
                     {contact.avatar && <img src={contact.avatar} alt="avatar" className="w-full h-full object-cover mix-blend-multiply opacity-90" />}
                  </div>
                  
                  <div className="flex-grow flex flex-col pt-1">
                     <span className="text-[9px] tracking-[0.2em] font-medium text-[#7D786D] uppercase mb-1">MÃ NGƯỜI DÙNG #{contact.id.slice(0,4)}</span>
                     <h3 className="font-serif text-2xl text-[#3A3831] mb-2">{contact.name}</h3>
                     <p className="text-xs text-[#5C5950] leading-relaxed mb-4 line-clamp-2 italic font-serif">"{contact.specialNotes || contact.personalityParams || 'Chưa có thông tin...'}"</p>
                     
                     <div className="mt-auto border-t border-dashed border-[#BDBCA9] pt-3 flex flex-col gap-2.5">
                         {/* Status */}
                         <div className="flex items-center gap-2">
                             <div className={cn("w-1.5 h-1.5 rounded-full animate-pulse", contact.mood === 'bình thường' ? 'bg-emerald-500' : 'bg-pink-500')}></div>
                             <span className="text-[9px] uppercase font-bold tracking-[0.1em] text-[#5C5950]">{contact.mood || 'Bình thường'}</span>
                         </div>
                         
                         {/* Relationship Progress */}
                         <div className="space-y-1.5 w-full pr-6">
                             <div className="flex justify-between items-center text-[9px] uppercase font-bold tracking-widest text-[#5C5950]">
                                <span>Tình cảm</span>
                                <span>{contact.relationshipLevel || 0}%</span>
                             </div>
                             <div className="h-1 bg-[#BDBCA9]/40 rounded-full overflow-hidden w-full relative">
                                <div className="absolute top-0 left-0 bottom-0 bg-[#3A3831]/80 rounded-full transition-all duration-1000 ease-out" style={{ width: `${contact.relationshipLevel || 0}%` }}></div>
                             </div>
                         </div>
                     </div>
                  </div>

                  <div className="absolute right-0 top-6 bottom-6 w-[20px] bg-[#2A2A2A] flex items-center justify-center translate-x-1 shadow-md">
                     <span className="text-white text-[9px] tracking-[0.3em] rotate-90 whitespace-nowrap opacity-80 uppercase">LIÊN KẾT {(i + 1).toString().padStart(2, '0')}</span>
                  </div>
               </div>
            ))}

            <button 
               className="w-full relative bg-[#DDDCD2] p-6 shadow-[0_2px_10px_rgba(0,0,0,0.05)] border border-dashed border-[#BDBCA9] flex flex-col items-center justify-center gap-3 hover:bg-[#D5D3CA] transition-colors min-h-[160px]"
               onClick={() => {
                  setCharacter(null);
                  pushScreen('character-create');
               }}
            >
               <div className="w-10 h-10 rounded-full border border-[#7D786D] flex items-center justify-center text-[#7D786D]">
                  <Plus size={20} strokeWidth={1.5} />
               </div>
               <span className="text-[10px] tracking-[0.2em] font-medium text-[#7D786D] uppercase">Create New Outline</span>
            </button>
         </div>

         {/* Character Profile Archive View */}
         <div 
            className={cn(
               "absolute inset-0 z-50 transition-all duration-700 overflow-hidden flex flex-col", 
               selectedChar ? "translate-y-0 opacity-100 pointer-events-auto" : "translate-y-[10px] opacity-0 pointer-events-none"
            )}
            style={{ backgroundColor: colors.bgTone }}
         >
            {selectedChar && (() => {
               const charHue = getHue(selectedChar.name);
               const isAccentDark = parseInt(colors.accentTone.replace('#', ''), 16) < 0xffffff / 2;
               
               return (
                  <>
                     {/* Background Image / Blur */}
                     <div className="absolute inset-0 z-0">
                        {themeSettings.appBackgrounds?.['contacts'] ? (
                           <div 
                              className="absolute inset-0 bg-cover bg-center blur-[12px] scale-110 opacity-70 mix-blend-overlay"
                              style={{ backgroundImage: `url(${themeSettings.appBackgrounds?.['contacts']})` }}
                           />
                        ) : null}
                        <div className="absolute inset-0 opacity-80 bg-white/50 backdrop-blur-3xl" />
                        <div className="absolute inset-0" style={{ backgroundImage: `radial-gradient(circle at top left, ${colors.bgTone} 0%, transparent 80%), radial-gradient(circle at bottom right, ${colors.accentTone}22 0%, transparent 60%)` }} />
                     </div>

                     {/* Header Area */}
                     <div className="relative z-10 px-6 pt-12 pb-4 flex justify-between items-start">
                        <div>
                           <h1 className="text-4xl font-serif text-[#3A3831] drop-shadow-sm tracking-wide" style={{ color: colors.accentTone }}>
                              {selectedChar.name}
                           </h1>
                           <div className="flex gap-2 items-center mt-2.5">
                              <span className="text-[9px] tracking-[0.4em] uppercase font-bold" style={{ color: colors.accentTone, opacity: 0.8 }}>
                                 ARCHIVE
                              </span>
                              <div className="w-8 h-[1px]" style={{ backgroundColor: colors.accentTone, opacity: 0.5 }}></div>
                              <span className="text-[9px] tracking-[0.4em] uppercase font-bold" style={{ color: colors.accentTone, opacity: 0.8 }}>
                                 VOL. {selectedChar.id.slice(-2)}
                              </span>
                           </div>
                        </div>
                        <div className="flex gap-4 items-center">
                           <button onClick={() => setSelectedCharId(null)} className="p-2 active:scale-95 transition-transform" style={{ color: colors.accentTone }}>
                              <ArrowLeft size={22} strokeWidth={1.5} className="rotate-180" />
                           </button>
                        </div>
                     </div>

                     {/* Tab Navigation */}
                     <div className="relative z-10 px-6 flex gap-6 border-b border-black/10">
                         {['ARCHIVE', 'ATTRIBUTES', 'MEMORIES'].map((tab) => (
                             <button
                                 key={tab}
                                 onClick={() => setActiveTab(tab as any)}
                                 className={cn(
                                     "pb-3 text-[10px] tracking-[0.2em] font-bold uppercase transition-all",
                                     activeTab === tab ? "border-b-2" : "opacity-40 hover:opacity-70"
                                 )}
                                 style={{ 
                                     color: activeTab === tab ? colors.accentTone : '#000',
                                     borderColor: activeTab === tab ? colors.accentTone : 'transparent'
                                 }}
                             >
                                 {tab}
                             </button>
                         ))}
                     </div>

                     {/* Scrollable Content (Stitch Blocks) */}
                     <div className="relative z-10 flex-grow overflow-y-auto px-6 py-6 pb-32 space-y-12">
                        
                        {/* PROFILE HEADER - Always visible or top of content */}
                        <div className="relative">
                           <div 
                              className="relative w-full rounded-[24px] p-6 pt-6 border shadow-[0_10px_30px_rgba(0,0,0,0.05)] backdrop-blur-md"
                              style={{ backgroundColor: colors.cardBg, borderColor: `${colors.accentTone}22` }}
                           >
                              <div className="flex gap-5">
                                 <div className="w-[80px] h-[100px] shrink-0 bg-black/10 overflow-hidden shadow-inner">
                                    {selectedChar.avatar && <img src={selectedChar.avatar} alt="avatar" className="w-full h-full object-cover mix-blend-multiply opacity-90" />}
                                 </div>
                                 <div className="flex-grow flex flex-col justify-center gap-3">
                                    <div className="flex items-center gap-2">
                                       <span className="text-[10px] uppercase font-bold tracking-widest text-black/40 w-16">AGE</span>
                                       <span className="text-sm font-serif" style={{ color: colors.accentTone }}>{selectedChar.age || 'Unknown'}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                       <span className="text-[10px] uppercase font-bold tracking-widest text-black/40 w-16">GENDER</span>
                                       <span className="text-sm font-serif" style={{ color: colors.accentTone }}>{selectedChar.gender || 'Unknown'}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                       <span className="text-[10px] uppercase font-bold tracking-widest text-black/40 w-16">LEVEL</span>
                                       <span className="text-sm font-serif" style={{ color: colors.accentTone }}>{selectedChar.relationshipLevel || 0}%</span>
                                    </div>
                                 </div>
                              </div>
                              <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-black/5">
                                 <button 
                                    className="w-8 h-8 rounded-full flex items-center justify-center bg-white/30 hover:bg-white/80 text-black/60 hover:text-black shadow-sm transition-colors"
                                    onClick={() => {
                                       setCharacter(selectedChar);
                                       pushScreen('character-create');
                                    }}
                                    title="Edit Profile"
                                 >
                                    <Edit2 size={14} strokeWidth={1.5} />
                                 </button>
                                 <button 
                                    className="w-8 h-8 rounded-full flex items-center justify-center bg-white/30 hover:bg-white/80 text-black/60 hover:text-red-600 shadow-sm transition-colors"
                                    onClick={() => {
                                       if(window.confirm('Delete this persona?')) {
                                          removeContact(selectedChar.id);
                                          setSelectedCharId(null);
                                       }
                                    }}
                                    title="Delete Persona"
                                 >
                                    <Trash2 size={14} strokeWidth={1.5} />
                                 </button>
                              </div>
                           </div>
                        </div>

                        {activeTab === 'ARCHIVE' && (
                            <div className="relative animate-in fade-in slide-in-from-bottom-4 duration-500">
                                <div 
                                   className="absolute -top-3 right-4 px-4 py-1.5 text-[10px] tracking-[0.2em] font-medium z-20 text-white uppercase shadow-sm"
                                   style={{ backgroundColor: colors.accentTone }}
                                >
                                   STITCH 02 / {STITCH_2_DATA[activeStitch2Index].title}
                                </div>
                                <div 
                                   className="relative w-full rounded-[24px] p-6 pt-10 border shadow-[0_10px_30px_rgba(0,0,0,0.05)] backdrop-blur-md min-h-[140px] flex flex-col"
                                   style={{ backgroundColor: colors.cardBg, borderColor: `${colors.accentTone}22` }}
                                >
                                   <p className="flex-grow text-[13px] leading-relaxed font-serif italic text-black/80 mb-6 whitespace-pre-wrap">
                                      {STITCH_2_DATA[activeStitch2Index].content}
                                   </p>
                                   <div className="flex items-center justify-between text-[10px] tracking-widest uppercase font-bold text-black/40">
                                      <div className="flex items-center gap-4 mx-auto cursor-pointer select-none">
                                         <button onClick={() => setActiveStitch2Index(prev => prev > 0 ? prev - 1 : STITCH_2_DATA.length - 1)} className="p-2 hover:text-black active:scale-95 transition-all">
                                            <ArrowLeft size={14} className="opacity-70" />
                                         </button>
                                         <span className="flex items-center gap-2">
                                            <div className="w-8 h-[1px] bg-black/20"></div>
                                            DATA {(activeStitch2Index + 1).toString().padStart(2,'0')} / {STITCH_2_DATA.length.toString().padStart(2,'0')}
                                         </span>
                                         <button onClick={() => setActiveStitch2Index(prev => prev < STITCH_2_DATA.length - 1 ? prev + 1 : 0)} className="p-2 hover:text-black active:scale-95 transition-all">
                                            <ArrowRight size={14} className="opacity-70" />
                                         </button>
                                      </div>
                                   </div>
                                </div>
                            </div>
                        )}

                        {activeTab === 'ATTRIBUTES' && (
                            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
                                {['WISDOM', 'VITALITY', 'CHARISMA', 'AGILITY'].map((stat, idx) => {
                                    const val = getStat(selectedChar.id, idx, 40, 98);
                                    const icons = [Brain, Activity, Star, Zap];
                                    const Icon = icons[idx];
                                    return (
                                        <div key={stat} className="flex items-center gap-4 p-4 rounded-2xl border bg-white/50" style={{ borderColor: `${colors.accentTone}22` }}>
                                            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: `${colors.accentTone}22`, color: colors.accentTone }}>
                                                <Icon size={18} />
                                            </div>
                                            <div className="flex-grow">
                                                <div className="flex justify-between mb-1">
                                                    <span className="text-[10px] tracking-widest uppercase font-bold text-black/60">{stat}</span>
                                                    <span className="text-[10px] font-bold" style={{ color: colors.accentTone }}>{val}</span>
                                                </div>
                                                <div className="h-1 bg-black/5 rounded-full overflow-hidden">
                                                    <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${val}%`, backgroundColor: colors.accentTone }} />
                                                </div>
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        )}

                        {activeTab === 'MEMORIES' && (
                            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-[1px] before:bg-black/10">
                                {[
                                    { text: "First Encounter: A fleeting glance in the rain.", date: "Unknown" },
                                    { text: "Trust established during the midnight protocol.", date: "Log #442" },
                                    { text: "Shared silence is sometimes louder than words.", date: "Current Cycle" },
                                ].map((mem, idx) => (
                                    <div key={idx} className="relative pl-10 pr-4">
                                        <div className="absolute left-[13px] top-1 w-2.5 h-2.5 rounded-full border-2 border-white" style={{ backgroundColor: colors.accentTone }} />
                                        <p className="text-[13px] text-black/80 font-serif italic mb-1">"{mem.text}"</p>
                                        <p className="text-[9px] tracking-widest text-black/40 uppercase">{mem.date}</p>
                                    </div>
                                ))}
                            </div>
                        )}
                     </div>

                     {/* Bottom Input Area */}
                     <div className="absolute z-20 bottom-8 left-4 right-4">
                        <div 
                           className="w-full rounded-[24px] p-2 flex items-center gap-2 shadow-[0_20px_40px_rgba(0,0,0,0.15)] backdrop-blur-3xl border bg-white/50"
                           style={{ borderColor: `${colors.accentTone}40` }}
                        >
                           <input 
                              type="text" 
                              value={chatInput}
                              onChange={(e) => setChatInput(e.target.value)}
                              placeholder="Write into the silence..."
                              onKeyDown={(e) => e.key === 'Enter' && handleConnect()}
                              className="flex-grow pl-4 py-3 bg-transparent outline-none font-serif italic text-sm text-black placeholder:text-black/40"
                           />
                           <button 
                              className="px-6 py-3 rounded-[18px] tracking-[0.2em] text-[11px] font-bold uppercase text-white shadow-md active:scale-95 transition-all truncate min-w-[100px] flex items-center justify-center gap-2"
                              style={{ backgroundColor: colors.accentTone }}
                              onClick={handleConnect}
                           >
                              {chatInput ? <Send size={14} /> : <MessageCircle size={14} />}
                              {chatInput ? 'SEND' : 'CONNECT'}
                           </button>
                        </div>
                     </div>
                  </>
               );
            })()}
         </div>
      </AppLayout>
   );
}

