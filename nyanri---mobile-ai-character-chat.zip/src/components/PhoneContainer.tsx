import { ReactNode, useEffect, useState, useRef } from 'react';
import { Battery, Wifi, Signal } from 'lucide-react';
import { format } from 'date-fns';
import { useAppStore } from '../store/useAppStore';

interface PhoneContainerProps {
  children: ReactNode;
}

export default function PhoneContainer({ children }: PhoneContainerProps) {
  const [time, setTime] = useState(new Date());
  const { globalMediaId, globalMediaUrl, isGlobalPlaying, setGlobalMedia, setGlobalMediaProgress } = useAppStore();
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      if (isGlobalPlaying) {
        audioRef.current.play().catch(e => {
          console.error("Audio play failed:", e);
          setGlobalMedia(globalMediaId, globalMediaUrl, false);
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isGlobalPlaying, globalMediaUrl]);

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const current = audioRef.current.currentTime;
      const duration = audioRef.current.duration || 0;
      const progress = duration > 0 ? current / duration : 0;
      // throttle storing or just store directly if performance is ok
      setGlobalMediaProgress(progress, current, duration);
    }
  };

  return (
    <div className="relative w-full h-[100dvh] bg-[#1A1A1A] flex-shrink-0 mx-auto overflow-hidden flex flex-col">
      {/* Global Media Player Component */}
      <div className="absolute -top-[1000px] -left-[1000px] w-[300px] h-[300px] overflow-hidden opacity-0 pointer-events-none z-[-999]">
        {globalMediaUrl ? (
          <audio 
            ref={audioRef}
            src={globalMediaUrl} 
            onTimeUpdate={handleTimeUpdate}
            onEnded={() => setGlobalMedia(globalMediaId, globalMediaUrl, false)}
            onError={(e) => {
              console.warn("Global Audio error:", e);
              setGlobalMedia(globalMediaId, globalMediaUrl, false);
            }}
          />
        ) : null}
      </div>

      {/* Phone Screen Edge */}
      <div className="relative w-full h-full overflow-hidden flex flex-col">
        
        {/* Status Bar */}
        <div className="absolute top-0 w-full h-10 flex items-center justify-between px-6 z-50 text-white select-none pointer-events-none fade-in">
          <div className="text-[12px] font-medium tracking-tight">
            {format(time, 'HH:mm')}
          </div>
          <div className="flex items-center gap-1.5 text-[11px]">
            <Signal size={12} className="opacity-90 mt-0.5" />
            <span className="font-medium">5G</span>
            <Battery size={14} className="opacity-90 ml-1" />
          </div>
        </div>

        {/* Content */}
        <div className="flex-grow w-full h-full relative z-0">
          {children}
        </div>
      </div>
    </div>
  );
}
