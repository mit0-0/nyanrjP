import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { loadAppData } from './store/useAppStore';

window.addEventListener('unhandledrejection', (event) => {
  if (event.reason && event.reason.name === 'AbortError') {
    event.preventDefault();
  }
  if (event.reason && typeof event.reason.message === 'string' && event.reason.message.includes('play() request was interrupted')) {
    event.preventDefault();
  }
});

// Suppress Vite error overlay for these specific play() errors
const originalConsoleError = console.error;
console.error = function(...args) {
  if (args[0] && typeof args[0] === 'string' && args[0].includes('play() request was interrupted')) {
    return;
  }
  originalConsoleError.apply(console, args);
};

// Load stored data before booting the app
loadAppData().then(() => {
  createRoot(document.getElementById('root')!).render(
    <App />
  );
});

