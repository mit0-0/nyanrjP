/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, Component, ErrorInfo, ReactNode } from 'react';
import { useAppStore } from './store/useAppStore';
import { AnimatePresence, motion } from 'motion/react';
import PhoneContainer from './components/PhoneContainer';
import SplashScreen from './components/screens/SplashScreen';
import HomeScreen from './components/screens/HomeScreen';
import ChatScreen from './components/screens/ChatScreen';
import ChatListScreen from './components/screens/ChatListScreen';
import CharacterCreateScreen from './components/screens/CharacterCreateScreen';
import DiaryScreen from './components/apps/DiaryScreen';
import SocialScreen from './components/apps/SocialScreen';
import BankScreen from './components/apps/BankScreen';
import ShoprjScreen from './components/apps/ShoprjScreen';
import MusicScreen from './components/apps/MusicScreen';
import SearchScreen from './components/apps/SearchScreen';
import SettingsScreen from './components/apps/SettingsScreen';
import WorldbookScreen from './components/apps/WorldbookScreen';
import ForumScreen from './components/apps/ForumScreen';
import ContactsScreen from './components/apps/ContactsScreen';
import DailyLogScreen from './components/apps/DailyLogScreen';
import AppLayout from './components/apps/AppLayout'; // Helper for quick mocks

class ErrorBoundary extends Component<{children: ReactNode}, {hasError: boolean, error: string}> {
  constructor(props: {children: ReactNode}) {
    super(props);
    this.state = { hasError: false, error: '' };
  }

  static getDerivedStateFromError(error: Error) {
    if (error && error.message && error.message.includes('play() request was interrupted')) {
      return { hasError: false, error: '' };
    }
    if (error && error.name === 'AbortError') {
      return { hasError: false, error: '' };
    }
    if (error && error.name === 'NotAllowedError') {
      return { hasError: false, error: '' };
    }
    return { hasError: true, error: error.toString() };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
         <div className="absolute inset-0 bg-red-900 border border-red-500 text-white p-4 overflow-auto z-50">
            <h1>Something went wrong.</h1>
            <pre className="text-xs">{this.state.error}</pre>
            <button onClick={() => { localStorage.clear(); window.location.reload() }} className="mt-4 px-4 py-2 bg-white text-red-900 rounded-lg">Clear Storage & Reload</button>
         </div>
      );
    }
    return this.props.children;
  }
}

function MockScreen({ title }: { title: string }) {
   return (
      <AppLayout title={title} bgClass="bg-[#1A1A1A]">
         <div className="flex flex-col items-center justify-center h-64 text-[#F2C4CE] opacity-80">
            <span className="text-4xl mb-4">✧</span>
            <p className="font-serif italic text-xl text-center px-6">Tính năng {title.toLowerCase()} đang được xây dựng...</p>
         </div>
      </AppLayout>
   )
}

export default function App() {
  const { currentScreen, replaceScreen } = useAppStore();

  // Handle splash screen timer
  useEffect(() => {
    // Lock screen manually handled in SplashScreen
  }, [currentScreen, replaceScreen]);

  return (
    <div className="h-[100dvh] w-full bg-black flex items-center justify-center relative font-sans overflow-hidden">
      <PhoneContainer>
        <ErrorBoundary>
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0, scale: 0.85, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.08 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="absolute inset-0 w-full h-full bg-black"
          >
            {currentScreen === 'splash' && <SplashScreen />}
            {currentScreen === 'home' && <HomeScreen />}
            {currentScreen === 'character-create' && <CharacterCreateScreen />}
            {currentScreen === 'chat' && <ChatListScreen />}
            {currentScreen === 'chat-detail' && <ChatScreen />}
            {currentScreen === 'diary' && <DiaryScreen />}
            {currentScreen === 'social' && <SocialScreen />}
            {currentScreen === 'bank' && <BankScreen />}
            {currentScreen === 'music' && <MusicScreen />}
            {currentScreen === 'shoprj' && <ShoprjScreen />}
            {currentScreen === 'search' && <SearchScreen />}
            {currentScreen === 'settings' && <SettingsScreen />}
            {currentScreen === 'worldbook' && <WorldbookScreen />}
            {currentScreen === 'forum' && <ForumScreen />}
            {currentScreen === 'contacts' && <ContactsScreen />}
            {currentScreen === 'daily-log' && <DailyLogScreen />}
            {/* Fallback for anything not explicitly matched above */}
            {(!['splash','home','character-create','chat','chat-detail','diary','social','bank','map','music','gallery','search','settings','worldbook','forum','contacts','daily-log','shoprj'].includes(currentScreen)) && <MockScreen title="Ứng dụng" />}
          </motion.div>
        </AnimatePresence>
        </ErrorBoundary>
      </PhoneContainer>
    </div>
  );
}


